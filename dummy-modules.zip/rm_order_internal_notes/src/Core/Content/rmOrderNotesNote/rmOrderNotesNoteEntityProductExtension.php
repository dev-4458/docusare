<?php declare(strict_types=1);

namespace rm\Customization\Core\Content\rmOrderNotesNote;

use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToManyAssociationField;


class rmOrderNotesNoteEntityProductExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            new OneToManyAssociationField('rmCustomization', rmOrderNotesNoteDefinition::class, 'entity_id', 'id', false),
        );
    }

    public function getDefinitionClass(): string
    {
        return ProductDefinition::class;
    }
}