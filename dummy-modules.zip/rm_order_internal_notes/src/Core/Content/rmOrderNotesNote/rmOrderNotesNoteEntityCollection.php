<?php declare(strict_types=1);

namespace rm\Customization\Core\Content\rmOrderNotesNote;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

class rmOrderNotesNoteEntityCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return rmOrderNotesNoteEntity::class;
    }
}