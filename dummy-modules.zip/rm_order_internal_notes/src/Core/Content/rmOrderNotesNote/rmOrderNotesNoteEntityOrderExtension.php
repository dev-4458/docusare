<?php declare(strict_types=1);

namespace rm\Customization\Core\Content\rmOrderNotesNote;

use Shopware\Core\Checkout\Order\OrderDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToManyAssociationField;


class rmOrderNotesNoteEntityOrderExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            new OneToManyAssociationField('rmCustomization', rmOrderNotesNoteDefinition::class, 'entity_id', 'id', false),
        );
    }

    public function getDefinitionClass(): string
    {
        return OrderDefinition::class;
    }
}