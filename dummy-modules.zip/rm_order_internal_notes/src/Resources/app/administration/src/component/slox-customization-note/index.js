import template from './rm-customization-note.html.twig';
import './rm-customization-note.scss';

const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;

Shopware.Component.register('rm-customization-note', {
    template,

    inject: [
        'repositoryFactory',
        'userService'
    ],

    mixins: [
        Mixin.getByName('notification')
    ],

    data() {
        return {
            note: null,
            items: null,
            checkedDesktopItems: [],
            checkedItems: [],
            showButtonForShowMessage: false
        }
    },

    computed: {
        rmCustomizationRepository() {
            return this.repositoryFactory.create('rm_customization');
        },

        currentUser() {
            return Shopware.State.get('session').currentUser;
        },

        getItems() {
            if (this.items) {
                document.querySelector(".rmCustomizationBadge").textContent = this.items.length;
                document.querySelector(".rmCustomizationBadge").classList.remove('hasCustomizations');

                if(this.items.length > 0)
                    document.querySelector(".rmCustomizationBadge").classList.add('hasCustomizations');

                return this.items;
            }

            return;
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            if (this.$route.meta.entityType == 'customer' || this.$route.meta.entityType == 'product')
                this.showButtonForShowMessage = true;

            this.loadItems();
            return this.items;
        },

        loadItems() {
            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('entityId', this.$route.params.id)
            );
            criteria.addSorting(Criteria.sort('createdAt', 'desc'));

            this.rmCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    this.items = result;
                    this.items.forEach((value, index) => {
                        if (value.showDesktop == 1)
                            this.checkedDesktopItems.push(value.id);
                            
                        if (value.showMessage == 1)
                            this.checkedItems.push(value.id);
                    });
                });
        },

        onNoteSaveClick() {
            if (this.note == null || this.note.length == 0)
                return;

            this.createNotificationSuccess({ title: this.$tc('rm-customization-note.general.title'), message: this.$tc('rm-customization-note.general.saved') })

            let entity = this.rmCustomizationRepository.create(Shopware.Context.api);
            entity.entityId = this.$route.params.id;
            entity.entityType = this.$route.meta.entityType;
            entity.username = this.currentUser.lastName;
            entity.note = this.note;

            this.rmCustomizationRepository.save(entity, Shopware.Context.api).then(result => {
                this.loadItems();
            });

            this.note = '';
        },

        onNoteShowOnDesktopChange(event) {
            let itemId = event.target.value;
            let checked = event.target.checked;

            if (!itemId)
                return;

            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('id', itemId)
            );

            this.rmCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    result.forEach((entity) => {
                        if (checked == true)
                            entity.showDesktop = 1;
                        else
                            entity.showDesktop = 0;

                        this.rmCustomizationRepository.save(entity, Shopware.Context.api);
                    });
                });
        },
        
        onNoteShowMessageChange(event) {
            let itemId = event.target.value;
            let checked = event.target.checked;

            if (!itemId)
                return;

            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('id', itemId)
            );

            this.rmCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    result.forEach((entity) => {
                        if (checked == true)
                            entity.showMessage = 1;
                        else
                            entity.showMessage = 0;

                        this.rmCustomizationRepository.save(entity, Shopware.Context.api);
                    });
                });
        },

        onShowConfirmation(event) {
            event.target.parentNode.style.display = "none";
            event.target.parentNode.nextElementSibling.style.display = "block";
        },

        onDeleteThisNote(event) {
            let itemId = event.target.dataset.id;

            if (!itemId)
                return;

            this.onRestoreConfirmation(event);
            this.rmCustomizationRepository.delete(itemId, Shopware.Context.api).then(result => {
                this.createNotificationSuccess({ title: this.$tc('rm-customization-note.general.title'), message: this.$tc('rm-customization-note.general.deleted') });
                this.loadItems();
            });
        },

        onRestoreConfirmation(event) {
            event.target.parentNode.parentNode.style.display = "none";
            event.target.parentNode.parentNode.previousElementSibling.style.display = "block";
        }
    }
});