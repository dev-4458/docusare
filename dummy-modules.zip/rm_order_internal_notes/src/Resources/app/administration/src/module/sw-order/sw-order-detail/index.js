import template from './sw-order-detail.html.twig';

const {Component, Context} = Shopware;
const {Criteria} = Shopware.Data;

Component.override('sw-order-detail', {
    template,

    inject: [
        'repositoryFactory'
    ],

    data() {
        return {
            items: null,
        }
    },

    computed: {
        rmCustomizationRepository() {
            return this.repositoryFactory.create('rm_customization');
        },
    },

    created() {
        this.createdCustomizationComponent();
    },

    methods: {
        createdCustomizationComponent() {
            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('entityId', this.$route.params.id)
            );

            this.rmCustomizationRepository
            .search(criteria, Shopware.Context.api)
            .then(result => {
                this.items = result;
                document.querySelector(".rmCustomizationBadge").textContent = this.items.length;
                document.querySelector(".rmCustomizationBadge").classList.remove('hasCustomizations');
                
                if(this.items.length > 0)
                    document.querySelector(".rmCustomizationBadge").classList.add('hasCustomizations');
            });
        },
    }
});