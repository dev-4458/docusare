import template from './sw-order-list.html.twig';

const {Component} = Shopware;
const { Criteria } = Shopware.Data;

Component.override('sw-order-list', {
    template,

    computed: {
        orderCriteria() {
            const criteria = this.$super('orderCriteria');
            criteria.addAssociation('rmCustomization');
            criteria.getAssociation('rmCustomization').addSorting(Criteria.sort('createdAt', 'DESC'));
            return criteria;
        }
    },

    methods: {
        getOrderColumns() {
            const columns = this.$super('getOrderColumns');

            columns.push({
                property: 'rmcustomizationnote',
                label: 'rm-customization-note.general.title',
                allowResize: true,
                primary: false,
            });

            return columns;
        },
    },

});
