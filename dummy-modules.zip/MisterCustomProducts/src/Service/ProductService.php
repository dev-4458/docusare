<?php declare(strict_types=1);

namespace MisterCustomProducts\Product;

use Shopware\Core\Content\Product\ProductCollection;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;

class CustomProductService
{
    private EntityRepositoryInterface $productRepository;
    private EntityRepositoryInterface $customFieldSetRepository;
    private EntityRepositoryInterface $customFieldRepository;

    public function __construct(
        EntityRepositoryInterface $productRepository,
        EntityRepositoryInterface $customFieldSetRepository,
        EntityRepositoryInterface $customFieldRepository
    ) {
        $this->productRepository = $productRepository;
        $this->customFieldSetRepository = $customFieldSetRepository;
        $this->customFieldRepository = $customFieldRepository;
    }

    public function getProductsWithCustomSpecOEM(int $customSpecOEM, Context $context): ProductCollection
    {
        $customFieldSet = $this->customFieldSetRepository->search([
            ['name' => 'custom_spec_OEM']
        ], $context)->first();

        $customField = $this->customFieldRepository->search([
            ['name' => 'custom_spec_OEM'],
            ['customFieldSetId' => $customFieldSet->getId()]
        ], $context)->first();

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('customFields.' . $customField->getId(), $customSpecOEM));

        return $this->productRepository->search($criteria, $context)->getEntities();
    }
}
