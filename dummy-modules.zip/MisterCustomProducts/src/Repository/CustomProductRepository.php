<?php

namespace NikiOFoodyTheme2\Repository;

use Doctrine\DBAL\Connection;
use Shopware\Core\Content\Product\ProductCollection;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Doctrine\FetchModeHelper;
use Shopware\Core\Framework\DataAbstractionLayer\Doctrine\QueryBuilder;
use Shopware\Core\Framework\DataAbstractionLayer\Doctrine\Repository\EntityRepository;

class CustomProductRepository extends EntityRepository
{
    public function getProductsByCommonOEM(string $oemValue, string $currentProductId, Context $context): ProductCollection
    {
        $query = $this->createQueryBuilder('product')
            ->andWhere('product.customFields.custom_spec_OEM = :oemValue')
            ->andWhere('product.id != :currentProductId')
            ->setParameter('oemValue', $oemValue)
            ->setParameter('currentProductId', $currentProductId)
            ->getQuery();

        $query->setFetchMode(
            $this->getDefinition()->getEntityClass(),
            'customFields',
            FetchModeHelper::FETCH_LAZY
        );

        return new ProductCollection($query->getResult());
    }
}
