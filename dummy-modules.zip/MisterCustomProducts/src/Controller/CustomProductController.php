<?php declare(strict_types=1);

namespace MisterCustomProducts\Controller;

use MisterCustomProducts\Service\ProductService;
use Shopware\Core\Framework\Routing\Annotation\RouteScopePrefix;
use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @RouteScopePrefix("/api")
 */
class CustomProductController extends StorefrontController
{
    private $productService;

    public function __construct(ProductService $productService)
    {
        $this->productService = $productService;
    }

    /**
     * @Route("/v{version}/_action/mister_custom_products/list", name="api.action.mister_custom_products.list", methods={"GET"})
     */
    public function list(Request $request): JsonResponse
    {
        $products = $this->productService->getProductsByCustomField();

        return new JsonResponse(['customProducts' => $products]);
    }
}
