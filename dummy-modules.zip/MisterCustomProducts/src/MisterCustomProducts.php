<?php declare(strict_types=1);

namespace MisterCustomProducts;

use Shopware\Core\Framework\Plugin;

class MisterCustomProducts extends Plugin
{
}