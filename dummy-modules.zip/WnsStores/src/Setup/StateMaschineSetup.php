<?php declare(strict_types=1);

namespace Wns\Stores\Setup;

use Doctrine\DBAL\Connection;
use Shopware\Core\Checkout\Order\Aggregate\OrderDelivery\OrderDeliveryStates;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\StateMachine\StateMachineEntity;

class StateMaschineSetup
{
    const STATE_NAME = 'wns_ship_to_store';

    const STATE_NAME_PICKED_UP = 'wns_ship_to_store_picked_up';

    /**
     * @var EntityRepositoryInterface
     */
    private $stateMaschineRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $stateMaschineStateRepository;

    /**
     * @var Connection
     */
    private $connection;

    public function __construct(
        EntityRepositoryInterface $stateMaschineRepository,
        EntityRepositoryInterface $stateMaschineStateRepository,
        Connection $connection
    )
    {
        $this->stateMaschineRepository = $stateMaschineRepository;
        $this->stateMaschineStateRepository = $stateMaschineStateRepository;
        $this->connection = $connection;
    }

    public function setup(Context $context): ?bool
    {
        $stateMachineId = $this->getOrderDeliveryStateMachineId($context);
        if (!$stateMachineId) {
            return null;
        }

        $stateId = $this->getOrderDeliveryStateId($stateMachineId, self::STATE_NAME, $context);
        if (!$stateId) {
            $this->stateMaschineStateRepository->create([
                [
                    'technicalName' => self::STATE_NAME,
                    'stateMachineId' => $stateMachineId,
                    'name' => 'Lieferung in Filiale'
                ]
            ], $context);

            $result = $this->connection->executeQuery('
            SELECT id, technical_name
            FROM state_machine_state
            WHERE HEX(state_machine_id) = :stateMachineId AND (
                technical_name = "open" OR
                technical_name = "cancelled" OR 
                technical_name = :stateName
            )
        ', ['stateMachineId' => strtoupper($stateMachineId), 'stateName' => self::STATE_NAME])->fetchAll();

            $stateIds = [];
            foreach ($result as $row) {
                $stateIds[$row['technical_name']] = $row['id'];
            }

            $this->connection->insert('state_machine_transition',
                [
                    'id' => Uuid::randomBytes(),
                    'state_machine_id' => Uuid::fromHexToBytes($stateMachineId),
                    'action_name' => 'ship_to_store',
                    'from_state_id' => $stateIds['open'],
                    'to_state_id' => $stateIds[self::STATE_NAME],
                    'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT)
                ]
            );
            $this->connection->insert('state_machine_transition',
                [
                    'id' => Uuid::randomBytes(),
                    'state_machine_id' => Uuid::fromHexToBytes($stateMachineId),
                    'action_name' => 'cancel',
                    'from_state_id' => $stateIds[self::STATE_NAME],
                    'to_state_id' => $stateIds['cancelled'],
                    'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT)
                ]
            );
        }

        $stateId = $this->getOrderDeliveryStateId($stateMachineId, self::STATE_NAME_PICKED_UP, $context);
        if (!$stateId) {
            $this->stateMaschineStateRepository->create([
                [
                    'technicalName' => self::STATE_NAME_PICKED_UP,
                    'stateMachineId' => $stateMachineId,
                    'name' => 'Abgeholt in Filiale'
                ]
            ], $context);

            $result = $this->connection->executeQuery('
            SELECT id, technical_name
            FROM state_machine_state
            WHERE HEX(state_machine_id) = :stateMachineId AND (
                technical_name = :stateName OR
                technical_name = :stateNamePickedUp 
            )
        ', ['stateMachineId' => strtoupper($stateMachineId), 'stateName' => self::STATE_NAME, 'stateNamePickedUp' => self::STATE_NAME_PICKED_UP])->fetchAll();

            $stateIds = [];
            foreach ($result as $row) {
                $stateIds[$row['technical_name']] = $row['id'];
            }
            $this->connection->insert('state_machine_transition',
                [
                    'id' => Uuid::randomBytes(),
                    'state_machine_id' => Uuid::fromHexToBytes($stateMachineId),
                    'action_name' => 'picked_up',
                    'from_state_id' => $stateIds[self::STATE_NAME],
                    'to_state_id' => $stateIds[self::STATE_NAME_PICKED_UP],
                    'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT)
                ]
            );
        }

        return true;
    }

    private function getOrderDeliveryStateMachineId($context): ?string
    {
        $criteria = new Criteria();
        $criteria->addFilter(
            new EqualsFilter('technicalName', OrderDeliveryStates::STATE_MACHINE)
        );

        /** @var StateMachineEntity|null $orderTransactionStateMachine */
        $orderDeliveryStateMachine = $this->stateMaschineRepository->search($criteria, $context)->first();
        if (!$orderDeliveryStateMachine) {
            return null;
        }

        return $orderDeliveryStateMachine->getId();
    }

    private function getOrderDeliveryStateId(string $stateMachineId, string $stateName, $context): ?string
    {
        $criteria = new Criteria();
        $criteria->addFilter(
            new EqualsFilter('stateMachineId', $stateMachineId),
            new EqualsFilter('technicalName', $stateName)
        );

        /** @var StateMachineEntity|null $orderTransactionStateMachine */
        $orderDeliveryState = $this->stateMaschineStateRepository->search($criteria, $context)->first();
        if (!$orderDeliveryState) {
            return null;
        }

        return $orderDeliveryState->getId();
    }
}
