<?php declare(strict_types=1);

namespace Wns\Stores\Setup;

use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\System\CustomField\Aggregate\CustomFieldSet\CustomFieldSetEntity;

class CustomFieldSetup
{
    /**
     * @var EntityRepositoryInterface
     */
    private $customFieldSetRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $customFieldRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $customFieldSetRelationRepository;

    public function __construct(
        EntityRepositoryInterface $customFieldSetRepository,
        EntityRepositoryInterface $customFieldRepository,
        EntityRepositoryInterface $customFieldSetRelationRepository
    ) {
        $this->customFieldSetRepository = $customFieldSetRepository;
        $this->customFieldRepository = $customFieldRepository;
        $this->customFieldSetRelationRepository = $customFieldSetRelationRepository;
    }

    /**
     * @param array[] $fieldSets
     * @param InstallContext $setupContext
     */
    public function setup(array $fieldSets, InstallContext $setupContext): void
    {
        foreach ($fieldSets as $fieldSet) {
            $this->upsertCustomFieldSet($fieldSet, $setupContext->getContext());
        }
    }

    /**
     * @param mixed[] $fieldSet
     * @param Context $context
     * @throws InconsistentCriteriaIdsException
     */
    private function upsertCustomFieldSet(array $fieldSet, Context $context): void
    {
        if (!isset($fieldSet['name'])) {
            return;
        }

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('name', $fieldSet['name']));
        $criteria->addAssociation('customFields');
        $criteria->addAssociation('relations');
        $result = $this->customFieldSetRepository->search($criteria, $context);

        $existingCustomFieldIds = [];
        $existingRelationIds = [];
        $existingFieldSets = $result->getEntities()->getElements();

        if (!empty($existingFieldSets)) {
            $existingFieldSet = array_shift($existingFieldSets);

            if ($existingFieldSet instanceof CustomFieldSetEntity) {
                $fieldSet['id'] = $existingFieldSet->getId();
            }

            $existingCustomFields = $existingFieldSet->getCustomFields();

            if ($existingCustomFields !== null) {
                foreach ($existingCustomFields->getElements() as $existingCustomField) {
                    $existingCustomFieldIds[$existingCustomField->getName()] = $existingCustomField->getId();
                }
            }

            $existingRelations = $existingFieldSet->getRelations();
            if ($existingRelations !== null) {
                foreach ($existingRelations->getElements() as $existingRelation) {
                    $existingRelationIds[$existingRelation->getEntityName()] = $existingRelation->getId();
                }
            }
        }

        if (!isset($fieldSet['id'])) {
            $this->customFieldSetRepository->create([$fieldSet], $context);

            return;
        }

        if (isset($fieldSet['customFields']) && is_array($fieldSet['customFields'])) {
            $customFields = $fieldSet['customFields'];

            foreach ($customFields as $index => $customField) {
                $customFields[$index]['customFieldSetId'] = $fieldSet['id'];

                if (isset($existingCustomFieldIds[$customField['name']])) {
                    $customFields[$index]['id'] = $existingCustomFieldIds[$customField['name']];

                    unset($existingCustomFieldIds[$customField['name']]);
                }
            }

            $this->customFieldRepository->upsert($customFields, $context);

            if (!empty($existingCustomFieldIds)) {
                $deleteIds = [];

                foreach ($existingCustomFieldIds as $id) {
                    $deleteIds[] = ['id' => $id];
                }

                $this->customFieldRepository->delete($deleteIds, $context);
            }
        }

        if (isset($fieldSet['relations']) && is_array($fieldSet['relations'])) {
            $relations = $fieldSet['relations'];

            foreach ($relations as $index => $relation) {
                $relations[$index]['customFieldSetId'] = $fieldSet['id'];

                if (isset($existingRelationIds[$relation['entityName']])) {
                    $relations[$index]['id'] = $existingRelationIds[$relation['entityName']];

                    unset($existingRelationIds[$relation['entityName']]);
                }
            }

            $this->customFieldSetRelationRepository->upsert($relations, $context);

            if (!empty($existingRelationIds)) {
                $deleteIds = [];

                foreach ($existingRelationIds as $id) {
                    $deleteIds[] = ['id' => $id];
                }

                $this->customFieldSetRelationRepository->delete($deleteIds, $context);
            }
        }

        unset($fieldSet['customFields'], $fieldSet['relations']);

        $this->customFieldSetRepository->upsert([$fieldSet], $context);
    }
}
