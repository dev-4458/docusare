<?php declare(strict_types=1);

namespace Wns\Stores\Setup;

use Shopware\Core\Checkout\Shipping\ShippingMethodDefinition;
use Shopware\Core\Checkout\Shipping\ShippingMethodEntity;
use Shopware\Core\Content\Rule\RuleEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\DeliveryTime\DeliveryTimeEntity;
use Wns\Stores\WnsStores;

class ShippingSetup
{
    /**
     * @var EntityRepositoryInterface
     */
    private $shippingMethodRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $ruleRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $deliveryTimeRepository;

    public function __construct(
        EntityRepositoryInterface $shippingMethodRepository,
        EntityRepositoryInterface $ruleRepository,
        EntityRepositoryInterface $deliveryTimeRepository
    ) {
        $this->shippingMethodRepository = $shippingMethodRepository;
        $this->ruleRepository = $ruleRepository;
        $this->deliveryTimeRepository = $deliveryTimeRepository;
    }

    public function setup(array $shippingMethod, Context $context): ?string
    {
        if (!isset($shippingMethod['name'])) {
            return null;
        }

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('name', $shippingMethod['name']));
        $result = $this->shippingMethodRepository->search($criteria, $context);

        $existingShippingMethod = $result->getEntities()->first();

        if ($existingShippingMethod instanceof ShippingMethodEntity) {
            $customFields = $existingShippingMethod->getCustomFields();

            if (!(isset($customFields[WnsStores::CUSTOM_FIELD_ACTIVE])
                && $customFields[WnsStores::CUSTOM_FIELD_ACTIVE] === true
            )) {
                $shippingMethod['id'] = $existingShippingMethod->getId();

                $this->shippingMethodRepository->update([$shippingMethod], $context);
            }

            return $existingShippingMethod->getId();
        }

        if (!isset($shippingMethod['availabilityRuleId'])) {
            $rule = $this->ruleRepository->search(new Criteria(), $context)->getEntities()->first();

            if (!$rule instanceof RuleEntity) {
                return null;
            }

            $shippingMethod['availabilityRuleId'] = $rule->getId();
        }

        if (!isset($shippingMethod['deliveryTimeId'])) {
            $deliveryTime = $this->deliveryTimeRepository->search(new Criteria(), $context)->getEntities()->first();

            if (!$deliveryTime instanceof DeliveryTimeEntity) {
                return null;
            }

            $shippingMethod['deliveryTimeId'] = $deliveryTime->getId();
        }

        $result = $this->shippingMethodRepository->create([$shippingMethod], $context);

        $written = $result->getEventByEntityName(ShippingMethodDefinition::ENTITY_NAME);
        $writtenIds = $written->getIds();

        return array_shift($writtenIds);
    }
}
