<?php declare(strict_types=1);

namespace Wns\Stores\Setup;

use Doctrine\DBAL\Connection;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Uuid\Uuid;

class MailTemplateSetup
{
    const STATE_NAME = 'order_delivery.state.wns_ship_to_store';

    /**
     * @var EntityRepositoryInterface
     */
    private $mailTemplateRepository;

    /**
     * @var Connection
     */
    private $connection;

    public function __construct(
        EntityRepositoryInterface $mailTemplateRepository,
        Connection $connection
    )
    {
        $this->mailTemplateRepository = $mailTemplateRepository;
        $this->connection = $connection;
    }

    public function setup(Context $context): ?bool
    {
        $mailTemplateTypeId = $this->getMailTemplateTypeId();
        if (!$mailTemplateTypeId) {

            $mailTemplateTypeId = Uuid::randomBytes();

            $this->connection->insert('mail_template_type', [
                'id' => $mailTemplateTypeId,
                'technical_name' => self::STATE_NAME,
                'available_entities' => json_encode(['order' => 'order']),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ]);

            $this->connection->insert('mail_template_type_translation', [
                'mail_template_type_id' => $mailTemplateTypeId,
                'language_id' => Uuid::fromHexToBytes(Defaults::LANGUAGE_SYSTEM),
                'name' => 'Eintritt Lieferstatus: Filiale',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ]);
        }

        $mailTemplateId = $this->getMailTemplateId($context, $mailTemplateTypeId);
        if (!$mailTemplateId) {

            $this->mailTemplateRepository->create([
                [
                    'mailTemplateTypeId' => Uuid::fromBytesToHex($mailTemplateTypeId),
                    'systemDefault' => false,
                    'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                    'subject' => 'Bestellung in Filiale zur Abholung bereit',
                    'senderName' => '{{ salesChannel.name }}',
                    'contentHtml' => ' ',
                    'contentPlain' => ' '
                ]
            ], $context);
        }

        return true;
    }

    /**
     * @return string|null
     * @throws \Doctrine\DBAL\DBALException
     */
    private function getMailTemplateTypeId()
    {
        return $this->connection->executeQuery('
            SELECT id
            FROM mail_template_type
            WHERE technical_name = :name
        ', ['name' => self::STATE_NAME])->fetchColumn();
    }

    /**
     * @param Context $context
     * @param string $mailTemplateTypeId
     * @return string|null
     */
    private function getMailTemplateId(Context $context, string $mailTemplateTypeId): ?string
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('mailTemplateTypeId', Uuid::fromBytesToHex($mailTemplateTypeId)));
        $criteria->setLimit(1);

        /** @var MailTemplateEntity|null $mailTemplate */
        $mailTemplate = $this->mailTemplateRepository->search($criteria, $context)->first();
        if (!$mailTemplate) {
            return null;
        }

        return $mailTemplate->getId();
    }

}
