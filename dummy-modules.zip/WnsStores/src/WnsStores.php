<?php declare(strict_types=1);

namespace Wns\Stores;

use Doctrine\DBAL\Connection;
use Shopware\Core\Checkout\Order\Aggregate\OrderDelivery\OrderDeliveryStates;
use Shopware\Core\Checkout\Order\Aggregate\OrderTransaction\OrderTransactionStates;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UpdateContext;
use Shopware\Core\System\CustomField\CustomFieldTypes;
use Shopware\Core\System\StateMachine\StateMachineEntity;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Wns\Stores\Setup\CustomFieldSetup;
use Wns\Stores\Setup\MailTemplateSetup;
use Wns\Stores\Setup\ShippingSetup;
use Wns\Stores\Setup\StateMaschineSetup;

class WnsStores extends Plugin
{
    public const CUSTOM_FIELDSET = 'wns_stores';
    public const CUSTOM_FIELD_ACTIVE = self::CUSTOM_FIELDSET . '_active';

    public const SHIPPING_METHOD_NAME = 'Filiallieferung';

    public const SESSION_STORE_ID = 'wnsStoreId';

    private const CUSTOM_FIELDSET_DATA = [
        [
            'name' => self::CUSTOM_FIELDSET,
            'config' => [
                'label' => [
                    'de-DE' => 'Filiallieferung',
                    'en-GB' => 'Store delivery'
                ]
            ],
            'customFields' => [
                [
                    'name' => self::CUSTOM_FIELD_ACTIVE,
                    'type' => CustomFieldTypes::BOOL,
                    'config' => [
                        'componentName' => 'sw-field',
                        'customFieldPosition' => 1,
                        'type' => 'switch',
                        'customFieldType' => 'switch',
                        'label' => [
                            'de-DE' => 'Filial-Auswahl für diese Versandart aktivieren',
                            'en-GB' => 'Activate store selection for this shipping method'
                        ]
                    ]
                ]
            ],
            'relations' => [
                [
                    'entityName' => 'shipping_method'
                ]
            ]
        ]
    ];

    public function install(InstallContext $installContext): void
    {
        $this->installOrUpdate($installContext);

        parent::install($installContext);
    }

    public function update(UpdateContext $updateContext): void
    {
        $this->installOrUpdate($updateContext);

        parent::update($updateContext);
    }

    private function installOrUpdate(InstallContext $installContext): void
    {
        /** @var EntityRepositoryInterface $customFieldSetRepository */
        $customFieldSetRepository = $this->container->get('custom_field_set.repository');
        /** @var EntityRepositoryInterface $customFieldRepository */
        $customFieldRepository = $this->container->get('custom_field.repository');
        /** @var EntityRepositoryInterface $customFieldSetRelationRepository */
        $customFieldSetRelationRepository = $this->container->get('custom_field_set_relation.repository');

        $customFieldSetup = new CustomFieldSetup(
            $customFieldSetRepository,
            $customFieldRepository,
            $customFieldSetRelationRepository
        );

        $customFieldSetup->setup(self::CUSTOM_FIELDSET_DATA, $installContext);

        /** @var EntityRepositoryInterface $shippingMethodRepository */
        $shippingMethodRepository = $this->container->get('shipping_method.repository');
        /** @var EntityRepositoryInterface $ruleRepository */
        $ruleRepository = $this->container->get('rule.repository');
        /** @var EntityRepositoryInterface $deliveryTimeRepository */
        $deliveryTimeRepository = $this->container->get('delivery_time.repository');

        $shippingSetup = new ShippingSetup($shippingMethodRepository, $ruleRepository, $deliveryTimeRepository);

        $shippingMethod = [
            'name' => self::SHIPPING_METHOD_NAME,
            'customFields' => [self::CUSTOM_FIELD_ACTIVE => true]
        ];

        $shippingSetup->setup($shippingMethod, $installContext->getContext());

        /** @var EntityRepositoryInterface $stateMaschineRepository */
        $stateMaschineRepository = $this->container->get('state_machine.repository');
        /** @var EntityRepositoryInterface $stateMaschineStateRepository */
        $stateMaschineStateRepository = $this->container->get('state_machine_state.repository');

        /** @var Connection $connection */
        $connection = $this->container->get('Doctrine\DBAL\Connection');

        $stateMaschineSetup = new StateMaschineSetup($stateMaschineRepository, $stateMaschineStateRepository, $connection);

        $stateMaschineSetup->setup($installContext->getContext());

        /** @var EntityRepositoryInterface $mailTemplateRepository */
        $mailTemplateRepository = $this->container->get('mail_template.repository');

        $mailTemplateSetup = new MailTemplateSetup($mailTemplateRepository, $connection);

        $mailTemplateSetup->setup($installContext->getContext());
    }
}
