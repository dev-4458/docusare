<?php declare(strict_types=1);

namespace Wns\Stores\Subscriber;

use Shopware\Core\Checkout\Cart\Event\CheckoutOrderPlacedEvent;
use Shopware\Core\Checkout\Customer\Aggregate\CustomerAddress\CustomerAddressEntity;
use Shopware\Storefront\Page\Checkout\Cart\CheckoutCartPage;
use Shopware\Storefront\Page\Checkout\Cart\CheckoutCartPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Confirm\CheckoutConfirmPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Finish\CheckoutFinishPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Offcanvas\OffcanvasCartPage;
use Shopware\Storefront\Page\Checkout\Offcanvas\OffcanvasCartPageLoadedEvent;
use Shopware\Storefront\Page\PageLoadedEvent;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Session\Flash\FlashBagInterface;
use Wns\Stores\Custom\Store;
use Wns\Stores\Custom\StoreMissingError;
use Wns\Stores\Custom\StoreService;

class Checkout implements EventSubscriberInterface
{
    /**
     * @var StoreService
     */
    private $storeService;

    /**
     * @var Container
     */
    private $container;

    public function __construct(StoreService $storeService, Container $container)
    {
        $this->storeService = $storeService;
        $this->container = $container;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CheckoutCartPageLoadedEvent::class => 'onCartPageLoaded',
            OffcanvasCartPageLoadedEvent::class => 'onCartPageLoaded',
            CheckoutConfirmPageLoadedEvent::class => 'onCheckoutPageLoaded',
            CheckoutFinishPageLoadedEvent::class => 'onCheckoutPageLoaded',
            CheckoutOrderPlacedEvent::class => 'onCheckoutOrderPlaced'
        ];
    }

    public function onCartPageLoaded(PageLoadedEvent $event): void
    {
        /** @var CheckoutCartPage|OffcanvasCartPage $page */
        $page = $event->getPage();
        $errors = $page->getCart()->getErrors()->getElements();

        foreach ($errors as $key => $error) {
            if ($error instanceof StoreMissingError) {
                $page->getCart()->getErrors()->remove($key);
            }
        }

        /** @var FlashBagInterface $flashBag */
        $flashBag = $this->container->get('session')->getFlashBag();
        $warnings = $flashBag->get('warning');

        $filteredWarnings = [];
        foreach ($warnings as $warning) {
            if ($warning !== 'checkout.store-missing') {
                $filteredWarnings[] = $warning;
            }
        }
        if (!empty($filteredWarnings)) {
            $flashBag->set('warning', $filteredWarnings);
        }
    }

    public function onCheckoutPageLoaded(PageLoadedEvent $event): void
    {
        if (!$this->storeService->isStoreShippingMethod($event->getSalesChannelContext()->getShippingMethod())) {
            return;
        }

        $store = $this->storeService->getCurrentStore($event->getContext());

        if (!$store instanceof Store) {
            return;
        }

        $billingAddress = $event->getSalesChannelContext()->getCustomer()->getActiveBillingAddress();

        if (!$billingAddress instanceof CustomerAddressEntity) {
            $event->getPage()->addExtension('wnsStoreAddress', $store);

            return;
        }

        $storeAddress = clone $billingAddress;

        $this->storeService->mergeCustomerAddressWithStore($storeAddress, $store);

        $event->getPage()->addExtension('wnsStoreAddress', $storeAddress);
    }

    public function onCheckoutOrderPlaced(CheckoutOrderPlacedEvent $event): void
    {
        $this->storeService->modifyOrderShippingAddresses($event->getOrder(), $event->getContext());
    }
}
