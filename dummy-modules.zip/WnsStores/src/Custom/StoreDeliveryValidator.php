<?php declare(strict_types=1);

namespace Wns\Stores\Custom;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Cart\CartValidatorInterface;
use Shopware\Core\Checkout\Cart\Error\ErrorCollection;
use Shopware\Core\System\SalesChannel\SalesChannelContext;

class StoreDeliveryValidator implements CartValidatorInterface
{
    /**
     * @var StoreService
     */
    private $storeService;

    public function __construct(StoreService $storeService)
    {
        $this->storeService = $storeService;
    }

    public function validate(Cart $cart, ErrorCollection $errors, SalesChannelContext $context): void
    {
        foreach ($cart->getDeliveries() as $delivery) {
            if (!$this->storeService->isStoreShippingMethod($delivery->getShippingMethod())) {
                continue;
            }

            if ($this->storeService->getCurrentStore($context->getContext()) !== null) {
                continue;
            }

            $errors->add(
                new StoreMissingError(
                    (string) $delivery->getShippingMethod()->getTranslation('name')
                )
            );
        }
    }
}
