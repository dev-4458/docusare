<?php declare(strict_types=1);

namespace Wns\Stores\Custom;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

/**
 * @method void            add(Store $entity)
 * @method void            set(string $key, Store $entity)
 * @method Store[]    getIterator()
 * @method Store[]    getElements()
 * @method Store|null get(string $key)
 * @method Store|null first()
 * @method Store|null last()
 */
class StoreCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return Store::class;
    }
}
