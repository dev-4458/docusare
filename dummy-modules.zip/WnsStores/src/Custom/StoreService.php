<?php declare(strict_types=1);

namespace Wns\Stores\Custom;

use Doctrine\DBAL\Connection;
use Shopware\Core\Checkout\Customer\Aggregate\CustomerAddress\CustomerAddressEntity;
use Shopware\Core\Checkout\Order\Aggregate\OrderAddress\OrderAddressEntity;
use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Checkout\Shipping\ShippingMethodEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Component\HttpFoundation\Session\Session;
use Wns\Stores\WnsStores;

class StoreService
{
    /**
     * @var EntityRepositoryInterface
     */
    private $storeRepository;

    /**
     * @var EntityRepositoryInterface
     */
    private $orderAddressRepository;

    /**
     * @var Session
     */
    private $session;

    /**
     * @var Connection
     */
    private $connection;

    public function __construct(
        EntityRepositoryInterface $storeRepository,
        EntityRepositoryInterface $orderAddressRepository,
        Session $session,
        Connection $connection
    )
    {
        $this->storeRepository = $storeRepository;
        $this->orderAddressRepository = $orderAddressRepository;
        $this->session = $session;
        $this->connection = $connection;
    }

    public function isStoreShippingMethod(ShippingMethodEntity $shippingMethod): bool
    {
        $customFields = $shippingMethod->getCustomFields();

        return isset($customFields[WnsStores::CUSTOM_FIELD_ACTIVE])
            && $customFields[WnsStores::CUSTOM_FIELD_ACTIVE] === true;
    }

    public function getCurrentStore(Context $context): ?Store
    {
        $storeId = $this->session->get(WnsStores::SESSION_STORE_ID);

        if ($storeId === null) {
            return null;
        }

        $criteria = new Criteria([$storeId]);
        $criteria->addFilter(new EqualsFilter('active', true));
        $criteria->addAssociation('country');

        $result = $this->storeRepository->search($criteria, $context);

        return $result->getEntities()->first();
    }

    public function sortStores(StoreCollection $storeCollection, SalesChannelContext $salesChannelContext): void
    {
        $customer = $salesChannelContext->getCustomer();

        if ($customer === null) {
            return;
        }

        $billingAddress = $customer->getActiveBillingAddress();

        if ($billingAddress === null) {
            return;
        }

        $billingZipcode = $billingAddress->getZipcode();

        $sortedStores = [];

        foreach ($storeCollection->getElements() as $store) {
            $distance = (string)floor($this->getZipcodeDistance($billingZipcode, $store->getZipcode()));
            $sortedStores[str_pad($distance, 10, '0', STR_PAD_LEFT) . $store->getId()] = $store;
        }

        ksort($sortedStores);

        $closestStore = array_shift($sortedStores);
        $sortedIds = [];

        foreach ($sortedStores as $store) {
            $sortedIds[$store->getCity() . $store->getId()] = $store->getId();
        }

        ksort($sortedIds);

        if ($closestStore instanceof Store) {
            array_unshift($sortedIds, $closestStore->getId());
        }

        $storeCollection->sortByIdArray($sortedIds);
    }

    public function modifyOrderShippingAddresses(OrderEntity $order, Context $context): void
    {
        $store = $this->getCurrentStore($context);

        if (!$store instanceof Store) {
            return;
        }

        $addresses = $order->getAddresses();

        if ($addresses === null) {
            return;
        }

        $billingAddress = null;

        foreach ($addresses as $address) {
            if ($address->getId() === $order->getBillingAddressId()) {
                $billingAddress = $address;
                break;
            }
        }

        if ($billingAddress === null) {
            return;
        }

        $deliveries = $order->getDeliveries();

        if ($deliveries === null) {
            return;
        }

        foreach ($deliveries as $delivery) {
            $shippingMethod = $delivery->getShippingMethod();

            if ($shippingMethod === null || !$this->isStoreShippingMethod($shippingMethod)) {
                continue;
            }

            $shippingAddress = clone $delivery->getShippingOrderAddress();

            if (!$shippingAddress instanceof OrderAddressEntity) {
                continue;
            }

            $salutation = $billingAddress->getSalutation();
            if ($salutation !== null) {
                $shippingAddress->setSalutation($salutation);
            }

            $shippingAddress->setSalutationId($billingAddress->getSalutationId());
            $shippingAddress->setTitle($billingAddress->getTitle());
            $shippingAddress->setFirstName($billingAddress->getFirstName());
            $shippingAddress->setLastName($billingAddress->getLastName());

            $this->mergeOrderAddressWithStore($shippingAddress, $store);

            if ($shippingAddress->getId() === $billingAddress->getId()) {
                $orderAddressId = Uuid::randomHex();
                $shippingAddress->setId($orderAddressId);
            } else {
                $orderAddressId = $shippingAddress->getId();
            }

            $this->orderAddressRepository->upsert([[
                'id' => $orderAddressId,
                'orderId' => $order->getId(),
                'company' => $shippingAddress->getCompany(),
                'department' => $shippingAddress->getDepartment(),
                'salutationId' => $shippingAddress->getSalutationId(),
                'title' => $shippingAddress->getTitle(),
                'firstName' => $shippingAddress->getFirstName(),
                'lastName' => $shippingAddress->getLastName(),
                'street' => $shippingAddress->getStreet(),
                'zipcode' => $shippingAddress->getZipcode(),
                'city' => $shippingAddress->getCity(),
                'vatId' => $shippingAddress->getVatId(),
                'countryId' => $shippingAddress->getCountryId(),
                // 'phone_number' => $shippingAddress->getPhoneNumber(),
                'additionalAddressLine1' => $shippingAddress->getAdditionalAddressLine1(),
                'additionalAddressLine2' => $shippingAddress->getAdditionalAddressLine2()
            ]], $context);

            /** @var OrderAddressEntity|null $billingAddress */
            $orderDeliveryAddress = $this->orderAddressRepository->search(new Criteria([$orderAddressId]), $context)->get($orderAddressId);

            $delivery->setShippingOrderAddress($orderDeliveryAddress);
            $delivery->setShippingOrderAddressId($orderAddressId);

            $this->connection->update('order_delivery', ['shipping_order_address_id' => Uuid::fromHexToBytes($orderAddressId)], ['id' => Uuid::fromHexToBytes($delivery->getId())]);

        }
    }

    public function mergeCustomerAddressWithStore(CustomerAddressEntity $address, Store $store): void
    {
        $this->mergeBaseAddressWithStore($address, $store);

        if ($address->getAdditionalAddressLine1() !== null) {
            $address->setAdditionalAddressLine1('');
        }

        if ($address->getAdditionalAddressLine2() !== null) {
            $address->setAdditionalAddressLine2('');
        }
    }

    public function mergeOrderAddressWithStore(OrderAddressEntity $address, Store $store): void
    {
        $this->mergeBaseAddressWithStore($address, $store);

        $address->setCountryStateId(null);
        $address->setVatId(null);
        $address->setPhoneNumber(null);
        $address->setAdditionalAddressLine1(null);
        $address->setAdditionalAddressLine2(null);
    }

    private function mergeBaseAddressWithStore(Entity $address, Store $store): void
    {
        if (!($address instanceof OrderAddressEntity || $address instanceof CustomerAddressEntity)) {
            return;
        }

        $address->setCompany($store->getCompany());
        $address->setDepartment($store->getStoreName());
        $address->setStreet($store->getStreet());
        $address->setZipcode($store->getZipcode());
        $address->setCity($store->getCity());
        $address->setCountryId($store->getCountryId());
        $address->setCountry($store->getCountry());
    }

    private function getZipcodeDistance(string $zipcodeA, string $zipcodeB): float
    {
        $positions = $this->connection->createQueryBuilder()
            ->select('`longitude`, `latitude`')
            ->from('`wns_zipcode`')
            ->where('`zipcode` IN (:zipcodeA, :zipcodeB)')
            ->setParameters(['zipcodeA' => $zipcodeA, 'zipcodeB' => $zipcodeB])
            ->execute()
            ->fetchAll();

        if (count($positions) !== 2) {
            return 99999999.9;
        }

        $earthRadius = 6371000;
        $latFrom = deg2rad((float)$positions[0]['latitude']);
        $lonFrom = deg2rad((float)$positions[0]['longitude']);
        $latTo = deg2rad((float)$positions[1]['latitude']);
        $lonTo = deg2rad((float)$positions[1]['longitude']);

        $lonDelta = $lonTo - $lonFrom;
        $a = pow(cos($latTo) * sin($lonDelta), 2) +
            pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
        $b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);

        $angle = atan2(sqrt($a), $b);

        return $angle * $earthRadius;
    }
}
