<?php declare(strict_types=1);

namespace Wns\Stores\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1593312463StoreEntity extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1593312463;
    }

    public function update(Connection $connection): void
    {
        $query = <<<SQL
CREATE TABLE IF NOT EXISTS `wns_store` (
    `id` BINARY(16) NOT NULL,
    `active` tinyint(1) NOT NULL DEFAULT 0,
    `store_name` VARCHAR(255) NOT NULL,
    `country_id` BINARY(16) NOT NULL,
    `street` VARCHAR(255) NOT NULL,
    `zipcode` VARCHAR(255) NOT NULL,
    `city` VARCHAR(255) NOT NULL,
    `company` VARCHAR(255) NOT NULL,
    `created_at` DATETIME(3) NOT NULL,
    `updated_at` DATETIME(3) NULL,
    PRIMARY KEY (`id`),
    KEY `fk.wns_store.country_id` (`country_id`),
    CONSTRAINT `fk.wns_store.country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
        $connection->executeUpdate($query);
    }

    public function updateDestructive(Connection $connection): void
    {
    }
}
