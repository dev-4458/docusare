<?php declare(strict_types=1);

namespace Wns\Stores\Page;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Page\GenericPageLoaderInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Wns\Stores\Custom\StoreCollection;
use Wns\Stores\Custom\StoreService;
use Wns\Stores\WnsStores;

class StoreListingPageLoader
{
    /**
     * @var GenericPageLoaderInterface
     */
    private $genericLoader;

    /**
     * @var EntityRepositoryInterface
     */
    private $storeRepository;

    /**
     * @var StoreService
     */
    private $storeService;

    /**
     * @var Session
     */
    private $session;

    public function __construct(
        GenericPageLoaderInterface $genericLoader,
        EntityRepositoryInterface $storeRepository,
        StoreService $storeService,
        Session $session
    ) {
        $this->genericLoader = $genericLoader;
        $this->storeRepository = $storeRepository;
        $this->storeService = $storeService;
        $this->session = $session;
    }

    public function load(Request $request, SalesChannelContext $salesChannelContext): StoreListingPage
    {
        $page = $this->genericLoader->load($request, $salesChannelContext);

        $page = StoreListingPage::createFrom($page);

        $page->setStores($this->getStores($salesChannelContext));

        $page->setStore(
            $page->getStores()->get($this->session->get(WnsStores::SESSION_STORE_ID))
        );

        return $page;
    }

    private function getStores(SalesChannelContext $salesChannelContext): StoreCollection
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('active', true));

        /** @var StoreCollection $collection */
        $collection = $this->storeRepository->search($criteria, $salesChannelContext->getContext())->getEntities();

        $this->storeService->sortStores($collection, $salesChannelContext);

        return $collection;
    }
}
