<?php declare(strict_types=1);

namespace Wns\Stores\Page;

use Shopware\Storefront\Page\Page;
use Wns\Stores\Custom\Store;
use Wns\Stores\Custom\StoreCollection;

class StoreListingPage extends Page
{
    /**
     * @var StoreCollection
     */
    protected $stores;

    /**
     * @var Store|null
     */
    protected $store;

    public function getStores(): StoreCollection
    {
        return $this->stores;
    }

    public function setStores(StoreCollection $stores): void
    {
        $this->stores = $stores;
    }

    public function getStore(): ?Store
    {
        return $this->store;
    }

    public function setStore(?Store $store): void
    {
        $this->store = $store;
    }
}
