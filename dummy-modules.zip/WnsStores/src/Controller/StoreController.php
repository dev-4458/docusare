<?php declare(strict_types=1);

namespace Wns\Stores\Controller;

use Shopware\Core\Framework\Routing\Annotation\RouteScope;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\Framework\Validation\DataBag\RequestDataBag;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Routing\Annotation\Route;
use Wns\Stores\Page\StoreListingPageLoader;
use Wns\Stores\WnsStores;

/**
 * @RouteScope(scopes={"storefront"})
 */
class StoreController extends StorefrontController
{
    /**
     * @var StoreListingPageLoader
     */
    private $storeListingPageLoader;

    /**
     * @var Session
     */
    private $session;

    public function __construct(StoreListingPageLoader $storeListingPageLoader, Session $session)
    {
        $this->storeListingPageLoader = $storeListingPageLoader;
        $this->session = $session;
    }

    /**
     * @Route("/widgets/store/address-book", name="frontend.store.addressbook", options={"seo"=true}, methods={"POST"},
     *     defaults={"XmlHttpRequest"=true}
     * )
     */
    public function addressBook(Request $request, RequestDataBag $dataBag, SalesChannelContext $context): Response
    {
        $viewData = [];
        $viewData = $this->handleStoreSelection($viewData, $dataBag);

        $viewData['page'] = $this->storeListingPageLoader->load($request, $context);

        if ($request->get('redirectTo') || $request->get('forwardTo')) {
            return $this->createActionResponse($request);
        }

        return $this->renderStorefront('@Storefront/storefront/component/store-modal.html.twig', $viewData);
    }

    /**
     * @throws InvalidUuidException
     */
    private function handleStoreSelection(array $viewData, RequestDataBag $dataBag): array
    {
        $selectedStoreId = $dataBag->get('selectStoreId');

        if ($selectedStoreId === null) {
            return $viewData;
        }

        if (!Uuid::isValid($selectedStoreId)) {
            throw new InvalidUuidException($selectedStoreId);
        }

        $this->session->set(WnsStores::SESSION_STORE_ID, $selectedStoreId);

        $viewData['success'] = true;

        return $viewData;
    }
}
