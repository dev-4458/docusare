import template from './wns-stores-detail.html.twig';

const { Component, Mixin } = Shopware;

Shopware.Component.register('wns-stores-detail', {
    template,

    inject: [
        'repositoryFactory'
    ],

    mixins: [
        Mixin.getByName('notification')
    ],

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    data() {
        return {
            store: null,
            repository: null,
            isLoading: false,
            processSuccess: false,
        };
    },

    created() {
        this.repository = this.repositoryFactory.create('wns_store');
        this.getStore();
    },

    methods: {

        getStore() {
            this.repository
                .get(this.$route.params.id, Shopware.Context.api)
                .then((entity) => {
                    this.store = entity;
                });
        },

        onClickSave() {
            this.isLoading = true;

            this.repository
                .save(this.store, Shopware.Context.api)
                .then(() => {
                    this.getStore();
                    this.isLoading = false;
                    this.processSuccess = true;
                }).catch((exception) => {
                    this.isLoading = false;
                    this.createNotificationError({
                        title: this.$tc('wns-stores.detail.errorTitle'),
                        message: exception
                    });
            });
        },

        saveFinish() {
            this.processSuccess = false;
        },
    }
});