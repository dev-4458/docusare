Shopware.Component.extend('wns-stores-create', 'wns-stores-detail', {
    methods: {
        getStore() {
            this.store = this.repository.create(Shopware.Context.api);
        },

        onClickSave() {
            this.isLoading = true;

            this.repository
                .save(this.store, Shopware.Context.api)
                .then(() => {
                    this.getStore();
                    this.isLoading = false;
                    this.$router.push({name: 'wns.stores.detail', params: {id: this.store.id}});
                }).catch((exception) => {
                this.isLoading = false;
                this.createNotificationError({
                    title: this.$tc('wns-stores.detail.errorTitle'),
                    message: exception
                });
            });
        },
    }
});