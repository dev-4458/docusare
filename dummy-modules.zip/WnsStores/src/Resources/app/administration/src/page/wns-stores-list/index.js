import template from './wns-stores-list.html.twig';

const Criteria = Shopware.Data.Criteria;

Shopware.Component.register('wns-stores-list', {
    template,

    inject: [
        'repositoryFactory'
    ],

    metaInfo() {
        return {
            title: this.$createTitle()
        };
    },

    data() {
        return {
            repository: null,
            stores: null
        };
    },

    computed: {
        columns() {
            return [{
                property: 'storeName',
                dataIndex: 'storeName',
                label: this.$tc('wns-stores.list.columnName'),
                routerLink: 'wns.stores.detail',
                allowResize: false,
                primary: true
            }]
        }
    },

    created() {
        this.repository = this.repositoryFactory.create('wns_store');

        this.repository
            .search(new Criteria(), Shopware.Context.api)
            .then((result) => {
                this.stores = result;
            });
    },
});