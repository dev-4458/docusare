import './../../page/wns-stores-list';
import './../../page/wns-stores-detail';
import './../../page/wns-stores-create';

import deDE from './snippet/de-DE.json';
import enGB from './snippet/en-GB.json';

Shopware.Module.register('wns-stores', {
    type: 'plugin',
    name: 'wns-stores.general.title',
    title: 'wns-stores.general.title',
    color: '#b5b098',

    snippets: {
        'de-DE': deDE,
        'en-GB': enGB
    },

    routes: {
        list: {
            component: 'wns-stores-list',
            path: 'list'
        },
        detail: {
            component: 'wns-stores-detail',
            path: 'detail/:id',
            meta: {
                parentPath: 'wns.stores.list'
            }
        },
        create: {
            component: 'wns-stores-create',
            path: 'create',
            meta: {
                parentPath: 'wns.stores.list'
            }
        },
    },
    navigation: [{
        label: 'wns-stores.general.title',
        color: '#b5b098',
        path: 'wns.stores.list',
        icon: 'default-building-shop',
        parent: 'sw-extension'
    }]
});