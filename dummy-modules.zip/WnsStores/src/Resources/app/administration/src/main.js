import './module/wns-stores';
