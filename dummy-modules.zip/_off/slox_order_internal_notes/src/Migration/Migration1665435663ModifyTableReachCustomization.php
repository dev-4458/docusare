<?php declare(strict_types=1);

namespace slox\Customization\Migration;

use Shopware\Core\Framework\Migration\MigrationStep;
use Doctrine\DBAL\Connection;

class Migration1665435663ModifyTableReachCustomization extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return (int) 1665435663;
    }

    public function update(Connection $connection): void
	{
        $connection->executeStatement("ALTER TABLE `slox_customization` DROP `version_id`, DROP `order_version_id`;");
        $connection->executeStatement("ALTER TABLE `slox_customization` CHANGE `order_id` `entity_id` BINARY(16) NOT NULL;");
        $connection->executeStatement("ALTER TABLE `slox_customization` ADD `entity_type` VARCHAR(100) NOT NULL AFTER `entity_id`;");
        $connection->executeStatement("UPDATE `slox_customization` SET entity_type = 'order';");
	}

    public function updateDestructive(Connection $connection): void
    {
        // implement update destructive
    }
}
