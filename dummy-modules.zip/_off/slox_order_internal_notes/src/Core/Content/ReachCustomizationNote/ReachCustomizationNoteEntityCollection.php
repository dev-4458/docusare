<?php declare(strict_types=1);

namespace slox\Customization\Core\Content\ReachCustomizationNote;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

class ReachCustomizationNoteEntityCollection extends EntityCollection
{
    protected function getExpectedClass(): string
    {
        return ReachCustomizationNoteEntity::class;
    }
}