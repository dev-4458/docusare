<?php declare(strict_types=1);

namespace slox\Customization\Core\Content\ReachCustomizationNote;

use Shopware\Core\Content\Product\ProductDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToManyAssociationField;


class ReachCustomizationNoteEntityProductExtension extends EntityExtension
{
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            new OneToManyAssociationField('sloxCustomization', ReachCustomizationNoteDefinition::class, 'entity_id', 'id', false),
        );
    }

    public function getDefinitionClass(): string
    {
        return ProductDefinition::class;
    }
}