<?php declare(strict_types=1);

namespace slox\Customization\Core\Content\ReachCustomizationNote;

use Shopware\Core\Checkout\Order\OrderDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\Field\FkField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\PrimaryKey;
use Shopware\Core\Framework\DataAbstractionLayer\Field\Flag\Required;
use Shopware\Core\Framework\DataAbstractionLayer\Field\VersionField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IdField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\LongTextField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ReferenceVersionField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\StringField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\IntField;
use Shopware\Core\Framework\DataAbstractionLayer\Field\ManyToOneAssociationField;

class ReachCustomizationNoteDefinition extends EntityDefinition
{
    public const ENTITY_NAME = 'slox_customization';

    public function getEntityName(): string
    {
        return self::ENTITY_NAME;
    }

    public function getEntityClass(): string
    {
        return ReachCustomizationNoteEntity::class;
    }

    public function getCollectionClass(): string
    {
        return ReachCustomizationNoteEntityCollection::class;
    }

    protected function defineFields(): FieldCollection
    {
        return new FieldCollection([
            (new IdField('id', 'id'))->addFlags(new PrimaryKey(), new Required()),

            (new IdField('entity_id', 'entityId')),
            (new StringField('entity_type', 'entityType')),

            (new StringField('username', 'username')),
            (new LongTextField('note', 'note')),
            (new IntField('show_desktop', 'showDesktop')),
            (new IntField('show_message', 'showMessage')),

            (new ManyToOneAssociationField('order', 'entity_id', OrderDefinition::class, 'id', false)),
        ]);
    }
}