const { Component } = Shopware;
const { Criteria } = Shopware.Data;

import template from './index.html.twig';

Component.register('slox-customization-dashboard', {
    template,

    inject: [
        'repositoryFactory'
    ],

    data() {
        return {
            noteData: [],
            fullyLoaded: false,           
            isLoading: false,
        };
    },

    computed: {
        noteRepository() {
            return this.repositoryFactory.create('slox_customization');
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.isLoading = true;

            this.fullyLoaded = false;
            this.fetchData().then((response) => {
                this.noteData = response;
                this.isLoading = false;
                this.fullyLoaded = true;
            });
        },

        fetchData() {
            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('showDesktop', 1)
            );
            criteria.addSorting(Criteria.sort('createdAt', 'DESC', false));

            return this.noteRepository.search(criteria);
        },

        noteColumns() {
            return [
                {
                    property: 'username',
                    label: this.$tc('slox-customization-note.dashboard.username'),
                    primary: false,
                    allowResize: true
                },
                {
                    property: 'entityType',
                    label: this.$tc('slox-customization-note.dashboard.type'),
                    primary: true,
                    allowResize: true
                },
                {
                    property: 'createdAt',
                    label: this.$tc('slox-customization-note.dashboard.date'),
                    primary: false,
                    allowResize: true
                }
            ];
        },
    },
});