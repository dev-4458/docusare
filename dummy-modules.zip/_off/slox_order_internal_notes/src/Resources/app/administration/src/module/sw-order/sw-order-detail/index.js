import template from './sw-order-detail.html.twig';

const {Component, Context} = Shopware;
const {Criteria} = Shopware.Data;

Component.override('sw-order-detail', {
    template,

    inject: [
        'repositoryFactory'
    ],

    data() {
        return {
            items: null,
        }
    },

    computed: {
        sloxCustomizationRepository() {
            return this.repositoryFactory.create('slox_customization');
        },
    },

    created() {
        this.createdCustomizationComponent();
    },

    methods: {
        createdCustomizationComponent() {
            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('entityId', this.$route.params.id)
            );

            this.sloxCustomizationRepository
            .search(criteria, Shopware.Context.api)
            .then(result => {
                this.items = result;
                document.querySelector(".sloxCustomizationBadge").textContent = this.items.length;
                document.querySelector(".sloxCustomizationBadge").classList.remove('hasCustomizations');
                
                if(this.items.length > 0)
                    document.querySelector(".sloxCustomizationBadge").classList.add('hasCustomizations');
            });
        },
    }
});