import template from './slox-customization-note.html.twig';
import './slox-customization-note.scss';

const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;

Shopware.Component.register('slox-customization-note', {
    template,

    inject: [
        'repositoryFactory',
        'userService'
    ],

    mixins: [
        Mixin.getByName('notification')
    ],

    data() {
        return {
            note: null,
            items: null,
            checkedDesktopItems: [],
            checkedItems: [],
            showButtonForShowMessage: false
        }
    },

    computed: {
        sloxCustomizationRepository() {
            return this.repositoryFactory.create('slox_customization');
        },

        currentUser() {
            return Shopware.State.get('session').currentUser;
        },

        getItems() {
            if (this.items) {
                document.querySelector(".sloxCustomizationBadge").textContent = this.items.length;
                document.querySelector(".sloxCustomizationBadge").classList.remove('hasCustomizations');

                if(this.items.length > 0)
                    document.querySelector(".sloxCustomizationBadge").classList.add('hasCustomizations');

                return this.items;
            }

            return;
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            if (this.$route.meta.entityType == 'customer' || this.$route.meta.entityType == 'product')
                this.showButtonForShowMessage = true;

            this.loadItems();
            return this.items;
        },

        loadItems() {
            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('entityId', this.$route.params.id)
            );
            criteria.addSorting(Criteria.sort('createdAt', 'desc'));

            this.sloxCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    this.items = result;
                    this.items.forEach((value, index) => {
                        if (value.showDesktop == 1)
                            this.checkedDesktopItems.push(value.id);
                            
                        if (value.showMessage == 1)
                            this.checkedItems.push(value.id);
                    });
                });
        },

        onNoteSaveClick() {
            if (this.note == null || this.note.length == 0)
                return;

            this.createNotificationSuccess({ title: this.$tc('slox-customization-note.general.title'), message: this.$tc('slox-customization-note.general.saved') })

            let entity = this.sloxCustomizationRepository.create(Shopware.Context.api);
            entity.entityId = this.$route.params.id;
            entity.entityType = this.$route.meta.entityType;
            entity.username = this.currentUser.lastName;
            entity.note = this.note;

            this.sloxCustomizationRepository.save(entity, Shopware.Context.api).then(result => {
                this.loadItems();
            });

            this.note = '';
        },

        onNoteShowOnDesktopChange(event) {
            let itemId = event.target.value;
            let checked = event.target.checked;

            if (!itemId)
                return;

            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('id', itemId)
            );

            this.sloxCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    result.forEach((entity) => {
                        if (checked == true)
                            entity.showDesktop = 1;
                        else
                            entity.showDesktop = 0;

                        this.sloxCustomizationRepository.save(entity, Shopware.Context.api);
                    });
                });
        },
        
        onNoteShowMessageChange(event) {
            let itemId = event.target.value;
            let checked = event.target.checked;

            if (!itemId)
                return;

            const criteria = new Criteria();
            criteria.addFilter(
                Criteria.equals('id', itemId)
            );

            this.sloxCustomizationRepository
                .search(criteria, Shopware.Context.api)
                .then(result => {
                    result.forEach((entity) => {
                        if (checked == true)
                            entity.showMessage = 1;
                        else
                            entity.showMessage = 0;

                        this.sloxCustomizationRepository.save(entity, Shopware.Context.api);
                    });
                });
        },

        onShowConfirmation(event) {
            event.target.parentNode.style.display = "none";
            event.target.parentNode.nextElementSibling.style.display = "block";
        },

        onDeleteThisNote(event) {
            let itemId = event.target.dataset.id;

            if (!itemId)
                return;

            this.onRestoreConfirmation(event);
            this.sloxCustomizationRepository.delete(itemId, Shopware.Context.api).then(result => {
                this.createNotificationSuccess({ title: this.$tc('slox-customization-note.general.title'), message: this.$tc('slox-customization-note.general.deleted') });
                this.loadItems();
            });
        },

        onRestoreConfirmation(event) {
            event.target.parentNode.parentNode.style.display = "none";
            event.target.parentNode.parentNode.previousElementSibling.style.display = "block";
        }
    }
});