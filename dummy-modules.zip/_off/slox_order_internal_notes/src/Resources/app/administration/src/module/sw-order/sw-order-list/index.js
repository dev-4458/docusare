import template from './sw-order-list.html.twig';

const {Component} = Shopware;
const { Criteria } = Shopware.Data;

Component.override('sw-order-list', {
    template,

    computed: {
        orderCriteria() {
            const criteria = this.$super('orderCriteria');
            criteria.addAssociation('sloxCustomization');
            criteria.getAssociation('sloxCustomization').addSorting(Criteria.sort('createdAt', 'DESC'));
            return criteria;
        }
    },

    methods: {
        getOrderColumns() {
            const columns = this.$super('getOrderColumns');

            columns.push({
                property: 'sloxcustomizationnote',
                label: 'slox-customization-note.general.title',
                allowResize: true,
                primary: false,
            });

            return columns;
        },
    },

});
