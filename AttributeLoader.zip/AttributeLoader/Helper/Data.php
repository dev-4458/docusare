<?php

namespace Custom\AttributeLoader\Helper;

use Laminas\Log\Logger;
use Laminas\Log\Writer\Stream;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context as MageContext;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json as Mage_JSON;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface as StoreManager;

class Data extends AbstractHelper
{
    const XML_GENERAL_ATTRIBUTE_LOADER_STATUS = 'custom_attributeloader/general/enabled';
    const XML_GENERAL_ATTRIBUTE_LOADER_ATTRIBUTE = 'custom_attributeloader/general/attribute';
    const XML_GENERAL_ATTRIBUTE_LOADER_MAIN_IMG = 'custom_attributeloader/general/main_img';
    const XML_GENERAL_ATTRIBUTE_LOADER_LOG = 'custom_attributeloader/general/log';
    const XML_GENERAL_ATTRIBUTE_LOADER_DAY_DIFF = 'custom_attributeloader/general/days';
    const XML_GENERAL_ATTRIBUTE_LOADER_BATCH_LIMIT = 'custom_attributeloader/general/batch';

    /**
     * @var DirectoryList
     */
    protected  $directoryList;

    protected  $storeManager;
    protected  $serialize;
    protected  $request;

    /**
     * @param MageContext $context
     * @param StoreManager $storeManager
     * @param Mage_JSON $serialize
     * @param DirectoryList $directoryList
     */
    public function __construct(
        MageContext $context,
        StoreManager $storeManager,
        Mage_JSON $serialize,
        DirectoryList $directoryList
    ) {
        $this->storeManager = $storeManager;
        $this->serialize = $serialize;
        $this->directoryList = $directoryList;
        parent::__construct($context);
        $this->request = $context->getRequest();
    }

    /**
     * @return int
     * @throws NoSuchEntityException
     */
    public function getStoreid()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function isEnabled()
    {
        return (bool)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_STATUS,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @return string
     * @throws NoSuchEntityException
     */
    public function getSelectedAttributeCode()
    {
        return (string)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_ATTRIBUTE,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @return string
     * @throws NoSuchEntityException
     */
    public function getMainImageAttribute()
    {
        return (string)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_MAIN_IMG,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        ) ?? 'da_media_link';
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function getLogEnabled()
    {
        return (bool)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_LOG,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @return int
     * @throws NoSuchEntityException
     */
    public function getFileDiffDay()
    {
        return (int)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_DAY_DIFF,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    public function getBatchLimit()
    {
        return (int)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_BATCH_LIMIT,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @param $json
     * @param $assoc
     *
     * @return mixed
     */
    public function jsonDecode($json, $assoc = false, $singleFileToImport=null)
    {
        $decode = @json_decode($json, $assoc);
        $error = false;
        switch (json_last_error()) {
            case JSON_ERROR_NONE:
                $error = false;
            break;
            case JSON_ERROR_DEPTH:
                $error = ' - Maximum stack depth exceeded';
            break;
            case JSON_ERROR_STATE_MISMATCH:
                $error = ' - Underflow or the modes mismatch';
            break;
            case JSON_ERROR_CTRL_CHAR:
                $error = ' - Unexpected control character found';
            break;
            case JSON_ERROR_SYNTAX:
                $error = ' - Syntax error, malformed JSON';
            break;
            case JSON_ERROR_UTF8:
                $error = ' - Malformed UTF-8 characters, possibly incorrectly encoded';
            break;
            default:
                $error = ' - Unknown error';
            break;
        }
        
        if(false !== $error) {
            return $error . 'in' . $singleFileToImport;
        }
        if (!$decode) {
            $decode = @json_decode(stripslashes($json), $assoc);
        }

        return $decode;
    }

    /**
     * @return string
     * @throws FileSystemException
     */
    public function getFilePath()
    {
        return $this->directoryList->getPath(DirectoryList::VAR_DIR) .
            DIRECTORY_SEPARATOR . 'importexport' . DIRECTORY_SEPARATOR;
    }

    /**
     * @param string $message
     *
     * @return void
     * @throws NoSuchEntityException
     */
    public function log( $message)
    {
        if (!$this->getLogEnabled()) {
            return;
        }
        $dateToday = date('Y_m_d_H') . '-MediaGallerySave.log';
        $writer = new Stream(BP . '/var/log/image-log/' . $dateToday);
        $logger = new Logger();
        $logger->addWriter($writer);
        $logger->info($message);
    }
}
