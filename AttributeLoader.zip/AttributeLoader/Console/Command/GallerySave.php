<?php

namespace Custom\AttributeLoader\Console\Command;

use Custom\AttributeLoader\Helper\Data;
use Exception;
use Magento\Framework\Console\Cli;
use Magento\Framework\EntityManager\EntityMetadata;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\App\Area;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface as StoreManagerInterface;
use Psr\Log\LoggerInterface as LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Custom\AttributeLoader\Model\GallerySave as CustomModelGallerySave;
use Custom\AttributeLoader\Model\FetchSkus as CustomModelFetchSkus;

class GallerySave extends Command
{
    const AREA_CODE_LOCK_FILE = 'custom_attribute_gallery_save_areacode.lock';
    const STORE_ARGUMENT = 'sku';
    /**
     * @var State
     */
    protected $appState;

    /**
     * @var EntityMetadata
     */
    protected $metadata;

    /**
     * @var State
     */
    protected  $state;

    /**
     * @var StoreManagerInterface
     */
    protected  $storeInterface;

    /**
     * @var DirectoryList
     */
    protected  $directoryList;

    /**
     * @var LoggerInterface
     */
    protected  $logger;

    private  $totalExecutionTime;
    private  $startTime;

    private  $helper;
    private  $customModelGallerySave;
    /**
     * @var CustomModelFetchSkus
     */
    private  $customModelFetchSkus;

    /**
     * @param State $appState
     * @param StoreManagerInterface $storeInterface
     * @param DirectoryList $directoryList
     * @param LoggerInterface $logger
     * @param Data $helper
     * @param CustomModelGallerySave $customModelGallerySave
     * @param CustomModelFetchSkus $customModelFetchSkus
     */
    public function __construct(
        State $appState,
        StoreManagerInterface $storeInterface,
        DirectoryList $directoryList,
        LoggerInterface $logger,
        Data $helper,
        CustomModelGallerySave $customModelGallerySave,
        CustomModelFetchSkus $customModelFetchSkus
    ) {
        $this->appState = $appState;
        $this->storeInterface = $storeInterface;
        $this->directoryList = $directoryList;
        $this->logger = $logger;
        $this->helper = $helper;
        $this->customModelGallerySave = $customModelGallerySave;
        $this->customModelFetchSkus = $customModelFetchSkus;
        parent::__construct();
    }

    /**
     * Initialization of the command.
     */
    protected function configure()
    {
        $this->setName('custom:gallerysave:sku');
        $this->setDescription('will take SKUs(not product ids) will check image and if image exists then save To gallery.');
        $this->setDefinition([
            new InputArgument(
                self::STORE_ARGUMENT,
                InputArgument::OPTIONAL,
                'The sku (comma separated) to save gallery.'
            ),
        ]);
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return int
     * @throws LocalizedException
     * @throws FileSystemException
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->setDecorated(true);
        if (!$this->helper->isEnabled()) {
            $output->writeln(__(
                ' Module is disabled from backend'
            )->getText());

            return Cli::RETURN_SUCCESS;
        }

        $this->startTime = microtime(true);
        $logDir = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $areaCodeFile = $logDir . "/" . self::AREA_CODE_LOCK_FILE;
        try {
            if (file_exists($areaCodeFile)) {
                unlink($areaCodeFile);
            }
            $this->appState->setAreaCode(Area::AREA_FRONTEND);
        } catch (LocalizedException $e) {
            fopen($areaCodeFile, 'w');
            if ($this->appState->getAreaCode() != Area::AREA_FRONTEND) {
                $output->writeln(__(
                    sprintf('Running in an unexpected state AreaCode : (%s)', $this->appState->getAreaCode())
                )->getText());
            }
        }

        $isNullOrMixedList = $this->customModelFetchSkus->execute();
        if(is_array($isNullOrMixedList) || $isNullOrMixedList instanceof Countable) {
            $output->writeln(date('Y-m-d_H:i:s').' => '.count($isNullOrMixedList));
        }
        
        $argSKUs = $input->getArgument(self::STORE_ARGUMENT);
        if ( (null === $isNullOrMixedList || empty($isNullOrMixedList) ) 
            && !$argSKUs) {
            $output->writeln(date('Y-m-d_H:i:s').' => ****_ProgressVideoUpload.txt or ArgumentSKUs are not found.');

            return Cli::RETURN_SUCCESS;
        }
        
        $updateFlag = false;
        if ($isNullOrMixedList) {
            $updateFlag = true;
        }
        $output->writeln(date('Y-m-d_H:i:s').' TYPE: '.gettype($isNullOrMixedList));
        if ($isNullOrMixedList || $argSKUs) {
            //$output->writeln(date('Y-m-dH:i:s').' ArgumentSKUs are not found.');
            //return Cli::RETURN_SUCCESS;
            $argSKUs = $argSKUs =='all' ? $argSKUs : explode(',',$argSKUs);
            $listSkus = $isNullOrMixedList ?: $argSKUs;
        }
        
        if(!$listSkus || empty($listSkus)) {
            $output->writeln(date('Y-m-d_H:i:s').' listSkus are not found.');
            return Cli::RETURN_SUCCESS;
        }
        $output->writeln(date('Y-m-d_H:i:s').'-'. print_r($listSkus,true));
        try {
            $output->writeln("=== Starting process for saving images ===");
            $output->writeln('');

            $this->customModelGallerySave->execute($listSkus, $updateFlag);
        } catch (Exception $e) {
            $output->writeln("");
            $output->writeln("<error>{$e->getMessage()}</error>");

            return Cli::RETURN_FAILURE;
        }
        $this->totalExecutionTime = microtime(true) - $this->startTime;
        $output->writeln('');
        $output->writeln('Completed for all the products || ' . gmdate('H:i:s',
                intval($this->totalExecutionTime)));

        return Cli::RETURN_SUCCESS;
    }
}
