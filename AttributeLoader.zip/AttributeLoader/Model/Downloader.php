<?php

namespace Custom\AttributeLoader\Model;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as Product_Model;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as Magento_CollectionFactory;

class Downloader
{
    private $productCollectionFactory;
    private $productRepository;
    private $filesystem;

    public function __construct(
        Magento_CollectionFactory  $productCollectionFactory,
        ProductRepositoryInterface $productRepository,
        Filesystem                 $filesystem
    )
    {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productRepository = $productRepository;
        $this->filesystem = $filesystem;
    }

    public function execute()
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect(array('id', 'image'));
        $mediapath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();

        $mediapathFile = $mediapath . '/video.mp4';
        foreach ($collection as $productKey => $product) {
            if ($product instanceof Product_Model) {
                if (file_exists($mediapathFile)) {
                    continue;
                }
                $videoVimeo = file_get_contents('');
                file_put_contents($mediapathFile, $videoVimeo);
                if (!$videoVimeo) {
                    continue;
                }
                echo '';
            }


        }
    }
}