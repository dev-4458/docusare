<?php

namespace Custom\AttributeLoader\Model;

use Custom\AttributeLoader\Helper\Data;
use Laminas\Log\Logger;
use Laminas\Log\Writer\Stream;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as Product_Model;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as Magento_CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

class GallerySave
{
    private  $productCollectionFactory;
    private  $productRepository;

    private  $filesystem;

    private  $helper;
    private  $perProductStartTime;
    private  $perProductTotalExecutionTime;
    private  $tmp_catalog_product_dir;
    private  $catalog_product_dir;
    private  $import_dir;
    private  $base_url;
    private  $directoryList;
    private  $storeManager;

    /**
     * @param Magento_CollectionFactory $productCollectionFactory
     * @param ProductRepositoryInterface $productRepository
     * @param Filesystem $filesystem
     * @param Data $helper
     * @param DirectoryList $directoryList
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Magento_CollectionFactory $productCollectionFactory,
        ProductRepositoryInterface $productRepository,
        Filesystem $filesystem,
        Data $helper,
        DirectoryList $directoryList,
        StoreManagerInterface $storeManager
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productRepository = $productRepository;
        $this->filesystem = $filesystem;
        $this->helper = $helper;
        $this->directoryList = $directoryList;
        $this->storeManager = $storeManager;
    }

    /**
     * @throws LocalizedException
     */
    public function execute(
        $skus = null,
        bool $update_via_file_flag = false
    ) {
        $this->helper->log('Started in custom gallery save.');
        $dirImportExport = $this->helper->getFilePath();
        
        $fileProgressName = $dirImportExport . date('Ymd') . '_productProgressGallerySaveLogs.txt';
        //$filesToImport = glob($path);
        
        $failedFileProgress = $dirImportExport . date('Ymd') . '_productFailedLogsOnGallerySave.txt';
        $daMediaLinkAttribute = $this->helper->getMainImageAttribute();

        //will hold values with comma separated paths
        $mediaAttribute = $this->helper->getSelectedAttributeCode();
        $arrayAttributes = ['id', 'sku', 'name', $mediaAttribute, 'da_media_image_filename', $daMediaLinkAttribute];
        //$this->helper->log(print_r($arrayAttributes, true));
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect(
            $arrayAttributes
        );
        $collection->setOrder('entity_id', 'DESC');
        $collection->setFlag('has_stock_status_filter', false);
        if (!empty($skus) && $skus !== 'all') {
            /*$this->helper->log(
                print_r($update_via_file_flag,true)
            );*/
            if ($skus && !$update_via_file_flag) {
                $skus = explode(",", $skus);
                $collection->addAttributeToFilter(
                    'sku', ['in' => [$skus]]
                );
            }
            //This is via File System
            if ($update_via_file_flag) {
                $skus = array_filter($skus);
                $collection->addAttributeToFilter(
                    'sku', ['in' => [$skus]]
                );
            }
        }

        $collection->addMediaGalleryData();
        $this->helper->log(
            $collection->getSelect()->__toString()
        );
        // would be : /home/xxxxx/public_html/pub/media/import
        $mediaPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath() . 'import';

        $media_dir = $this->directoryList->getPath(DirectoryList::MEDIA);
        $this->tmp_catalog_product_dir = $media_dir . DIRECTORY_SEPARATOR . 'tmp' . DIRECTORY_SEPARATOR . 'catalog'
            . DIRECTORY_SEPARATOR . 'product' . DIRECTORY_SEPARATOR;
        $this->catalog_product_dir = $media_dir . DIRECTORY_SEPARATOR . 'catalog' . DIRECTORY_SEPARATOR . 'product'
            . DIRECTORY_SEPARATOR;
        $this->import_dir = $media_dir . DIRECTORY_SEPARATOR . 'import' . DIRECTORY_SEPARATOR;
        $this->base_url = $this->storeManager->getStore()->getBaseUrl();

        foreach ($collection as $productKey => $product) {
            $this->perProductStartTime = microtime(true);
            if (!$product instanceof Product_Model) {
                $this->helper->log('Product not found valid.' . $product->getId());
                continue;
            }

            $proLabel = 'ProductID: ' . $product->getId() . ' || SKU: ' . $product->getSku();
            $this->helper->log('Process started for: ' . $proLabel);
            //will hold values with comma separated paths for given product
            $mediaFileImgOrVideoAttributeValue = $product->getData($mediaAttribute);
            //$mediaFileImgOrVideoAttributeValue = 'http://via.placeholder.com/444.png;http://via.placeholder.com/333.png;http://via.placeholder.com/222.png';
            if (!$mediaFileImgOrVideoAttributeValue) {
                $this->helper->log(
                    'Product value "(' . $mediaAttribute . '=>' . $mediaFileImgOrVideoAttributeValue
                    . ')" found empty or invalid for given product: ' . $proLabel
                );
            }
            $commaImagesURLs = null;
            if ($mediaFileImgOrVideoAttributeValue) {
                $commaImagesURLs = explode(";", $mediaFileImgOrVideoAttributeValue);
                if (!$commaImagesURLs) {
                    $this->helper->log('otherGalleryImg skipping.');
                    continue;
                }
            }
            /*$existingFileNames = [];
            $productExistingImages = $product->getMediaGalleryImages();
            if ($productExistingImages) {
                foreach ($productExistingImages->getItems() as $productImage) {
                    $existingFileNames[] = substr(
                        $productImage->getData('file'),
                        5
                    );
                }
            }
            $this->helper->log(
                print_r($existingFileNames, true)
            );*/

            //Main Single Image
            $mainImgAddedFlag = false;
            $mediaLinkURLValue = $product->getDataUsingMethod($daMediaLinkAttribute);
            //$mediaLinkURLValue = 'http://via.placeholder.com/265.png';
            if ($mediaLinkURLValue && filter_var($mediaLinkURLValue, FILTER_VALIDATE_URL) !== false) {
                $mainImageBaseName = basename($mediaLinkURLValue);
                $mediaPathFile = $mediaPath . '/' . $mainImageBaseName;

                $putStatus = $this->downloadImageIfNotExists(
                    $proLabel,
                    $mediaPathFile,
                    $mediaLinkURLValue,
                    'MainImage'
                );
                if ($putStatus) {
                    try {
                        //$this->saveImageGallery($product, $mediaPathFile, true);
                        $this->setMediaGallery($product, $mainImageBaseName);
                    } catch (\Exception $e) {
                        $this->helper->log($e->getMessage());
                        if ($update_via_file_flag) {
                            file_put_contents($failedFileProgress, PHP_EOL . $product->getSku(), FILE_APPEND | LOCK_EX);
                        }
                        continue;
                    }
                    $this->helper->log('MainImage added to gallery = ' . $mediaPathFile);
                    $mainImgAddedFlag = true;
                } else {
                    $this->helper->log('MainImage not added to gallery = ' . $mediaPathFile);
                }
            } else {
                $this->helper->log('MainImage URL not found valid = ' . $mediaLinkURLValue);
            }

            $otherImgAddedFlag = false;
            //Let's save the media gallery scanning
            if ($commaImagesURLs) {
                foreach ($commaImagesURLs as $commaImageURLKey => $commaImageURL) {
                    if (!$commaImageURL || filter_var($commaImageURL, FILTER_VALIDATE_URL) === false) {
                        $this->helper->log('otherGalleryImg URL not found valid = ' . $commaImageURL);
                        continue;
                    }
                    $otherImageBaseName = basename($commaImageURL);
                    $mediaPathFileLocal = $mediaPath . '/' . $otherImageBaseName;
                    $this->helper->log('otherGalleryImg Looping through, Local Media Path : ' . $mediaPathFileLocal);

                    //if not exists in the import directory
                    $putStatus = $this->downloadImageIfNotExists(
                        $proLabel,
                        $mediaPathFileLocal,
                        $commaImageURL,
                        'otherGalleryImg'
                    );

                    if ($putStatus) {
                        //$this->saveImageGallery($product, $mediaPathFileLocal);
                        try{
                           $this->setMediaGallery(
                                $product,
                                $otherImageBaseName,
                                $commaImageURLKey + 2
                            ); 
                        } catch (\Exception $e) {
                            $this->helper->log($e->getMessage());
                            if ($update_via_file_flag) {
                                file_put_contents($failedFileProgress, PHP_EOL . $product->getSku(), FILE_APPEND | LOCK_EX);
                            }
                            continue;
                        }
                        
                        $this->helper->log('otherGalleryImg added to gallery' . $mediaPathFileLocal);
                        $otherImgAddedFlag = true;
                    } else {
                        $this->helper->log(
                            'otherGalleryImg not added to gallery= ' . $mediaPathFileLocal .
                            ' putStatus= ' . $putStatus .
                            ' fileExists= ' . file_exists($mediaPathFileLocal)
                        );
                        $otherImgAddedFlag = false;
                    }
                }
            }

            try {
                if ($mainImgAddedFlag || $otherImgAddedFlag) {
                    $this->helper->log('Save Action Performed for : ' . $proLabel);
                    //$this->productRepository->save($product);
                    $product->save();
                } else {
                    $this->helper->log('Save Action Skipped for : ' . $proLabel);
                }
            } catch (\Exception $e) {
                $this->helper->log($e->getMessage());
                if ($update_via_file_flag) {
                    file_put_contents($failedFileProgress, PHP_EOL . $product->getSku(), FILE_APPEND | LOCK_EX);
                }
                continue;
            }

            $this->perProductTotalExecutionTime = microtime(true) - $this->perProductStartTime;
            $diff = gmdate('H:i:s', intval($this->perProductTotalExecutionTime));

            $this->helper->log('Took (' . $diff . ') seconds for ' . $proLabel);
            $this->helper->log('****************** END ******************');
            if ($update_via_file_flag) {
                file_put_contents($fileProgressName, PHP_EOL . $product->getSku(), FILE_APPEND | LOCK_EX);
            }
        }
        unset($product);
    }

    private function setMediaGallery(
        Product_Model $product,
        $img,
        $position = 1
    ) {
        $imageCheck = strtolower(strtr($img,
            [' (' => '_', ' ' => '_', ')' => '_']));
        $a = substr($imageCheck,
            0,
            1);
        $b = substr($imageCheck,
            1,
            1);
        $path = strtolower($a . DIRECTORY_SEPARATOR . $b . DIRECTORY_SEPARATOR);
        if (!is_dir($this->tmp_catalog_product_dir . $path)) {
            mkdir($this->tmp_catalog_product_dir . $path,
                0777,
                true);
        }
        $importImage = true;
        $removeImages = [];
        $checkRemoveImages = [];
        $imgInProduct = false;
        if (file_exists($this->import_dir . $img)) {
            $gallery = $product->getMediaGallery();
            /*file_put_contents('/var/www/html/mage-live/ee243/var/log/fileName.txt',
                'destinationFile: ' . print_r($gallery,true) . PHP_EOL,
                FILE_APPEND | LOCK_EX);*/
            if (isset($gallery['images']) && is_array($gallery['images'])) {
                if ($this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck) > 0) {
                    foreach ($gallery['images'] as $image) {
                        if ($this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck,
                            'match',
                            $this->catalog_product_dir . substr($image['file'],
                                1),
                            false)) {
                            $removeImages[] = array_merge($image,
                                ['removed' => '1']);
                            $checkRemoveImages[] = $image['file'];
                        } elseif ($this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck,
                            'match',
                            $this->catalog_product_dir . substr($image['file'],
                                1),
                            true)) {
                            $imgInProduct = true;
                            $importImage = false;
                            if (md5(file_get_contents($this->catalog_product_dir . $path . $imageCheck))
                                != md5(file_get_contents($this->import_dir . $img))) {
                                rename($this->import_dir . $img,
                                    $this->catalog_product_dir . $path . $imageCheck
                                );
                            }
                        } elseif (strtolower($image['file']) == DIRECTORY_SEPARATOR . $path . $imageCheck) {
                            $removeImages[] = array_merge($image,
                                ['removed' => '1']);
                            $checkRemoveImages[] = $image['file'];
                        }
                    }
                    $this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck,
                        'delete',
                        ($imgInProduct
                            ? $this->catalog_product_dir . $path . $imageCheck
                            : false));
                }
            } elseif ($this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck) > 0) {
                $this->_fileExistsRegex($this->catalog_product_dir . $path . $imageCheck,
                    'delete');
            }
        }
        if ($imgInProduct || $importImage || sizeof($removeImages) > 0) {
            do {
                if ($importImage) {
                    if (!file_exists($this->import_dir . $img)) {
                        continue;
                    }
                    rename(
                        $this->import_dir . $img,
                        $this->tmp_catalog_product_dir . $path . $imageCheck
                    );
                    $images = [
                        [
                            'url' => $this->base_url . 'media/tmp/catalog/product/' . $path . $imageCheck,
                            'file' => '/' . $path . $imageCheck,
                            'label' => self::_charsW3cProducts('s' . $position),
                            'position' => $position,
                            'disabled' => '0',
                            'removed' => '0',
                        ],
                    ];
                }

                if ($removeImages) {
                    $images = (isset($images)
                        ? array_merge($images,
                            $removeImages)
                        : $removeImages);
                }
                $image = true;
                $small_image = true;
                $thumbnail = true;

                if ($product->getImage() != 'no_selection' && $product->getImage() != 'true'
                    && $product->getImage() != null) {
                    $image = false;
                }
                if ($product->getSmallImage() != 'no_selection' && $product->getSmallImage() != 'true'
                    && $product->getSmallImage() != null) {
                    $small_image = false;
                }
                if ($product->getThumbnail() != 'no_selection' && $product->getThumbnail() != 'true'
                    && $product->getThumbnail() != null) {
                    $thumbnail = false;
                }
                if ($checkRemoveImages) {
                    if (in_array($product->getImage(),
                        $checkRemoveImages)) {
                        $image = true;
                    }
                    if (in_array($product->getSmallImage(),
                        $checkRemoveImages)) {
                        $small_image = true;
                    }
                    if (in_array($product->getThumbnail(),
                        $checkRemoveImages)) {
                        $thumbnail = true;
                    }
                }

                $values = [];
                if ($image) {
                    $values['image'] = '/' . $path . $imageCheck;
                    $product->setImage('/' . $path . $imageCheck);
                }
                if ($small_image) {
                    $values['small_image'] = '/' . $path . $imageCheck;
                    $product->setSmallImage('/' . $path . $imageCheck);
                }
                if ($thumbnail) {
                    $values['thumbnail'] = '/' . $path . $imageCheck;
                    $product->setThumbnail('/' . $path . $imageCheck);
                }

                $mediaGallery = [];
                if (isset($images)) {
                    $mediaGallery['images'] = json_encode($images);
                }
                if ($values) {
                    $mediaGallery['values'] = json_encode($values);
                }
                $product->setMediaGallery($mediaGallery);
            } while (false);
        }
        $product->save();
    }

    private function downloadImageIfNotExists(
        $proLabel,
        $mediaPathFileLocal,
        $commaImageURL,
        $type = null
    ) {
        $putStatus = false;
        if (!file_exists($mediaPathFileLocal)) {
            $this->helper->log($type . ' File download started : ' . $proLabel);
            $mediaFileImgOrVideo = @file_get_contents($commaImageURL);
            $this->helper->log($type . ' File download complete : ' . $proLabel);
            $imgDownloaded = true;
            if (!$mediaFileImgOrVideo) {
                $this->helper->log($type . ' Media get contents not valid for : ' . $proLabel . ' => '
                    . $commaImageURL);
                $imgDownloaded = false;
            }

            if (true === $imgDownloaded) {
                $this->helper->log($type . ' File put started : ' . $proLabel);
                $putStatus = @file_put_contents($mediaPathFileLocal, $mediaFileImgOrVideo);
                $this->helper->log($type . ' File put complete : ' . $proLabel);
            }
        } else {
            $putStatus = true;
        }

        return $putStatus;
    }

    private function _fileExistsRegex($img, $action = 'count', $other = false, $check = false)
    {
        $name = substr($img,
            0,
            strrpos($img,
                '.'));
        $extension = substr($img,
            strrpos($img,
                '.'));
        $files = glob($name . "*" . $extension);

        if ($action == 'match') {
            if ($check) {
                $match = '';
            } else {
                $match = '_[0-9]+';
            }
            if (is_array($files)) {
                foreach ($files as $file) {
                    if (preg_match('#' . $name . '(' . $match . ')' . $extension . '#',
                        $other)) {
                        return true;
                    }
                }
            }
        } elseif ($action == 'count') {
            return sizeof($files);
        } elseif ($action == 'delete') {
            if (is_array($files)) {
                foreach ($files as $file) {
                    if (!$other || ($other && $file != $img)) {
                        @unlink($file);
                        @unlink(strtr($file,
                            [$this->catalog_product_dir => $this->tmp_catalog_product_dir]));
                    }
                }
            }
        }
    }

    private static function _charsW3cProducts($string)
    {
        if (empty($string) && $string != '0') {
            return false;
        }

        return htmlentities($string,
            ENT_NOQUOTES,
            'UTF-8');
    }

    /**
     * @throws LocalizedException
     * @deprecated
     */
    private function saveImageGallery(
        Product_Model $product,
        $pImgPath,
        $type = null
    ) {
        //if(file_exists($pImgPath)) {
        if ($type == null) {
            $product->addImageToMediaGallery(
                $pImgPath,
                null,
                false,
                false
            );
        } else {
            $product->addImageToMediaGallery(
                $pImgPath,
                ['image', 'small_image', 'thumbnail'],
                false,
                false
            );
        }
        //}
    }
}
