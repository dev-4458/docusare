<?php
/**
 * Copyright © . All rights reserved. See LICENSE.txt for license details.
 */

declare(strict_types=1);

namespace Custom\AttributeLoader\Model;

use Custom\AttributeLoader\Helper\Data;
use Custom\AttributeLoader\Model\GallerySave as CustomModelGallerySave;
use Magento\Framework\Exception\NoSuchEntityException;

class FetchSkus
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * @var GallerySave
     */
    private $customModelGallerySave;

    /**
     * @param GallerySave $customModelGallerySave
     * @param Data $helper
     */
    public function __construct(
        CustomModelGallerySave $customModelGallerySave,
        Data $helper
    ) {
        $this->customModelGallerySave = $customModelGallerySave;
        $this->helper = $helper;
    }

    /**
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $dirImportExport = $this->helper->getFilePath();
        //Let's scan the files using glob directory
        $path = $dirImportExport . '*_ProgressVideoUpload.txt';
        $filesToImport = glob($path);
        if (empty($filesToImport)) {
            $this->helper->log('File(s) pattern wise not found : ');
            return null;
        }
        $products_to_update = null;

        //Below is the progress file where completed SKUs were written
        //$fileProgressName = $dirImportExport . date('Ymd') . '_productProgressGallerySaveLogs.txt';
        $fileProgressNamePath = $dirImportExport  . '*_productProgressGallerySaveLogs.txt';
        $fileProgressNames = glob($fileProgressNamePath);
        $fileProgressData = [];
        foreach($fileProgressNames as $singleProgressFileName) {
           if (!file_exists($singleProgressFileName)) {
                $this->helper->log('Progress File is not exists: ' . $singleProgressFileName);
                continue;
            }
            $fileProgressData[] = array_filter(
                explode("\n", file_get_contents($singleProgressFileName))
            );
        }
        //$fileProgressData = array_unique( array_reduce($fileProgressData, 'array_merge', []));
        $fileProgressData = array_merge(...$fileProgressData);
        
        $failedFileProgress = $dirImportExport . date('Ymd') . '_productFailedLogsOnGallerySave.txt';
        $fileSKUsToTake = $dirImportExport . 'skusToTakeOnePerLine.txt';
        foreach ($filesToImport as $singleFileToImport) {
            if (!file_exists($singleFileToImport)) {
                $this->helper->log('File is not exists: ' . $singleFileToImport);
                $fileExitsFlag = false;
                continue;
            }

            //Last Modified Date
            $mdate = date("Ymd", filemtime($singleFileToImport));
            $dayDiff = $this->helper->getFileDiffDay();
            $sliceLimit = $this->helper->getBatchLimit();
            if ($sliceLimit > 15) {
                $sliceLimit = 15;
            }

            //Current Date
            $currentDate = date("Ymd");

            $this->helper->log('File difference: ' . ($currentDate - $mdate) . ' day(s) for ' . $singleFileToImport);
            //Skip those files older than 1 day
            if ($mdate && ($currentDate - $mdate) > $dayDiff) {
                $this->helper->log('File skipping due to old: ' . ($currentDate - $mdate) . ' for '
                    . $singleFileToImport);
                continue;
            }
            $fileData = file_get_contents($singleFileToImport);
            if ($singleFileToImport && $fileData) {
                $this->helper->log('File is exists: ' . $singleFileToImport);

                //Associated array
                $idsDecodeList = $this->helper->jsonDecode($fileData, true, $singleFileToImport );
                //$this->helper->log(print_r($idsDecodeList,true));
                if (!is_array($idsDecodeList) || [] == $idsDecodeList) {
                    $this->helper->log(print_r($idsDecodeList,true));
                    continue;
                }
                //$this->helper->log($singleFileToImport);
                $orgCount = is_array($idsDecodeList) || $idsDecodeList instanceof Countable
                    ? count($idsDecodeList)
                    : 0;
                $this->helper->log('Total No of SKUs COUNT: ' . $orgCount);

                //Will merge
                if ($fileSKUsToTake && file_exists($fileSKUsToTake)) {
                    $fileSKUsToTakeData = explode("\n", file_get_contents($fileSKUsToTake));
                    $idsDecodeList = array_merge($idsDecodeList, array_unique($fileSKUsToTakeData));
                }
                
                //Will remove already done ones
                if (is_array($fileProgressData) && !empty($fileProgressData)) {
                    //$fileProgressData = explode("\n", file_get_contents($fileProgressName));
                    $idsDecodeList = array_diff($idsDecodeList, array_unique($fileProgressData));
                }
                
                //Will remove failed ones
                if ($failedFileProgress && file_exists($failedFileProgress)) {
                    $failedFileProgressData = explode("\n", file_get_contents($failedFileProgress));
                    $idsDecodeList = array_diff($idsDecodeList, array_unique($failedFileProgressData));
                }
                $countFruits = is_array($idsDecodeList) || $idsDecodeList instanceof Countable
                    ? count($idsDecodeList)
                    : 0;
                $this->helper->log(' ******************** Latest Size(To Consider for import): ' . $countFruits.' ********************');
                //AVG time is 4 min 50 secs for 40 SKUs, CRON runs every 7 min.
                if ($countFruits > $sliceLimit) {
                    $products_to_update[] = array_slice($idsDecodeList, 0, $sliceLimit);
                } else {
                    $products_to_update[] = $idsDecodeList;
                }
                $fileExitsFlag = true;
            }
        }
        
        //This is to prevent multiple blank array
        $products_to_update = is_array($products_to_update) 
            ? array_filter($products_to_update)
            : $products_to_update;
            
        if(null === $products_to_update || empty($products_to_update)) {
            $this->helper->log(' ******************** Either SKUs Queue is cleared or No SKUs found ******************** ');
            return null;
        }
        
        return $products_to_update;
    }
}
