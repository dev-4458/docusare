---
title: Qalyptus On-Demand
---

À l’aide de l’extension Qlik Sense Qalyptus On-Demand, vous pouvez générer vos rapports créés avec Qalyptus directement à partir d’une application Qlik Sense.

Qalyptus utilise le profil utilisateur Qlik Sense pour générer le rapport. En d’autres termes, Qalyptus prendra en compte les Session Access existantes dans l’application lors de la génération du rapport. Si, par exemple, l’utilisateur n’a accès qu’aux données de son service, lors de la génération du rapport, seules les données de son service seront visibles sur le rapport.

Notez que vous devez ajouter le compte de domaine (DOMAIN\username) de [l’utilisateur dans ses informations](/products/qalyptus/qalyptus-server/qalyptus-administration/user-management/qalyptus-users).

## Présentation de Qalyptus On-Demand

<iframe width="560" height="315" src="https://www.youtube.com/embed/0SVACyVLoAs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Configurer Qalyptus On-Demand

Qalyptus On-Demand a besoin de Qalyptus Server pour générer les rapports. Avant d’utiliser Qalyptus On-Demand, vous devez installer et configurer Qalyptus Server. Découvrez [comment installer Qalyptus Server](/products/qalyptus/deploying-qalyptus/install-qualyptus-server).

:::note
Ou trouver l’extension Qalyptus On-Demand ? Après installation de Qalyptus Server vous trouverez Qalyptus On-Demand dans le dossier : C:\ProgramData\Qalyptus\Extensions
:::

### 1- Autoriser l’utilisation de Qalyptus On-Demand

Qalyptus On-Demand est une extension Qlik Sense qui utilise l’API Qalyptus pour communiquer avec Qalyptus Server. Pour des raisons de sécurité, vous devez ajouter l’adresse Qlik Sense comme origine de confiance, choisir les utilisateurs qui seront autorisés à utiliser Qalyptus On-Demand et choisir les rapports que vous souhaitez rendre visibles aux utilisateurs sur Qalyptus On-Demand.

### 1-1 Ajouter l’adresse Qlik Sense en tant qu’origine autorisée

A chaque fois que vous souhaitez communiquer avec Qalyptus Server depuis une autre application web, vous devez ajouter l’adresse de cette application dans la liste des origines de autorisées.

Pour ajouter l’adresse Qlik Sense en tant qu’origine autorisée dans Qalyptus Server, procédez comme suit :

- Se connecter au Qalyptus Server
- Aller à Administration Qalyptus> Système> **Origines Autorisées**
- Cliquez sur **Ajouter Origine**
- Entrez un nom pour l’origine
- Saisissez une description (facultatif)
- Saisissez l’adresse de votre Qlik Sense. Exemple : https://qlik-sense-url.com
- Cliquez sur **Enregistrer**

![Add trusted origin](/img/docs-images/qalyptus-server-add-trusted-origin.png)

### 1-2 Attribuer des autorisations aux utilisateurs

Pour les utilisateurs que vous souhaitez autoriser à utiliser Qalyptus On-Demand, vous devez leur attribuer un Rôle contenant l’autorisation **« Restrictions pour API et rapports à la demande »**.

Pour plus de détails sur la création et l’attribution d’un rôle aux utilisateurs, consultez la section : [Rôles de sécurité](/products/qalyptus/qalyptus-server/qalyptus-administration/system/security-roles).

![API permissions](/img/docs-images/qalyptus-server-api-permissions.png)

### 1-3 Rendre des rapports disponibles pour Qalyptus On-Demand

Par défaut, les rapports ne sont pas visibles dans Qalyptus On-Demand. Pour chaque rapport, vous devez choisir les utilisateurs qui peuvent le visualiser et le générer dans Qalyptus On-demand.

Pour choisir les utilisateurs pouvant afficher et générer un rapport dans Qalyptus On-Demand, procédez comme suit :

- Se connecter à Qalyptus Server
- Accédez à la page **Rapports**
- Modifiez le rapport que vous souhaitez rendre visible pour les utilisateurs. Exemple : **Sales analysis**
- Sélectionnez l’onglet API et restrictions de rapport à la demande
- Cliquez sur **Ajouter Utilisateurs** ou **Ajouter Groupes**
- Ajouter des utilisateurs et/ou des groupes. Si vous souhaitez autoriser tous les utilisateurs, choisissez le groupe par défaut “All users”.
- Cliquez sur **Enregistrer**

![Qalyptus Server On Demand User](/img/docs-images/qalyptus-server-on-demand-users.png)

### 2- Importer Qalyptus On-Demand dans Qlik Sense QMC

Pour utiliser l’extension Qalyptus On-Demand dans Qlik Sense, vous devez l’importer dans Qlik Sense QMC. Qalyptus On-Demand est un fichier zip que vous pouvez trouver sur la machine où Qalyptus Server est installé à cet emplacement : “C:\ProgramData\Qalyptus\Extensions” ou dans votre compte Qalyptus, dans la page de [téléchargement](https://my.qalyptus.com/my-account/download-archives/).

Pour importer Qalyptus On-Demand dans QMC, procédez comme suit :

- Connectez-vous à Qlik Sense QMC en tant qu’administrateur
- Allez à la page Extensions
- Cliquez sur Import
- Accédez au fichier zip Qalyptus On-Demand
- Cliquez sur Import

![Import on demand](/img/docs-images/qalyptus-server-import-qalyptus-on-demand.png)

Désormais, Qalyptus On-Demand est prêt à être utilisé dans les feuilles Qlik Sense.

### 3- Ajouter Qalyptus On-Demand à une feuille Qlik Sense

Pour utiliser Qalyptus On-Demand, vous devez l’ajouter à une feuille Qlik Sense. Qalyptus On-Demand apparaît dans une feuille sous forme de bouton.

Pour ajouter Qalyptus On-Demand à une feuille, procédez comme suit:

- Ouvrez une feuille Qlik Sense pour laquelle vous disposez de droits de modification
- Cliquez sur Modifier la feuille, en haut à droite
- Dans la zone de gauche, allez dans Objets personnalisés> Qalyptus bundle
- Glissez-déposez Qalyptus On-Demand

![Drag and drop on demand](/img/docs-images/qalyptus-server-drag-and-drop-qalyptus-on-demand.png)

Nous devons maintenant configurer Qalyptus On-demand pour communiquer avec Qalyptus Server.

En mode édition de la feuille Qlik Sense, sélectionnez le bouton Qalyptus On-Demand pour commencer la configuration..

![On Demand Edit Mode](/img/docs-images/qalyptus-serverqalyptus-on-demand-edit-mode.png)

### Authentication section

- Ajoutez votre adresse de serveur Qalyptyus. Exemple : https://qalyptus-server-url.com:3994
- Choisissez la méthode d’authentification parmi les méthodes disponibles :
  - Authentification Windows (nom d’utilisateur et mot de passe Windows de l’utilisateur) : disponible avec Qalyptus Server Enterprise et Qalyptus Server Ultimate
  - Identifiants Qalyptus (email et mot de passe d’un utilisateur créé dans Qalyptus Server) : disponibles avec Qalyptus Server Business, Qalyptus Server Enterprise et Qalyptus Server Ultimate
  - SSO avec SAML (un utilisateur s’authentifie à l’aide d’un [Fournisseur d’Identité](/products/qalyptus/qalyptus-server/qalyptus-administration/system/identity-providers) configuré) : disponible avec Qalyptus Server Ultimate

![Qalyptus Server On Demand Auth Options](/img/docs-images/qalyptus-server-qalyptus-on-demand-auth-options.png)

### Section Paramètres

- Ignorer les filtres de rapport existants : Si vous cochez cette option, si un utilisateur exécute un rapport contenant un filtre, Qalyptus n’appliquera pas le filtre défini dans le rapport. Qalyptus appliquera que les sélections actuelles s’il y en a.
  Si l’option n’est pas cochée et que l’utilisateur effectue des sélections, Qalyptus ajoutera les sélections en tant que filtres aux filtres de rapport existants. L’ordre des filtres étant important, les sélections seront ajoutées après les filtres de rapport existants.
- Remplacer l’application de rapport par l’application en cours: pour que les sélections actuelles soient prises en compte lors de la génération d’un rapport, le rapport doit être créé avec une application Qlik Sense dont l’ID est le même que celui de l’application en cours. Cochez cette option si vous souhaitez que Qalyptus remplace l’ID d’application utilisé dans les rapports par l’ID d’application actuel. Utilisez cette option uniquement si l’application en cours contient les mêmes objets que l’application utilisée pour créer le rapport.
  Exemples:

  Exemple 1 : Vous avez créé un rapport à l’aide de l’application app1 (ID=xxx) publiée dans le flux S1. Cette même application existe dans le flux S2 avec un ID=yyy, et vous souhaitez générer un rapport avec les sélections actuelles depuis l’application avec ID=yyy.

  Exemple 2 : Vous avez créé un rapport en utilisant l’application app1 (ID=xxx) ; vous souhaitez générer un rapport avec les sélections en cours à partir d’une application générée avec la méthode ODAG (On-Demand App Generation). La nouvelle application généré avec ODAG aura un identifiant différent.

### Rubrique Apparence

Dans cette section, vous pouvez personnaliser le libellé et le design du bouton Qalyptus On-Demand.

### 4- Use Qalyptus On-Demand

### Authentification

Dans la feuille Qlik Sense, cliquez sur le bouton Qalyptus On-Demand. La première fois, l’utilisateur doit s’authentifier avec la méthode d’authentification choisie.

- Si la méthode d’authentification est l’authentification Windows, l’utilisateur doit saisir ses identifiants Windows : nom d’utilisateur au format DOMAINE\nom d’utilisateur et son mot de passe Windows.
- Si la méthode d’authentification est les identifiants Qalyptus, l’utilisateur doit exister dans Qalyptus Server et créer un mot de passe. L’utilisateur doit utiliser son email et le mot de passe créé. Si l’utilisateur existe dans Qalyptus Server et n’a pas encore créé de mot de passe, il peut générer un mot de passe sur la page de connexion de Qalyptus Server en cliquant sur le lien Mot de passe oublié?
- Si la méthode d’authentification est SSO avec SAML, si vous avez configuré un fournisseur d’identité dans Qalyptus Server, l’utilisateur sera automatiquement redirigé vers la page de connexion du fournisseur d’identité. Si vous avez configuré plusieurs fournisseurs d’identité, l’utilisateur verra un bouton de connexion pour chaque fournisseur d’identité.

### Générer un rapport

Après authentification, l’utilisateur verra la liste des rapports auxquels il a droit.

Pour générer un rapport, choisissez un rapport dans la liste des rapports, cliquez sur **Run now** et choisissez le format de sortie.

Suivez le statut d’exécution dans l’onglet **Status**. A la fin de l’exécution, vous pouvez télécharger le rapport, supprimer l’entrée d’exécution ou relancer le rapport.

![Qalyptus On Demand Overview](/img/docs-images/qalyptus-on-demand-overview.png)

Les administrateurs Qalyptus peuvent gérer les exécutions de rapports dans Qalyptus Server. Si l’exécution a échoué, vous pouvez accéder au fichier journal pour en savoir plus sur l’erreur.

Pour accéder au statut d’exécution dans Qalyptus Server, accédez à la page **Statut > Requêtes à la demande**.

![Qalyptus On Demand Status](/img/docs-images/qalyptus-server-qalyptus-on-demand-status.png)
