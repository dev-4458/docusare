---
title: Qalyptus Self-Reporting
---

**Qalyptus Self-Reporting** est une extension qui s’intègre parfaitement dans Qlik Sense. Elle permet aux utilisateurs de créer des tâches avec des rapports en illimité dans différents formats (PDF, Excel, PowerPoint, ..), ajouter différents filtres pour chaque rapport (sélections en cours ou un favori), ajouter un nombre illimité de destinataires, personnaliser le message e-mail, intégrer des graphiques et des tableaux dans le message e-mail et choisir la fréquence d’exécution.

## Présentation de Qalyptus Self-Reporting

<iframe width="560" height="315" src="https://www.youtube.com/embed/wKdhuih7_uE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Configurer Qalyptus Self-Reporting

Qalyptus Self-Reporting a besoin de Qalyptus Server pour générer les rapports. Avant d’utiliser Qalyptus Self-Reporting, vous devez [télécharger](https://www.qalyptus.com/products/download-qalyptus-server), installer et configurer Qalyptus Server. Découvrez [ comment installer Qalyptus Server](/products/qalyptus/deploying-qalyptus/install-qualyptus-server).

### 1- Autoriser l’utilisation de Qalyptus Self-Reporting

Qalyptus Self-Reporting est une extension Qlik Sense qui utilise l’API Qalyptus pour communiquer avec Qalyptus Server. Pour des raisons de sécurité, vous devez ajouter l’adresse Qlik Sense comme origine de confiance, choisir les utilisateurs qui seront autorisés à utiliser Qalyptus Self-Reporting et choisir les rapports que vous souhaitez rendre visibles aux utilisateurs sur Qalyptus Self-Reporting.

### 1-1 Ajouter l’adresse Qlik Sense en tant qu’origine autorisé

A chaque fois que vous souhaitez communiquer avec Qalyptus Server depuis une autre application web, vous devez ajouter l’adresse de cette application dans la liste des origines de autorisées.

Pour ajouter l’adresse Qlik Sense en tant qu’origine autorisée dans Qalyptus Server, procédez comme suit :

- Se connecter au Qalyptus Server
- Aller à Administration Qalyptus> Système> Origines Autorisées
- Cliquez sur Ajouter Origine
- Entrez un nom pour l’origine
- Saisissez une description (facultatif)
- Saisissez l’adresse de votre Qlik Sense. Exemple : https://qlik-sense-url.com
- Cliquez sur Enregistrer

![Qalyptus Server Add Trusted Origin](/img/docs-images/qalyptus-server-add-trusted-origin.png)

### 1-2 Attribuer des autorisations aux utilisateurs

Pour les utilisateurs que vous souhaitez autoriser à utiliser Qalyptus Self-Reporting, vous devez leur attribuer un Rôle contenant l’autorisation **« Restrictions pour API et rapports à la demande »**.

Pour plus de détails sur la création et l’attribution d’un rôle aux utilisateurs, consultez la section : [Rôles de sécurité.](/products/qalyptus/qalyptus-server/qalyptus-administration/system/security-roles).

![Qalyptus Server API Permissions](/img/docs-images/qalyptus-server-api-permissions.png)

### 1-3 Rendre des rapports disponibles pour Qalyptus Self-Reporting

Par défaut, les rapports ne sont pas visibles dans Qalyptus Self-Reporting. Pour chaque rapport, vous devez choisir les utilisateurs qui peuvent le visualiser et le générer dans Qalyptus Self-Reporting.

Pour choisir les utilisateurs pouvant afficher et générer un rapport dans Qalyptus Self-Reporting, procédez comme suit :

- Se connecter à Qalyptus Server
- Accédez à la page **Rapports**
- Modifiez le rapport que vous souhaitez rendre visible pour les utilisateurs. Exemple : **Sales analysis**
- Sélectionnez l’onglet API et restrictions de rapport à la demande
- Cliquez sur **Ajouter Utilisateurs** ou **Ajouter Groupes**
- Ajouter des utilisateurs et/ou des groupes. Si vous souhaitez autoriser tous les utilisateurs, choisissez le groupe par défaut “All users”.
- Cliquez sur **Enregistrer**

![Qalyptus Server On Demand User](/img/docs-images/qalyptus-server-on-demand-users.png)

### 1-4 Attribuer une licence à un utilisateur

Un utilisateur doit avoir une licence pour utiliser Qalyptus Self-Reporting. Pour attribuer une licence à un utilisateur, ajoutez l’utilisateur au groupe **« Qalyptus Self-Reporting »**.

Le nombre d’utilisateurs que vous pouvez ajouter au groupe **Qalyptus Self-Reporting** ne peut pas dépasser le nombre d’utilisateurs prévu dans votre licence Qalyptus Self-reporting.
Vous pouvez modifier les membres du groupe à tout moment si, par exemple, vous souhaitez désallouer la licence d’un utilisateur et l’attribuer à un autre.

### 2- Importer Qalyptus Self-Reporting dans Qlik Sense QMC

Pour utiliser l’extension Qalyptus Self-Reporting dans Qlik Sense, vous devez l’importer dans Qlik Sense QMC. Qalyptus Self-Reporting est un fichier zip que vous pouvez trouver sur la machine où Qalyptus Server est installé à cet emplacement : “C:\ProgramData\Qalyptus\Extensions” ou dans votre compte Qalyptus, dans la page de [téléchargement](https://my.qalyptus.com/my-account/download-archives/).

Pour importer Qalyptus Self-Reporting dans QMC, procédez comme suit :

- Connectez-vous à Qlik Sense **QMC** en tant qu’administrateur
- Allez à la page **Extensions**
- Cliquez sur **Import**
- Accédez au fichier zip Qalyptus Self-Reporting
- Cliquez sur **Import**

![Qalyptus Server Import Qalyptus Self Reporting](/img/docs-images/qalyptus-server-import-qalyptus-self-reporting.png)

Désormais, Qalyptus Self-Reporting est prêt à être utilisé dans les feuilles Qlik Sense.

### 3- Ajouter Qalyptus Self-Reporting à une feuille Qlik Sense

Pour utiliser Qalyptus Self-Reporting, vous devez l’ajouter à une feuille Qlik Sense. Qalyptus Self-Reporting apparaît dans une feuille sous forme de bouton.

Pour ajouter Qalyptus Self-Reporting à une feuille, procédez comme suit :

- Ouvrez une feuille Qlik Sense pour laquelle vous disposez de droits de modification
- Cliquez sur **Modifier la feuille**, en haut à droite
- Dans la zone de gauche, allez dans Objets personnalisés> **Qalyptus bundle**
- Glissez-déposez Qalyptus Self-Reporting

![Qalyptus Server Drag and Drop Qalyptus Self Reporting](/img/docs-images/qalyptus-server-drag-and-drop-qalyptus-self-reporting.png)

Nous devons maintenant configurer Qalyptus Self-Reporting pour communiquer avec Qalyptus Server.

En mode édition de la feuille Qlik Sense, sélectionnez le bouton Qalyptus Self-Reporting pour commencer la configuration.

![Qalyptus Server Self Reporting Edit Mode](/img/docs-images/qalyptus-server-qalyptus-self-reporting-edit-mode.png)

### Section Authentification

- Ajoutez votre adresse de serveur Qalyptyus. Exemple : https://qalyptus-server-url.com:3994
- Choisissez la méthode d’authentification parmi les méthodes disponibles :
  - Authentification Windows (nom d’utilisateur et mot de passe Windows de l’utilisateur) : disponible avec Qalyptus Server Enterprise et Qalyptus Server Ultimate
  - Identifiants Qalyptus (email et mot de passe d’un utilisateur créé dans Qalyptus Server) : disponibles avec Qalyptus Server Business, Qalyptus Server Enterprise et Qalyptus Server Ultimate
  - SSO avec SAML (un utilisateur s’authentifie à l’aide d’un [ Fournisseur d’Identité](/products/qalyptus/qalyptus-server/qalyptus-administration/system/identity-providers) configuré) : disponible avec Qalyptus Server Ultimate

![Qalyptus Server On Demand Auth Options](/img/docs-images/qalyptus-server-qalyptus-on-demand-auth-options.png)

### Settings section

- Ignorer les filtres de rapport existants : Si vous cochez cette option, si un utilisateur exécute un rapport contenant un filtre, Qalyptus n’appliquera pas le filtre défini dans le rapport. Qalyptus appliquera que les sélections actuelles s’il y en a.
  Si l’option n’est pas cochée et que l’utilisateur effectue des sélections, Qalyptus ajoutera les sélections en tant que filtres aux filtres de rapport existants. L’ordre des filtres étant important, les sélections seront ajoutées après les filtres de rapport existants.
- Remplacer l’application de rapport par l’application en cours: pour que les sélections actuelles soient prises en compte lors de la génération d’un rapport, le rapport doit être créé avec une application Qlik Sense dont l’ID est le même que celui de l’application en cours. Cochez cette option si vous souhaitez que Qalyptus remplace l’ID d’application utilisé dans les rapports par l’ID d’application actuel. Utilisez cette option uniquement si l’application en cours contient les mêmes objets que l’application utilisée pour créer le rapport.

  Exemples:

  Exemple 1 : Vous avez créé un rapport à l’aide de l’application app1 (ID=xxx) publiée dans le flux S1. Cette même application existe dans le flux S2 avec un ID=yyy, et vous souhaitez générer un rapport avec les sélections actuelles depuis l’application avec ID=yyy.

  Exemple 2 : Vous avez créé un rapport en utilisant l’application app1 (ID=xxx) ; vous souhaitez générer un rapport avec les sélections en cours à partir d’une application générée avec la méthode ODAG (On-Demand App Generation). La nouvelle application généré avec ODAG aura un identifiant différent.

### Rubrique Apparence

Dans cette section, vous pouvez personnaliser le libellé et le design du bouton Qalyptus Self-Reporting.

### 4- Utiliser Qalyptus à la demande

### Authentification

Dans la feuille Qlik Sense, cliquez sur le bouton Qalyptus Self-Reporting. La première fois, l’utilisateur doit s’authentifier avec la méthode d’authentification choisie.

- Si la méthode d’authentification est l’authentification Windows, l’utilisateur doit saisir ses identifiants Windows : nom d’utilisateur au format DOMAINE\nom d’utilisateur et son mot de passe Windows.
- Si la méthode d’authentification est les identifiants Qalyptus, l’utilisateur doit exister dans Qalyptus Server et créer un mot de passe. L’utilisateur doit utiliser son email et le mot de passe créé. Si l’utilisateur existe dans Qalyptus Server et n’a pas encore créé de mot de passe, il peut générer un mot de passe sur la page de connexion de Qalyptus Server en cliquant sur le lien Mot de passe oublié?
- Si la méthode d’authentification est SSO avec SAML, si vous avez configuré un fournisseur d’identité dans Qalyptus Server, l’utilisateur sera automatiquement redirigé vers la page de connexion du fournisseur d’identité. Si vous avez configuré plusieurs fournisseurs d’identité, l’utilisateur verra un bouton de connexion pour chaque fournisseur d’identité.

### Generate a report

Après authentification, l’utilisateur peut s’abonner pour recevoir des rapports par email ou générer un rapport à la volée à partir d’une liste de rapports auxquels il a droit.

Pour générer un rapport, accédez à l’onglet **Rapports**, choisissez un rapport dans la liste des rapports, cliquez sur **Run now** et choisissez le format de sortie.

Suivez le statut d’exécution dans l’onglet **Statut**. A la fin de l’exécution, vous pouvez télécharger le rapport, supprimer l’entrée d’exécution ou relancer le rapport.

![Qalyptus Self Reporting Run Report](/img/docs-images/qalyptus-self-reporting-run-report.png)

Les administrateurs Qalyptus peuvent gérer les exécutions de rapports dans Qalyptus Server. Si l’exécution a échoué, vous pouvez accéder au fichier journal pour en savoir plus sur l’erreur.

Pour accéder au statut d’exécution dans Qalyptus Server, accédez à la page **Statut > Requêtes à la demande**.

![Qalyptus Self On Demand Status](/img/docs-images/qalyptus-server-qalyptus-on-demand-status.png)

### Abonnez-vous pour recevoir les rapports par e-mail

Comme vous pouvez le voir dans la vidéo de présentation, un utilisateur peut créer un abonnement pour envoyer différents rapports à différents destinataires à intervalle régulier.

Pour créer un abonnement, procédez comme suit :

- Ouvrir Qalyptus Self-Reporting
- Sélectionnez l’onglet Subscriptions
- Cliquez sur Subscribe
- Donner un nom à l’abonnement
- Saisissez une description (facultatif)
- Allez dans l’onglet Reports
- Cliquez sur Add Report
- Sélectionnez un rapport
- Choisissez les formats de sortie
- Pour les rapports HTML, cochez “Joindre le rapport par e-mail” pour joindre le rapport
- Cochez “Intégrer le rapport dans l’e-mail” pour avoir la possibilité d’intégrer le rapport dans le message de l’email
- Sélectionnez un favori si vous souhaitez l’appliquer avant de générer le rapport
- Cochez “Utiliser les sélections actuelles” si vous souhaitez appliquer les sélections actuelles avant de générer le rapport
- Cliquez sur Ajouter
- Allez dans l’onglet Email
- Saisissez l’objet de l’e-mail
- Ajouter le message de l’e-mail
- Si vous le souhaitez, vous pouvez intégrer un rapport HTML. Dans l’éditeur de texte, cliquez sur Embed Report puis sélectionnez un rapport dans la liste
- Allez dans l’onglet Destinataires
- Cliquez sur Add Users
- Sélectionnez les destinataires de l’e-mail dans la liste des utilisateurs. Si l’utilisateur n’existe pas, cliquez sur Créer un utilisateur pour créer un nouvel utilisateur. Le nouvel utilisateur ne sera visible que par son créateur
- Cliquez sur Ajouter
- Allez dans l’onglet Schedules
- Sélectionnez une Fréquence et le Fuseau horaire
- Cliquez sur Enregistrer

L’abonnement a été créé et les destinataires recevront par email les rapports à la fréquence choisie. Vous pouvez modifier ou supprimer l’abonnement à tout moment.
Vous pouvez également exécuter l’abonnement manuellement, les détails de l’exécution se trouvent sur la page Statut.
![Qalyptus Self Reporting Run Overview](/img/docs-images/qalyptus-self-reporting-overview.png)

Pour accéder à l’état de l’abonnement dans Qalyptus Server, accédez à la page **Statut> Abonnements aux rapports.**

![Qalyptus Self Service Subscription Status](/img/docs-images/qalyptus-server-qalyptus-selft-service-subscription-status.png)
