---
title: Qalyptus Notify
---

Qalyptus Notify vous permet de vous abonner à une feuille Qlik Sense ou à une application Qlik Sense entière. En vous abonnant, vous recevez un instantané d’une feuille ou d’une application sous forme d’image ou de PDF par e-mail à intervalles réguliers, sans avoir à vous connecter à Qlik Sense.

## Présentation de Qalyptus Notify

<iframe width="560" height="315" src="https://www.youtube.com/embed/AfgeOkrJEOQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Installer Qalyptus Notify

Qalyptus Notify est une extension Qlik Sense qui utilise Qalyptus Server Engine. Dans la vidéo ci-dessous, nous allons voir comment installer Qalyptus Server puis comment importer l’extension Qalyptus Notify dans Qlik Sense Server Entreprise.

:::note
Vous n’avez pas besoin d’une licence Qalyptus Server pour utiliser Qalyptus Notify.
:::

Nous verrons ce qui suit :

- S’assurer des droits nécessaires pour se connecter à Qlik Sense
- Ouvrir les Ports des services Qlik Sense (Uniquement pour une installation dans une machine séparée)
- Exporter les certificats Qlik Sense
- Importer et configurer Qalyptus Notify

## Install and configure Qalyptus Notify

<iframe width="560" height="315" src="https://www.youtube.com/embed/k-iFsNa4vX8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
