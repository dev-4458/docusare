---
title: Les exigences système de Qalyptus
---

## Qalyptus Desktop

Les valeurs ci-dessous se rapportent au matériel et aux logiciels minimums requis pour exécuter Qalyptus Desktop.

- Systèmes d’exploitation pris en charge (32-bit et 64-bit) : Windows 11 et Windows 10
- Exigences minimales en RAM : 1 Go
- Exigences en espace disque : 300 Mo
- Microsoft Office (32-bit ou 64-bit) : 2007, 2010, 2013, 2016, 2019, 2021 et Office 365 (versions installées uniquement)
- .NET Framework : version 4.7.2 ou ultérieure
- Paramètres d’affichage de tous les moniteurs : Taille du texte et des applications: 100% et Résolution d’affichage maximale: 1920 x 1080
- Aucune connexion Internet n’est nécessaire

Pour Qlik Sense

- Éditions Qlik Sense prises en charge : Qlik Sense Enterprise géré par le client et Qlik Sense Desktop
- Ouvrir le Port entrant 4747 où le service Qlik Sense Engine est installé
- Ouvrir les Ports entrants : 4242 et 4243 où sont installés les services Qlik Sense Repository et Qlik Sense Proxy
- Installez les Certificats Qlik Sense si Qalyptus est installé sur une machine différente de Qlik Sense ou si Qalyptus est installé sur la même machine que Qlik Sense mais que l’utilisateur des services Qlik Sense est différent de l’utilisateur Qalyptus.
- Qalyptus Desktop peut être installé sur le même domaine que Qlik Sense ou sur un domaine différent

Pour QlikView

- QlikView 11 ou QlikView 12 installé
- Qalyptus et QlikView doivent être installés sur le même ordinateur
- QlikView Desktop doit disposer d’une licence locale active ou d’une licence Named User CAL (utilisateur nommée) sur QlikView Server
- QlikView Desktop Personal Edition (version gratuite) non pris en charge

## Qalyptus Server

Les valeurs ci-dessous se rapportent au matériel et aux logiciels minimums requis pour exécuter Qalyptus Server.

- Systèmes d’exploitation pris en charge (64-bit) : Microsoft Windows Server 2012 ou ultérieur
- Exigences minimales en RAM : 2 Go
- Exigences en espace disque : 500 Mo
- .NET Framework : version 4.7.2 ou ultérieure
- Sur la machine sur laquelle Qalyptus Server est installé, ouvrir le Port entrant 3994 (Port par défaut du service Qalyptus Server, peut être changé)
- Ouvrir les Ports entrants 4747 où le service Qlik Sense Engine est installé et les ports: 4242 et 4243 où sont installés les services Qlik Sense Repository et Qlik Sense Proxy

Pour Qlik Sense

- Éditions Qlik Sense prises en charge : Qlik Sense Enterprise géré par le client et Qlik Sense Desktop
- Ouvrir le Port entrant 4747 où le service Qlik Sense Engine est installé
- Ouvrir les Ports entrants : 4242 et 4243 où sont installés les services Qlik Sense Repository et Qlik Sense Proxy
- Installez les Certificats Qlik Sense si Qalyptus est installé sur une machine différente de Qlik Sense ou si Qalyptus est installé sur la même machine que Qlik Sense mais que l’utilisateur des services Qlik Sense est différent de l’utilisateur du service Qalyptus Server.
- Qalyptus Desktop peut être installé sur le même domaine que Qlik Sense ou sur un domaine différent

Pour QlikView

- QlikView 11 ou QlikView 12 installé
- Qalyptus et QlikView doivent être installés sur le même ordinateur
- QlikView Desktop doit disposer d’une licence locale active ou d’une licence Named User CAL (utilisateur nommée) sur QlikView Server
- QlikView Desktop Personal Edition (version gratuite) non pris en charge
