---
title: Changer le certificat utilisé par Qalyptus Server en un certificat tiers
sidebar_label: Utiliser un certificat tiers
---

Par défaut, un certificat auto-signé est utilisé pour sécuriser la communication avec Qalyptus Server. Cela entraîne un avertissement dans le navigateur Web du client tel que «Le certificat de sécurité du site n’est pas approuvé”. Pour résoudre ce problème, le certificat utilisé Qalyptus doit être remplacé par un certificat signé d’une autorité de Certification (AC).

:::note
Le certificat auto-signé existant est sécurisé. Le message d’avertissement s’affiche car le navigateur Web ne dispose pas de toutes les informations nécessaire pour considérer que le certificat est valide. Suivez les étapes ci-dessous pour supprimer l’avertissement dans le navigateur Web client.
:::

## Importer le certificat

Suivez les étapes suivantes pour importer le certificat:

1. Lancez la console **MMC** sur la machine où Qalyptus Server est installé
2. Dans la console **MMC**, ouvrez **Fichier> Ajouter / Supprimer un composant logiciel enfichable …**
3. Sélectionnez **Certificats** et cliquez sur **Ajouter**
4. Sélectionnez **Un Compte d’ordinateur**, cliquez sur Suivant, sélectionnez L’ordinateur local et cliquez sur **Terminer**
5. Dans la console **MMC**, ouvrez **Certificats (ordinateur local) / Personnel**
6. Dans la console **MMC**, ouvrez **Actions> Toutes les tâches> Importer …**
7. Parcourez jusqu’au fichier de certificat fourni par votre autorité de certification
8. Suivez les instructions à l’écran pour importer le certificat, y compris la clé privée
9. Vérifiez que le nouveau certificat a été importé dans **Certificats (ordinateur local)> Personnel> Certificats** et qu’il contient une clé privée
10. Double-cliquez sur le **Certificat> Chemin d’accès de certification** et confirmez qu’il affiche **«Ce certificat est valide»**

## Utilisez le certificat dans Qalyptus Server Configuration

Suivez les étapes ci-dessous pour configurer Qalyptus avec votre certificat.

1. Dans la console **MMC**, cliquez avec le bouton droit sur le certificat importé et sélectionnez **Ouvrir**
2. Dans l’onglet **Détails**, faites défiler vers le bas et sélectionnez **Empreinte numérique**
3. Sélectionnez et copiez sa valeur dans le presse-papiers avec le raccourci clavier CTRL + C
4. Fermez la console **MMC**
5. Dans le menu démarrer de votre ordinateur, rechercher **Qalyptus Server Configuration**
6. Cliquez sur **Qalyptus Server Configuration** et allez dans le menu **General**
7. Entrez le nom d’utilisateur et le mot de passe de l’utilisateur qui exécute le service Qalyptus Server
8. Cochez la case **Use https**
9. Puis choisissez **Other valid SSL certificate**
10. Collez **Empreinte numérique** de votre certificat dans le champ **Certificate**
11. Assurez vous que l’adresse entrée dans le champ **Machine address** est celle qui sera utilisée pour se connecter à Qalyptus Server
12. Cliquez sur **Save**
13. Une message de confirmation s’affichera quant votre certificat est prise en compte par Qalyptus

Vous devriez maintenant pouvoir accéder à Qalyptus Server avec HTTPS sans le message d’avertissement du navigateur.
