---
title: Activation de HTTP
---

Dans une installation par défaut de Qalyptus Server, un certificat auto-signé est généré et utilisé. Vous pouvez utiliser Qalyptus Server avec HTTP, même si cela n’est pas recommandé.

Pour activer HTTP, après l’installation de Qalyptus Server, suivez les étapes suivantes :

1. Connectez vous à la machine où Qalyptus Server est installé avec l’utilisateur qui exécute le service **Qalyptus Server**
2. Dans le menu démarrer, rechercher **Qalyptus Server Configuration**
3. Cliquez sur **Qalyptus Server Configuration** et allez dans le menu **General**
4. Entrez le nom d’utilisateur et le mot de passe de l’utilisateur qui exécute le service Qalyptus Server
5. Décochez la case **Use https**
6. Cliquez sur **Save**
7. Une message de confirmation s’affichera quant les modifications sont prisent en compte

:::note
Notez qu’une fois que vous avez choisi d’utiliser HTTP, l’adresse de Qalyptus Server avec HTTPS ne fonctionnera plus.
:::

:::note
Si Qlik Sense Server est configuré pour utiliser le protocole HTTPS, l’utilisation d’un protocole HTTP pour la connexion de Qalyptus peut entraîner un problème de connexion entre Qlik Sense et Qalyptus, notamment quand vous utiliser les extensions Qalyptus Notify et Qalyptus On-Demand.
:::
