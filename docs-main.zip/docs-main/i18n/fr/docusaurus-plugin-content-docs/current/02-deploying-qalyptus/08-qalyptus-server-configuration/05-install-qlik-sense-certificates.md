---
title: Installer les certificats Qlik Sense
---

Pour utiliser Qalyptus avec Qlik Sense, vous devez avoir les certificats de Qlik Sense installés sur la machine où Qalyptus est installé. il existe deux cas de figure.

## 1- Qalyptus est installé sur la même machine que Qlik Sense

Si Qalyptus est installé sur la même machine que Qlik Sense vous ne devez pas installer les certificats Qlik Sense car les certificats sont déjà installé.

:::note
Installer les certificats Qlik Sense dans ce cas, entraînera le dysfonctionnement de Qlik Sense. Pour résoudre ce problème, suivez les [instructions décrites dans cet article](https://community.qalyptus.com/t/problem-after-installing-certificates-on-the-machine-where-qlik-sense-is-installed/122).
:::

## 2- Qalyptus est installé sur une machine distincte de Qlik Sense

Dans ce cas **l’installation des certificats Qlik Sense est obligatoire** afin que Qalyptus puisse communiquer avec Qlik Sense. Deux principales étapes sont nécessaires pour installer les certificats Qlik Sense.

## Exporter les certificats Qlik Sense via la QMC

Suivez les étapes ci-dessous pour exporter les certificats:

1. Connectez vous à la **QMC** de Qlik Sense
2. Sélectionnez **Certificats** sur la page de démarrage de la **QMC**
3. La page d’exportation des certificats s’affiche
4. Cliquez sur **Add machine name** pour ajouter une nouvelle boîte
5. Dans la zone **Machine name**, tapez le nom complet de l’ordinateur où Qalyptus est installé : nomDeLaMachine.domain.com ou l’adresse IP
6. Laissez les champs **Certificate password** et **Retype password** vides
7. Cochez la case **Include secret key**
8. Cliquez sur **Export certificates**

Une fois l’exportation terminée, le message suivant s’affiche : **Certificates exported** .

Les certificats seront exportés vers un emplacement de disque et le chemin est affiché. Dans le dossier, les certificats suivants sont créés : client.pfx, root.cer, server.pfx. Si l’exportation échoue, le message suivant est affiché : **Certificates export could not complete**.

## Installer les certificat via Qalyptus Server Configuration

Pour installer les certificats Qlik Sense avec Qalyptus Server Configuration, suivez lez étapes suivantes :

1. Connectez vous à la machine où Qalyptus Server est installé avec l’utilisateur qui exécute le service **Qalyptus Server**
2. Dans le menu démarrer, rechercher **Qalyptus Server Configuration**
3. Cliquez sur **Qalyptus Server Configuration** et allez dans le menu **Qlik Sense Certificates**
4. Précisez le chemin d’accès aux fichiers précédemment exportés : client.pfx, server.pfx, root.cer
5. Cliquez sur le bouton **Install Certificates**
6. Si d’anciens certificats sont déjà installés, une boite de dialogue s’affiche pour vous demander la confirmation de les supprimer pour les replacer par les nouveaux certificats
7. Après l’installation, un message de confirmation s’affiche

Vous pouvez maintenant utiliser Qalyptus avec Qlik Sense pour générer vos rapports.
