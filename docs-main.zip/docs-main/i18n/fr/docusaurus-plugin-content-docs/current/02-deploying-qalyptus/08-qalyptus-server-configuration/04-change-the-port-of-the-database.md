---
title: Changer le port de la base de données
---

Le numéro de port par défaut de la base de données de Qalyptus Server est **4048**. Vous pouvez à tout moment modifier le numéro de Port de Qalyptus Server avec le numéro de votre choix à condition qu’il ne soit pas en cours d’utilisation par une autre application.

Pour modifier le port de la base de données, suivez les étapes suivantes :

1. Connectez vous à la machine où Qalyptus Server est installé avec l’utilisateur qui exécute le service **Qalyptus Server**
2. Dans le menu démarrer, rechercher **Qalyptus Server Configuration**
3. Cliquez sur **Qalyptus Server Configuration** et allez dans le menu **Database Settings**
4. Entrez le nouveau numéro de port dans le champ **Port**
5. Cliquez sur **Save**
6. Une message de confirmation s’affichera quant le numéro du port est changé

:::note
Si vous avez mis en place des connections ODBC avec la base de données de Qalyptus Server, pensez à modifier le Port afin qu’elles puissent continuer à fonctionner.
:::
