---
title: Changer le port
---

Le port par défaut de Qalyptus Server est **3994**. vous pouvez changer le numéro de port au moment de l’installation de Qalyptus ou après l’installation.

Pour modifier le port après l’installation de Qalyptus Server, suivez lez étapes suivantes :

1. Connectez vous à la machine où Qalyptus Server est installé avec l’utilisateur qui exécute le service **Qalyptus Server**
2. Dans le menu démarrer, rechercher **Qalyptus Server Configuration**
3. Cliquez sur **Qalyptus Server Configuration** et allez dans le menu **General**
4. Entrez le nom d’utilisateur et le mot de passe de l’utilisateur qui exécute le service Qalyptus Server
5. Changez le numéro du port. Utilisez un numéro de port non réservé par une autre application
6. Si vous utilisez un certificat autre que le certificat auto-signé de Qalyptus, entrez l’empreinte numérique du certificat que vous utilisez dans le champ **Certificate**
7. Cliquez sur **Save**
8. Une message de confirmation s’affichera quant le numéro du port est changé

:::note
Notez qu’une fois que vous avez changé le numéro du port, l’adresse de Qalyptus Server avec l’ancien numéro du port ne fonctionnera plus.
:::
