---
title: La licence Qalyptus Server
---

Pour afficher et gérer votre licence Qalyptus Server, accédez à l’onglet **Licence** dans Administration> Système. Vous aurez besoin d’ajouter ou mettre à jour votre licence si vous :

- Ajoutez une nouvelle licence pour une instance Qalyptus Server nouvellement installée.
- Ajoutez une nouvelle licence lorsque votre ancienne licence a expiré.

## Ajouter une nouvelle licence

Pour appliquer votre licence avant son expiration, procédez comme suit :

1. Obtenez la clé de licence que vous souhaitez mettre à jour (vous pouvez le faire en visitant [my-account](https://my.qalyptus.com/my-account/licenses/)).
2. Dans Qalyptus Server, allez dans **Administration> Système** et Choisissez> **Licence**.
3. Dans la zone de texte **Clé de licence**, collez votre clé de licence.
4. Cliquez sur le bouton **Activer** pour mettre à jour Qalyptus Server avec la nouvelle licence.

Vous verrez maintenant la nouvelle date d’expiration de la licence.
![Qalyptus Server License Screen](/img/docs-images/qalyptus-server-license-screen.png)
