---
title: Générer une clé de licence
---

La clé de licence Qalyptus Desktop est liée au nom d’utilisateur Windows de l’utilisateur qui utilise Qalyptus Desktop. Une licence Qalyptus Desktop est attribuée **à un seul nom d’utilisateur Windows**. Votre licence sera valide sur tous les PC tant que vous vous connecterez avec votre compte Windows.

La clé de licence de Qalyptus Server est liée à l’ID de la machine sur laquelle Qalyptus Server est installé. Si vous souhaitez installez Qalyptus Server dans un environnement de test, lisez la section “Licence hors production”.

## Générer une nouvelle licence

Une fois votre commande complétée, allez à la page [Licences](https://my.qalyptus.com/my-account/licenses) pour générer une clé de licence pour chaque produit.

Sur cette page, vous trouverez la liste des licences que vous avez achetées. Exemple : si vous avez acheté 3 licences Qalyptus Desktop, vous verrez 3 lignes correspondant aux 3 licences associées un numéro de support (Support Entitlement Number) unique.

![Licenses List](/img/docs-images/licenses-list.jpg)

Pour générer une nouvelle licence, procédez comme suit:

1. Dans la page de licence, cliquez sur le lien **New license**
2. Une nouvelle page s’ouvrira. Saisissez le nom complet et l’adresse e-mail du propriétaire de la licence ainsi que le nom d’utilisateur ou l’ID du serveur.

- Pour Qalyptus Desktop, le nom d’utilisateur est le compte Windows de l’utilisateur (Domaine\NomUtilisateur). Pour le trouver, ouvrez Qalyptus Desktop et allez dans : **Paramètres > Licence**
  ![License Activation](/img/docs-images/qalyptus-license-activation.png)
- Pour Qalyptus Server, l’ID du serveur est l’ID de la machine sur laquelle Qalyptus est installé. Pour le trouver, ouvrez Qalyptus Server et allez dans : **Administration Qalyptus > Licence**
  ![Server License Screen](/img/docs-images/qalyptus-server-license-screen.png)

3. Cliquez sur **Save**
4. Si tout c’est bien passé, une nouvelle licence sera créée et l’utilisateur spécifié recevra la clé de licence par mail
5. Vous verrez la clé de licence à la place du lien **New license**.

Maintenant, la licence peut être utilisée pour [activer l’instance Qalyptus](/products/qalyptus/deploying-qalyptus/licencing-qalyptus-desktop) de l’utilisateur spécifié.

:::note
Notez que la date d’expiration de la licence est calculée à partir de la date d’achat de la licence.
:::

## Renouveler une licence existante

Vous pouvez renouveler tout ou partie de vos licences existantes à tout moment. Nous vous recommandons de renouveler vos licences suffisamment avant la date d’expiration pour éviter toute interruption de l’utilisation.

Pour renouveler une licence existante, accédez à la page [Licences](https://my.qalyptus.com/my-account/licenses) et procédez comme suit:

1. Copiez la clé de licence que vous souhaitez renouveler
2. Cliquez sur le lien **Renew a license**
3. Une nouvelle page s’ouvrira. Collez la clé de licence et cliquez sur **Save**.
4. Si tout c’est bien passé, une nouvelle licence sera créée et le propriétaire de la licence recevra la clé de licence par mail
5. Vous verrez la clé de licence à la place du lien **Renew a license**.

Notez que la date d’expiration de la nouvelle licence sera supérieure à l’ancienne date d’une année.

## Licence hors production (licence pour un environnement de test)

La licence Qalyptus Server permet jusqu’à trois activations de la même clé: un environnement de production et deux environnements hors production, comme défini dans le contrat de licence utilisateur final. Après avoir installé Qalyptus Server sur une machine hors production, envoyez-nous la clé de licence de Qalyptus Server de l’environnement de production avec l’ID du serveur de la machine hors production et nous vous enverrons une clé de licence.
