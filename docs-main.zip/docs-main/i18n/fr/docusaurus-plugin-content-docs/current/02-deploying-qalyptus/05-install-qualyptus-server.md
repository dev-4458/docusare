---
title: Installer Qalyptus Server
---

Installer Qalyptus Server est nécessaire pour ordonnancer la génération et la distribution des rapports vers des dossier ou des utilisateurs par mail.

<iframe width="560" height="315" src="https://www.youtube.com/embed/rJvC8OzU3ww" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

Pour installer Qalyptus Server, procédez comme suit :

1. Téléchargez Qalyptus Server sur [qalyptus.com](https://www.qalyptus.com/).
2. Localisez le fichier d’installation.
3. Lancer l’installateur.
4. Sur l’écran **Sélectionnez la langue d’installation**, choisissez une langue et cliquez sur **Suivant**.
5. Acceptez les termes du contrat de licence et cliquez sur Suivant.
6. Choisissez le **répertoire d’installation** et cliquez sur **Suivant**.
7. Sur l’écran **Prêt pour l’installation**, cliquez sur **Installer**.
8. Sur l’écran final d’installation, laissez cochée **la case Lancer Qalyptus Server**, puis cliquez sur **Terminer** afin de configurer Qalyptus Server avant la première utilisation.
9. **Qalyptus Server Configuration** se lance.
   ![Qalyptus Server Configuration General](/img/docs-images/Qalyptus-server-configuration-general.png)
10. Qalyptus Server doit s’exécuter avec un utilisateur qui doit être un **administrateur local**. Entrez le Domaine et le nom de l’utilisateur dans ce format : Domaine\NomUtilisateur ainsi que son mot de passe.
11. Le numéro de port par défaut de Qalyptus Server est 3994. Vous pouvez choisir un autre numéro de port à condition qu’il ne soit pas déjà en utilisation par un autre programme.
12. Qalyptus Server accepte les protocoles http et https. Pour utiliser Qalyptus Server avec https, vous devez installer un certificat SSL valide avant d’activer l’option https.
13. Cliquez sur **Suivant** pour continuer.
14. Une fois les données du premier écran validées, **l’écran Configuration de la base de donnée** s’affiche.
    ![Qalyptus Server Configuration Database Configuration](/img/docs-images/Qalyptus-server-configuration-database-configuration.png)
15. Le numéro de port de la base de donnée de Qalyptus Server est 4048. Vous pouvez choisir un autre numéro de port à condition qu’il ne soit pas déjà en utilisation par un autre programme.
16. Entrez un nom d’utilisateur et un mot de passe de votre choix pour créer un utilisateur de base de donnée nécessaire à l’exécution de votre instance Qalyptus Server.
17. Cliquez sur **Suivant**.
18. L’écran **Certificats de Qlik Sense** s’affiche.
    ![Qalyptus Server Configuration Qlik Sense Certificates](/img/docs-images/Qalyptus-server-configuration-qlik-sense-certificates.png)
19. Si vous souhaitez installer les certificats de Qlik Sense, cocher la case **Je veux installer les certificats de Qlik Sense**. Sinon cliquez sur **Suivant**.
20. Préciser le chemin d’accès aux fichiers : client.pfx, server.pfx, root.cer. Pour exporter ces trois fichier de certificat, suivez les instructions décrites dans cette page d’aide de Qlik Sense. Important : lors de l’export des certificats, laissez **le champ mot de passe vide**.
21. Cliquez sur **Installer les certificats**.
22. L’écran **Prêt pour l’installation** s’affiche.
    ![Qalyptus Server Configuration Ready To Install](/img/docs-images/Qalyptus-server-configuration-ready-to-install.png)
23. Cliquez sur **Installer** pour installer et démarrer les services de Qalyptus Server.
24. Une fois l’installation terminée, l’écran de félicitations s’affiche.
    ![Qalyptus Server Configuration Congratulations](/img/docs-images/Qalyptus-server-configuration-congratulations.png)
25. Cliquez sur **Ouvrir Qalyptus Server** pour démarrer l’utilisation de Qalyptus Server.
26. Qalyptus Server s’ouvre avec votre navigateur par défaut sur la page ci-dessous. La première étape consiste à activer Qalyptus Server avec une licence ou commencer une période d’essai de 30 jours.

    ![Qalyptus Server Startup License](/img/docs-images/Qalyptus-server-startup-license.png)

27. Une fois la licence activée, passez à l’étape suivante.
    ![Qalyptus Server Startup Register](/img/docs-images/Qalyptus-server-startup-register.png)
28. Entrez les informations du premier utilisateur et administrateur de Qalyptus Serveur. Ces coordonnées vous permettrons de vous connecter à Qalyptus Server. Pour que vous puissiez vous connecter avec l’authentification Windows, renseignez votre Compte de domaine (Domaine\NomUtilisateur).
29. Cliquez sur **Suivant**.
30. Un écran **Installer** s’affiche.
31. Cliquez sur le bouton **Installer**.
32. Une fois l’installation terminée, vous serez rediriger vers l’écran de connexion.
    ![Qalyptus Server Login Form](/img/docs-images/Qalyptus-server-login-form.png)
33. Sur la machine sur laquelle Qalyptus Server est installé, ouvrez le **Port entrant** 3994 pour le service Qalyptus Server. Si vous avez modifié ces ports par défaut lors du processus de configuration, ouvrez les ports que vous avez choisis.
34. Ouvrir les **Ports entrants** 4747 où le service Qlik Sense Engine est installé et les ports: 4242 et 4243 où sont installés les services Qlik Sense Repository et Qlik Sense Proxy.
