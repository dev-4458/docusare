---
title: Installer Qalyptus Desktop
---

Installez Qalyptus Desktop sur les ordinateurs des utilisateurs qui créeront des projets Qalyptus: connexions, modèles, rapports et tâches.

Pour installer Qalyptus Desktop, procédez comme suit :

1. Téléchargez Qalyptus Desktop sur [qalyptus.com](https://www.qalyptus.com/).
2. Localisez le fichier d’installation.
3. Lancer l’installateur.
4. Sur l’écran Sélectionnez la langue d’installation, choisissez une langue et cliquez sur Suivant.
5. Acceptez les termes du contrat de licence et cliquez sur Suivant.
6. Choisissez le répertoire d’installation et cliquez sur Suivant.
7. Sur l’écran Prêt pour l’installation, cliquez sur Installer.
8. Si vous souhaitez lancer Qalyptus Desktop, laissez cochée la case Lancer Qalyptus Desktop, puis cliquez sur Terminer.

## Installer et configurer votre environnement pour utiliser Qalyptus Desktop avec Qlik Sense

Si vous voulez utiliser Qalyptus avec Qlik Sense Server, vous devez effectuer certaines configurations pour permettre à Qalyptus de se connecter à votre serveur Qlik Sense. La vidéo ci-dessous explique comment le faire.

<iframe width="560" height="315" src="https://www.youtube.com/embed/DqlcseUypNY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
