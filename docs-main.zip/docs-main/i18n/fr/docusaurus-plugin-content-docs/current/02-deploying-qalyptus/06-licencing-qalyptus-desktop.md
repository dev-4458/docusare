---
title: La licence Qalyptus Desktop
---

Vous pouvez afficher et gérer votre licence Qalyptus Desktop dans l’onglet **Licence** dans la page **Paramètres**. Vous aurez besoin d’ajouter ou mettre à jour votre licence si vous :

- Ajoutez une nouvelle licence pour une instance Qalyptus Desktop nouvellement installée.
- Ajoutez une nouvelle licence lorsque votre ancienne licence a expiré.

## Ajouter une nouvelle licence

Pour appliquer votre licence avant son expiration, procédez comme suit:

1. Obtenez une clé de licence de votre compte (vous pouvez le faire en visitant [my-account](https://my.qalyptus.com/my-account/licenses/)).
2. Dans Qalyptus Desktop, ouvrez la fenêtre paramètre et choisissez> **Licence**.
3. La page ci-dessous apparaît.
4. Dans la zone de texte **Clé de licence**, collez votre clé de licence.
5. Cliquez sur le bouton **Appliquer** pour mettre à jour Qalyptus Desktop avec la nouvelle licence.

Vous verrez maintenant la nouvelle date d’expiration de la licence.

![Qalyptus License Activation](/img/docs-images/qalyptus-license-activation.png)

Si votre licence a expiré, au lancement de Qalyptus Desktop, une fenêtre apparaît. Cliquez sur le boutton OK, puis entrez votre clé de licence et cliquez sur **Appliquer**.

![Qalyptus License Activation 2](/img/docs-images/qalyptus-license-activation-2.png)
