---
title: Les langues supportées
---

L’interface utilisateur de Qalyptus prend en charge les langues suivantes:

- Anglais
- Français

Les langues suivantes seront bientôt ajoutées : allemand, espagnol, portugais et italien.

Lorsque vous changez de langue, l’interface change instantanément. Vous n’avez pas besoin de redémarrer Qalyptus.
