---
title: Qalyptus API
---

Parfois, vous avez des cas d’utilisation et des exigences que nous ne proposons pas encore. Heureusement, il est possible de créer vos propres applications et d’étendre les fonctionnalités de Qalyptus.

Les outils et les API que Qalyptus met à la disposition des développeurs permettent d’intégrer, de personnaliser, d’automatiser et d’étendre les fonctionnalités de Qalyptus en fonction des besoins spécifiques de votre entreprise.

L’API Qalyptus peut être intégrée dans vos applications internes ou utilisée dans des extensions Qlik Sense par exemple.

Accéder à [à la documentation de REST API Qalyptus](https://help.qalyptus.com/qalyptus-api/).
