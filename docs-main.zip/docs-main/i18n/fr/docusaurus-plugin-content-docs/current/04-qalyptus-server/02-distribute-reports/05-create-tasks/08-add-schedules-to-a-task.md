---
title: Ajouter des programmations
---

Pour planifier une tâche et lui permettre de s’exécuter automatiquement, vous devriez lui attribuer une ou plusieurs [programmations ](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules).

Pour ajouter une programmation à une tâche, suivez les étapes suivantes :

1. Dans la page **Tâches**, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet **Programmations**.
3. Cliquez sur **Ajouter Programmations**.
4. Une fenêtre s’ouvre.
5. Sélectionnez une ou plusieurs programmations.
6. Cliquez sur **Ajouter**.
7. Cliquez sur **Enregistrer**.

La liste des tâches programmées est visible dans la pages **Statut > Taches programmées**.

:::note
Une tâche programmée va s’exécuter à la date et heure de ses programmations uniquement si elle est active.
:::
