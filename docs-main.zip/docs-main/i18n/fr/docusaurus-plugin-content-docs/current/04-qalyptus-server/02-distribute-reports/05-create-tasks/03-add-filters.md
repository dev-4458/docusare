---
title: Ajouter des filtres à une tâche
---

Qalyptus vous permet d’appliquer des [filtres](/products/qalyptus/qalyptus-desktop/create-filters) sur les tâches avant de générer vos rapports. Pour ajouter des filtres à une tâche, suivez les étapes suivantes :

1. Dans la page **Tâches**, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet **Filtres**.
3. Cliquez sur le bouton **Ajouter Filtres**.
4. Une fenêtre s’affiche.
5. Sélectionnez un ou plusieurs filtres.
6. Cliquez sur **Ajouter**.
7. Si besoin, ordonnez les filtres en utilisant les boutons ↓ et ↑.
8. Cliquez sur **Enregistrer**.
