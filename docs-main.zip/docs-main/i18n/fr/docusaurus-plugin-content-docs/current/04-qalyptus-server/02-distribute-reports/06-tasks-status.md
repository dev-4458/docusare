---
title: Statuts des tâches
---

Il es important de suivre l’exécution des tâches de génération des rapports. Les statuts des tâches sont disponibles dans la page **Statut**.

Cette page contient trois onglets : **Tâches programmées**, **Requêtes à la demande** et **Abonnements aux rapports**.

## Tâches programmées

Dans cet onglet vous trouverez l’ensemble des tâches qui ont au moins une programmation. L’onglet contient les éléments suivants :

- Bouton **Exécuter** et **Arrêter** la tâche.
- **Nom de la tâche**.
- **Nom de la programmation**.
- **Indicateur** si la tâche est active ou pas.
- **Statut** : Statut de la tâche (Jamais, En file d’attente, En cours, Arrêté, Erreur, Terminé).
- **Dernière exécution** : Date de la dernière exécution de la tâche.
- **Prochaine exécution** : Date de la prochaine exécution de la tâche.
- **Action/Ouvrir fichier journal** : Télécharger et ouvrir le fichier de logs lié à la dernière exécution de la tâche.

## Requêtes à la demande

Cet onglet contient l’ensemble des tâches, rapports exécutés à la demande. On retrouve les tâches et les rapports exécutés depuis la page [Tâches](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/create-tasks), Rapports ou de l’extérieur (avec l’API Qalyptus). Exemple : la génération à la demande de rapports depuis Qlik Sense avec l’extension [Qalyptus On-Demand](https://github.com/qalyptus/qalyptus-sense-on-demand) extension.

Cet onglet contient les éléments suivants :

- Bouton **Exécuter** et **Arrêter**.
- **Titre de la tâche ou du rapport**.
- **Source** de l’élément.
- **Format** de sortie du ou des rapports.
- **Nom du projet** auquel l’élément est lié.
- **Statut** : Statut de l’exécution (Jamais, En file d’attente, En cours, Arrêté, Erreur, Terminé).
- **Dernière exécution** : Date de début de la dernière exécution.
- **Fin de l’exécution** : Date de fin de la dernière exécution.
- **Action/Télécharger** : Télécharger le résultat de l’exécution si sa source est : On-demand ou Rapport.
- **Action/Ouvrir fichier journal** : Télécharger et ouvrir le fichier de logs lié à la dernière exécution.
- **Action/Supprimer** : Supprimer l’élément.

## RAbonnements aux rapports

Cet onglet contient l’ensemble des abonnements aux rapports crées par les utilisateurs. Un abonnement est une tâche programmée pour générer un rapport et l’envoyer à un utilisateur par e-mail.

Cet onglet contient les éléments suivants :

- Nom du rapport.
- L’objet de l’e-mail.
- Le nom du propriétaire de l’abonnement.
- La programmation choisi pour recevoir le rapport.
- Le dernier statut de l’exécution de la tâche.
- La date de la dernière exécution de la tâche.
- La date de la prochaine exécution de la tâche.

Dans le menu Action, il est possible de voir le journal de l’exécution de la tâche, modifier l’abonnement, ainsi que de désabonner un utilisateur d’un rapport.

:::note
Lorsqu’une tâche envoie des rapports par e-mail, Qalyptus genère un fichier de log pour chaque e-mail envoyé. Dans ce fichier, vous pouvez voir l’état de l’activité SMTP. Si vous ne recevez pas d’e-mail envoyé par Qalyptus, vous pouvez consulter le fichier de log pour comprendre pourquoi.

Dans le fichier de log des tâches, vous voyez le chemin d’accès au dossier qui contient les fichiers de log des e-mails.
:::
