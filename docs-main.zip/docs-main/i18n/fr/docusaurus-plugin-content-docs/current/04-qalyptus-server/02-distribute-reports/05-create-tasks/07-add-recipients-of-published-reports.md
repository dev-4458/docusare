---
title: Ajouter des destinataires
---

Dans cette section, vous allez pouvoir ajouter les utilisateurs ou les groupes d’utilisateurs qui vont être les destinataires des rapports publiés avec une tâche.

Les utilisateurs que vous allez rajouter, peuvent recevoir l’e-mail envoyé durant l’exécution de la tâche et/ou avoir accès aux rapports dans le Hub de Qalyptus.

Pour ajouter des destinataires, suivez les étapes suivantes :

1. Dans la page **Tâches**, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet **Destinataires**.
3. Cliquez sur **Ajouter Utilisateurs**.
4. Une fenêtre s’ouvre.
5. Sélectionnez un ou plusieurs utilisateurs.
6. Cochez la case **Envoyer e-mail** pour permettre à l’utilisateur de recevoir l’e-mail de distribution.
7. Cochez la case **Peut voir dans Hub** pour permettre à l’utilisateur de consulter les rapports dans le Hub de Qalyptus.
8. Cliquez sur **Ajouter**.
9. Cliquez sur **Enregistrer**.

Pour ajouter un groupe d’utilisateurs, suivez les même étapes en cliquant sur le bouton **Ajouter Groupes**.
