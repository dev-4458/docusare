---
title: Distribuer les rapports par e-mail
---

Lors de l’exécution de la tâche, vous pouvez envoyer un e-mail aux utilisateurs pour leur distribuer des rapports ou pour simplement les notifier.

Pour configurez l’e-mail qui sera envoyé aux utilisateurs à la fin de la génération des rapports, suivez les étapes ci-dessous :

1. Dans la page **Tâches**, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet **Distribution > E-mail**.
3. Cochez la case **Envoyer e-mail** .
4. Entrez l’adresse e-mail de l’expéditeur dans le champ **De**.
5. Dans le champ **CC**, vous pouvez ajouter les adresses e-mail des utilisateurs qui seront en copie de l’e-mail (optionnel). Séparez les adresses e-mail avec une virgule.
6. Dans le champ **BCC**, vous pouvez ajouter les adresses e-mail des utilisateurs qui seront en copie cachée de l’e-mail (optionnel). Séparez les adresses e-mail avec une virgule.
7. Entrez un objet pour l’e-mail dans le champ **Objet**.
8. Dans le champ **Message**, entrez le message de l’e-mail. En plus du texte, vous pouvez ajouter :

   - Rapports HTML : Vous pouvez intégrer des rapports HTML directement dans le corps de l’e-mail. Dans l’éditeur du message, cliquez sur le bouton **“Rapports”** et sélectionnez le rapport à intégrer. Le nom du rapport peut être également ajouté dans l’objet de l’e-mail. Avant d’utiliser le rapport HTML, vous devez l’ajouter à la liste des rapports de tâches.

   - Variables Qlik Sense et QlikView : Dans l’éditeur du message, cliquez sur le bouton **“Variables”** pour ajouter des variable dans le message. Les variables peuvent être également utilisées dans l’objet de l’e-mail.

   - Étiquettes : Commencer à écrire # pour ajouter des étiquettes. Les étiquettes disponibles sont : le nom prénom de l’utilisateur, e-mail de l’utilisateur, la liste des rapports et la liste de destinations.

   - Images : Cliquez sur le bouton sous forme d’image pour insérer une image dans le message.

9. Pour attacher les rapports dans l’e-mail, cochez la case **Joindre les fichiers**. Tous les rapports dans l’onglet de la tâche Rapports avec la case à cocher «Pièce jointe» activée seront joints.

10. Cliquez sur **Enregistrer**.
