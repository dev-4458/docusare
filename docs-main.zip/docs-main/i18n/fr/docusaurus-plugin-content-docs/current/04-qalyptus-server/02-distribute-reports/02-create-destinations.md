---
title: Créer des destinations
---

Les destinations sont les endroits où seront sauvegardés les rapports générés par Qalyptus Server. Il peut s’agit du emplacement en local (sur la même machine où Qalyptus Server est installé) ou emplacement distant en utilisant des services de stockage de fichiers comme FTP, Dropbox, …etc.

Les étapes suivantes vous montre comment créer une destination dans Qalyptus Server.

1. Connectez vous à Qalyptus Server.
2. Allez dans l’onglet Destinations.
3. Cliquez sur Créer Destination.

![Qalyptus Server Destinations](/img/docs-images/Qalyptus-server-destinations.png)

4. Saisissez les informations dans les champs suivants :

- **Nom** : Entrez le nom de la destination.
- **Description** : Entrez une description pour la destination (optionnel).
- **Type** : Choisissez le type de la destination.
- Si vous choisissez un type autre que **Dossier**, Précisez le **Service de stockage de fichiers**.
- Choisissez entre un Chemin **Statique et Chemin Dynamique**.
- Si vous choisissez **Chemin Dynamique**, utilisez le bouton + pour créer votre chemin, sinon entrez un chemin statique

5. Cliquez sur **Enregistrer**.

Les [Services de stockage de fichiers ](/products/qalyptus/qalyptus-server/qalyptus-administration/system/storage-services) doivent être crées au préalable dans **Administration> Système > Services Stockage Fichiers**.
