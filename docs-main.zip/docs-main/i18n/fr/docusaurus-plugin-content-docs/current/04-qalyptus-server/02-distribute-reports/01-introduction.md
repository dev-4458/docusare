---
title: Introduction
---

Afin de générer et de distribuer vos rapports crées à partir de Qlik Sense et QlikView de manière automatique, il est nécessaire de paramétrer les moments de génération et les moyens de distribution.

- [Créer des destinations](/products/qalyptus/qalyptus-server/distribute-reports/create-destinations)
- [Créer des programmations](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules)
- [Créer des tâches](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/create-tasks)
- [Statuts des tâches](/products/qalyptus/qalyptus-server/distribute-reports/tasks-status)

## Distribution des rapports avec Qalyptus (en anglais)

<iframe width="560" height="315" src="https://www.youtube.com/embed/veRBObpxyHU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
