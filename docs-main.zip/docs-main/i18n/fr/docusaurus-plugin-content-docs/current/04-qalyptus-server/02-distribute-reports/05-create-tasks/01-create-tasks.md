---
title: Créer des tâches
---

Dans cette section nous allons voir comment créer des tâches et programmer leur exécution. Une tâche peut être exécutée à la demande ou de manière planifiée et récurrente à l’aide de [Programmations](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules).

Pour créer une tâche, suivez les étapes suivantes :

1. Sur Qalyptus Server, allez dans l’onglet Tâches.
2. Cliquez sur bouton Créer Tâche.
3. La fenêtre ci-dessous s’affiche.

![Qalyptus Create Task](/img/docs-images/qalyptus-create-task.png)

4. Entrez le nom de la tâche et choisissez un projet auquel la tâche sera associée.
5. Cliquez sur **Enregistrer**.
6. Puis cliquez sur **Publier**.
7. La fenêtre ci-dessous s’affiche.

![Qalyptus Publish Task](/img/docs-images/qalyptus-publish-task.png)

## Envoyer une notification après l’exécution de la tâche

Vous pouvez envoyer une notification par e-mail à la fin d’exécution d’une tâche pour informer des personnes de l’état de la tâche; la tâche s’est terminée par des erreurs, des avertissements ou un succès. Le fichier de log de la tâche est joint à l’e-mail.

Pour chaque tâche, vous pouvez choisir le statut pour lequel vous souhaitez envoyer une notification et les destinataires.

## Envoyer des rapports aux destinataires test

Lorsque vous planifiez une tâche pour envoyer des rapports aux destinataires, vous souhaiterez peut-être recevoir les e-mails à une adresse e-mail spécifique pour vous assurer que chaque destinataire reçoit l’e-mail avec le texte et les pièces jointes attendus.

Après avoir activé le **Mode Test**, les e-mails seront envoyés à une adresse e-mail spécifique à la fin de l’exécution de la tâche. L’objet de e-mail sera précédé de l’adresse e-mail du destinataire d’origine.

Si vous avez 20 destinataires dans votre tâche et entrez votre adresse e-mail lorsque vous activez le **Mode Test**, vous recevrez 20 e-mails, et les destinataires ne recevront rien. Si tout est OK, désactivez le **mode Test**, et les destinataires recevront les emails à la prochaine exécution de la tâche.

![Qalyptus Task Test Mode](/img/docs-images/qalyptus-task-test-mode.png)

## Publier les rapports

Pour publier des rapports avec cette tâche, suivez les étapes suivantes :

- [Ajouter des rapports](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-reports)
- [Ajouter des filtres](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-filters)
- Choisir les moyens de distribution: [Dossier](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-to-folders), [E-mail](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-by-email), [Qalyptus Hub](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-to-the-qalyptus-hub)
- [Ajouter des destinataires](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-recipients-of-published-reports)
- [Ajouter des programmations](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-schedules-to-a-task)
- [Ajouter des conditions](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-conditions-to-a-task)
