---
title: Créer des programmations
---

La page Programmations affiche la liste des programmations avec leur nom, leur type, leur fréquence, le nombre de tâches et leur description.

Pour créer une nouvelle programmation :

1. Sur Qalyptus Server, allez dans la page **Programmations**

![Qalyptus Server Schedules](/img/docs-images/Qalyptus-server-schedules.png)

2. Cliquez sur **Créer Programmation**

![Qalyptus Schedule](/img/docs-images/qalyptus-schedule.png)

3. Saisissez les informations dans les champs suivants :

- **Nom** : Entrez le nom de la programmation
- **Fréquence** : Choisissez la fréquence de la programmation. Vous pouvez définir : Une fois, Toutes les heures, Tous les jours, Toutes les semaines, Tous les mois ou Tous les ans
- Choisissez la date de **Début** et la date de **Fin**
- Sélectionnez votre Fuseau horaire préféré
- Choisissez le type **d’exécution** de la tâche: Parallèle ou En série
  Lorsque vous choisissez Parallèle, la tâche peut s’exécuter simultanément avec d’autres tâches.
  Si vous choisissez En série, la tâche s’exécutera séparément des autres tâches. Si une tâche en série est en cours d’exécution, les tâches qui s’exécutent après seront mises dans la file d’attente. Si une tâche En série est exécutée alors que d’autres tâches sont en cours d’exécution, elle est mise en file d’attente jusqu’à ce que toutes les tâches soient terminées.
- Définissez une priorité de 1 à 100, où 1 est la priorité la plus élevée. La priorité sera attribuée à aux tâches dans lesquelles la programmation est utilisée. Si deux tâches sont en attente dans la file d’attente, celle avec la priorité la plus élevée s’exécute en premier.

4. Cliquez sur **Enregistrer**

Pour modifier une Programmation existante :

1. Sur Qalyptus Server, allez dans l’onglet **Programmations**
2. Cliquez sur le bouton **Action** de la Programmation à modifier
3. Cliquez sur **Editer**
4. Modifier la programmation, puis cliquez sur **Enregistrer**
