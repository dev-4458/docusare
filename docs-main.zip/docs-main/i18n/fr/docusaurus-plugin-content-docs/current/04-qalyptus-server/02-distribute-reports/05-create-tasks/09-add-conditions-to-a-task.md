---
title: Ajouter des conditions
---

Pour exécuter une tâche uniquement si certaines conditions sont remplies, vous devez affecter une ou plusieurs conditions à la tâche.

Pour ajouter une condition à une tâche, procédez comme suit:

1. Sur la page **Tâches**, cliquez sur le nom d’une tâche pour la modifier
2. Allez dans l’onglet **Conditions**
3. Cliquez sur **Ajouter Conditions**
4. Une fenêtre s’ouvre
5. Sélectionnez une ou plusieurs conditions
6. Choisissez si vous souhaitez appliquer la condition à la tâche ou aux rapports

- **Pour la tâche**: Qalyptus évaluera la condition avant de commencer à générer les rapports. La condition est évaluée après l’application des filtres de la tâche
- **Pour les rapports** : Qalyptus évaluera la condition uniquement pour les rapports sélectionnés. La condition est évaluée après l’application des filtres des rapports
  Si le rapport est un rapport d’itération, vous pouvez choisir, dans l’onglet Rapports, entre :
  - Évaluer la condition avant de commencer la génération du rapport
  - Évaluer la condition pour chaque itération (avant de générer chacun des fichiers de rapport)

7. Cliquez sur **Ajouter**
8. Cliquez sur **Enregistrer**

:::note
La tâche n’est exécutée que si toutes les conditions affectées à la tâche sont satisfaites. Après exécution, Qalyptus évaluera les conditions appliquées à chaque rapport, si les conditions ne sont pas satisfaites, la génération du rapport est ignorée.
:::
