---
title: Distribuer les rapports vers le Hub de Qalyptus
---

Vous pouvez distribuer des rapports vers le Hub de Qalyptus. Le Hub permet aux utilisateurs de visualiser, télécharger et de s’abonner aux rapports auxquels ils ont le droit.

Pour publier les rapports d’une tâche vers le Hub, suivez les étapes suivantes :

1. Dans la page **Tâches**, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet **Distribution > Hub**.
3. Cochez la case **Publiez les rapports dans le Hub**.
4. Entrez le **nombre maximal d’occurrences de fichiers** à garder. Entrez 0 pour ne pas limiter le nombre d’occurrences. Si par exemple vous entrez le nombre 5, Qalyptus va historiser uniquement les 5 dernières versions de chaque fichier. Les versions les plus anciens seront supprimées.
5. Cliquez sur **Enregistrer**.
