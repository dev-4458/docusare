---
title: Ajouter des rapports
---

Pour ajouter des rapports à une tâche, suivez les étapes suivantes :

1. Après la création d’une tâche, cliquez sur le bouton **Publier**. Ou dans la liste des tâches cliquez sur le nom de la tâche pour l’éditer.
2. Allez à l’onglet **Rapports**.
3. Cliquez sur le bouton **Ajouter Rapport**.
4. Une fenêtre s’affiche.
5. Sélectionnez un rapport parmi les rapports disponibles dans la liste déroulante **Rapport**.
6. Sectionnez le **format** de sortie du rapport parmi les formats disponibles

![Qalyptus Publish Report](/img/docs-images/qalyptus-publish-report.png)

Pour plus de flexibilité, vous pouvez choisir pour chaque rapport ajouté à une tâche comment vous souhaitez le distribuer :

- Enregistrer dans dossier
- Publier sur Qalyptus Hub
- Pièce jointe
- Intégration e-mails (pour les rapports HTML)

7. Si le rapport sélectionné est un rapport qui contient une Itération, d’autres options s’affichent.

![Qalyptus Publish Iteration Report](/img/docs-images/qalyptus-publish-iteration-report.png)

- **Zipper les fichiers dans les destinations Dossier** : Si vous cochez cette case, les fichiers générés et sauvegardés dans un dossier seront compressés dans un fichier Zip.
- **Zipper les fichiers lorsqu’ils sont envoyés par e-mail** : Si vous cochez cette case, les rapports envoyés en pièce jointe seront regroupés dans un fichier zip.
- **Si une condition est appliquée, évaluez la condition pour chaque valeur de champ** : Si vous cochez cette case, Qalyptus va évaluer les conditions liées au rapport avant de générer chaque fichier du rapport.

- **Stockage dans des dossiers** : Cette option vous permet d’utiliser une variable Qlik Sense ou QlikView afin de distribuer chaque fichier, crée durant une Itération, dans une ou plusieurs destinations spécifiques.

  - Exemple 1 : Vous souhaitez créer des rapports par Ville et vous voulez que chaque rapport soit sauvegardé dans un dossier portant le nom de la ville : `D:\Marketing Files\<Nom ville>`. Dans ce cas, il vous suffit de créer une variable dans l’application source du rapport (Qlik Sense ou QlikView) qui va avoir comme valeur le chemin de stockage de chaque fichier en fonction de la ville sélectionnée. La définition de la variable va ressembler à ça : vStoragePathCityReport = ‘D:\Marketing Files\’ &City_name. En supposant que City_name est un champ qui contient des villes. Ainsi, le rapport pour la ville = Paris sera sauvegardé dans le dossier : ‘D:\Marketing Files\Paris’.

  - Exemple 2 : Vous souhaitez maintenant générer des rapports par Ville et sauvegarder les fichiers dans des dossiers avec le nom du Pays de la ville. Dans ce cas, votre variable va ressembler à ça : vStoragePathCityReport = ‘D:\Marketing Files\’ &County_name. En supposant que County_name est un champ qui contient des pays. Ainsi, le rapport pour la ville = Paris sera sauvegardé dans le dossier : ‘D:\Marketing Files\France’.

  - Exemple 3 : Pour sauvegarder un fichier dans plusieurs dossiers, il suffit de séparer la liste des chemin avec une virgule, en utilisant par exemple la fonction “Concat()“. Si vous souhaitez par exemple sauvegarder le fichier de chaque ville dans des dossiers qui portent le nom des managers de la ville, la variable va ressembler à ça : vStoragePathCityReport = Concat(‘D:\Marketing Files\’ &Manager_name, ‘,’). En supposant que Manager_name est un champ qui contient les managers des villes.

- **Distribution par e-mail** : Cette option vous permet d’utiliser une variable Qlik Sense ou QlikView afin de distribuer par e-mail chaque fichier du rapport, crée durant une Itération, à un ou plusieurs destinataires. Cette option fonctionne de la même manière que Stockage dans des dossiers. Veuillez regarder la vidéo ci-dessous pour voir comment envoyer le même rapport à différents utilisateurs avec des données différentes.

:::note
Le scénario dans la vidéo utilise l’e-mail des utilisateurs, mais vous pouvez utiliser le compte de domaine des utilisateurs.
:::

<iframe width="560" height="315" src="https://www.youtube.com/embed/YvnyjlrsBIk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

- **Visibilité dans le HUB** : Cette option vous permet d’utiliser une variable Qlik Sense ou QlikView afin de limiter les accès à chaque fichier, crée durant une Itération, dans Qalyptus Hub. Cette option fonctionne de la même manière que Stockage dans des dossiers.

  - Exemple 1: Vous pouvez par exemple générer des rapports par **Commercial** et les publier dans le portail Qalyptus Hub. Si vous voulez que chaque commercial puisse voir uniquement sont rapport, dans ce cas il vous suffit de créer une variable qui va avoir comme valeur l’e-mail ou le compte de domaine du commercial pendant l’itération. Ainsi, chaque commercial ne pourra voir que sont rapport.

  - Exemple 2 : Vous souhaitez que le rapport d’un commercial puisse être visible dans Qalyptus Hub uniquement pour le commercial et son Manager. Dans ce cas, votre variable doit contenir l’identifiant (e-mail ou le compte de domaine) du commercial et celui de son manager en les séparant avec une virgule.

8. Cliquez sur le bouton **Ajouter**.

9. Puis cliquez sur **Enregistrer**.
