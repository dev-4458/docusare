---
title: Distribuer les rapports dans des dossiers
---

Qalyptus Server peut distribuer des rapports dans des dossiers sur un disque dur ou sur un serveur distant via FTP. Avant d’ajouter des destinations, il faut créer les destinations dans la page
[Destinations](/products/qalyptus/qalyptus-server/distribute-reports/create-destinations).

Pour ajouter des destinations à une tâche, suivez les étapes suivantes :

1. Dans la page Tâches, cliquez sur le nom d’une tâche pour l’éditer.
2. Allez à l’onglet Distribution > Destinations.
3. Cliquez sur le bouton Ajouter Destinations.
4. Une fenêtre s’affiche.
5. Sélectionnez une ou plusieurs destinations.
6. Cliquez sur Ajouter.
7. Cliquez sur Enregistrer.
