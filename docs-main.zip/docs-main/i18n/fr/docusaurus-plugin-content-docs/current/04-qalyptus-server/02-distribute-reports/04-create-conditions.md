---
title: Créer des conditions
---

Vous pouvez ajouter une ou plusieurs conditions pour exécuter une tâche dans Qalyptus Server. La tâche n’est exécutée que si toutes les conditions sont remplies.

:::note
La tâche n’est exécutée que si toutes les conditions affectées à la tâche (Tous les rapports) sont satisfaites. Après exécution, Qalyptus évaluera les conditions appliquées à chaque rapport, si les conditions ne sont pas satisfaites, la génération du rapport est ignorée.
:::

Pour créer une condition, procédez comme suit:

1. Sur Qalyptus Server, accédez à la page **Conditions**
2. Cliquez sur **Créer Condition**
3. Entrez un **Nom**
4. Ajoutez une description si vous le souhaitez
5. Choisissez un **Projet** à associer à la condition
6. Cliquez sur Enregistrer
7. Cliquez ensuite sur **Editer**
8. Dans l’onglet **Règles**, cliquez sur **Ajouter Règle**.
   Une condition est composée de différentes règles. Pour qu’une condition soit satisfaite, toutes les règles doivent être satisfaites.
9. Vous pouvez créer une règle en comparant:
   - Une variable à une valeur personnalisée
   - Une variable au résultat d’une expression Qlik
   - Une variable à une autre variable
   - Vérifier si un graphique a des valeurs ou non
   - Un KPI à une valeur personnalisée
   - Un KPI au résultat d’une expression Qlik
   - Un KPI à une variable

![Qalyptus Condition Rules](/img/docs-images/qalyptus-condition-rules.png)

1. Cliquez sur **Ajouter**
2. Puis Cliquez sur **Enregistrer**
