---
title: Qalyptus Hub
---

Qalyptus Hub est un portail web qui permet aux utilisateur de consulter, télécharger et s’abonner à des rapports générés avec Qalyptus. Vous pouvez également accéder à vos applications Qlik Sense si elles sont synchronisées.

Qalyptus Hub est intégré dans Qalyptus Server. En vous connectant à Qalyptus Server, vous serez redirigé automatiquement sur le Hub.

![Qalyptus server Hub](/img/docs-images/qalyptus-server-hub.png)

## Qalyptus Hub avec un thème personnalisé

Le design de Qalyptus Hub peut être personnalisé avec le Design de votre entreprise.

![Qalyptus Hub Custom Theme](/img/docs-images/qalyptus-hub-custom-theme.png)

## Les différents onglets

### Accueil

Dans cette page vous trouverez les 6 derniers rapports que vous avez ajouté à vos favoris ainsi qu les 6 rapports les plus récents (récemment ajouté ou récemment vu).

### Applications

Cette page contient toutes les applications Qlik Sense synchronisées. Comme dans Qlik Sense Hub, l’utilisateur ne verra que les applications auxquelles il a droit.

### Rapports

Cette page contient l’ensemble des rapports auxquels vous avez le droit de consulter.

### Favoris

Cette page contient l’ensemble des rapports que vous avez marquez comme des favoris. Pour enlever un rapport de cette liste, cliquez sur le bouton sous forme d’étoile.

### Récents

Cette page contient l’ensemble de vos rapports triés par date d’ajout et date de visualisation du rapport.

### Abonnements

Dans cette page vous retrouverez la liste des abonnements aux rapports que vous avez crée ou qu’un administrateur a crée pour vous. Vous pouvez éditer un abonnement pour le modifier. Vous pouvez également vous désinscrire pour ne plus recevoir le rapport.

### Ressources

Cette page contient des liens vers différentes ressources créées par les administrateurs. Exemple : fichiers PDF dans des pages web, lien vers des fichiers dans SharePoint, …etc.

## Les actions possibles

### Prévisualiser un rapport

Pour prévisualiser un rapport, il vous suffit de cliquer sur le nom du rapport que vous désirez prévisualiser.

### Historique des versions

En fonction du nombre d’occurrences maximum défini lors de la génération du rapport, il est possible d’accéder à aux précédents versions du rapport. Pour afficher l’ensemble des versions, cliquez sur le menu **Action** correspondant au rapport, puis cliquez sur **Historique des versions**.

### Télécharger un rapport

Si vous avez les droits nécessaires, vous pouvez télécharger un rapport en cliquant sur le menu **Action** correspondant au rapport, puis cliquez sur **Télécharger**.

Vous pouvez également télécharger un rapport dans la page de prévisualisation en cliquant sur le bouton **Télécharger** qui se trouve en haut à droite.

### Marquer un rapport comme favori

Pour faciliter la recherche de votre rapports les plus utilisés, vous pouvez les marquer comme favori. Pour marquer un rapport comme favori, cliquez sur l’étoile des favoris près du nom du rapport. Pour supprimer un rapport des favoris, cliquez sur l’étoile que vous avez utilisée pour marquer le favori.

### S’abonner à un rapport

Vous pouvez vous abonner à des rapports afin de les recevoir par e-mail à une fréquence de votre choix.

Pour créer un abonnement, suivez les étapes suivantes :

- Cliquez sur le menu **Action** du rapport auquel vous souhaitez vous abonner.
- Cliquez sur **S’abonner**.
- Une fenêtre s’affiche.
- Sélectionnez le **format** des sortie du rapport parmi les formats disponibles.
- Entrez un **Objet** pour l’ e-mail.
- Ajouter un message si vous le souhaites.
- Dans **Programmation**, définissez la fréquence de réception du rapport. Choisissez de recevoir votre rapport : toutes les heures, tous les jours, toutes les semaines ou tous les mois.
- **Fuseau horaire** : Le fuseau horaire utilisé est celui défini dans votre profile.
- Cliquez sur **S’abonner**.

### Supprimer un rapport

Si vous avez les droits nécessaires, vous pouvez supprimer un rapport afin qu’ils ne soit plus visible dans Qalyptus Hub. La suppression d’un rapport implique la suppression définitive de toutes les occurrences du rapport.

Pour supprimer un rapport, cliquez sur le menu **Action** correspondant au rapport à supprimer, puis cliquez sur **Supprimer**.
