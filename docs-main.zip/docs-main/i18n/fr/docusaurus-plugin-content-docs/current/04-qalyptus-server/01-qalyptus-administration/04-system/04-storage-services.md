---
title: Services de Stockage
---

Qalyptus Server vous permet de sauvegarder les rapports générés dans des dossiers et dans des serveurs de stockages distants via les protocoles FTP et SFTP.

Dans cette section, nous allons voir comment créer des services de stockage de fichier afin de l’utiliser au moment de la création des destinations.

## Créer un service FTP ou SFTP

Pour créer un service FTP ou SFTP, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server.
2. Allez dans **Administration > Système > Services de Stockage**.
3. Cliquez sur **Ajouter un service**
   ![Qalyptus Server System File Storage](/img/docs-images/Qalyptus-server-system-file-storage-services.png)

4. Saisissez les informations dans les champs suivants :

- **Nom** : Entrez le nom du service.
- **Description** : Entrez une description pour le service (optionnel).
- **Défaut** : Cochez cette case pour définir ce service comme service par défaut.
- **Type** : Choisissez FTP ou SFTP.
- **Serveur FTP**: Nom d’hôte de votre serveur FTP.
- **Identifiant FTP** : Identifiant de l’utilisateur FTP.
- **Mot de passe FTP** : Mot de passe de l’utilisateur FTP.
- **Mode Passif** : Cochez cette case si vous souhaitez utiliser le mode passif. Cette option est uniquement disponible pour FTP.

5. Cliquez sur **Tester Connexion** pour vérifier l’accès au service.

6. Cliquez sur **Enregistrer**.
