---
title: Authentication
---

L’authentification vérifie l’identité d’un utilisateur. Tous ceux qui doivent disposer d’un accès à Qalyptus Server, que ce soit pour gérer le serveur, publier, explorer ou administrer du contenu, doivent être ajoutés en tant qu’utilisateurs dans le référentiel de Qalyptus. La méthode d’authentification peut être effectuée avec les identifiant Qalyptus ou les identifiants Windows. Dans tous les cas, chaque identité d’utilisateur doit être représentée dans le référentiel Qalyptus Server.

Pour choisir les authentifications à autoriser dans Qalyptus Server :

1. Connectez vous à Qalyptus Server.
2. Allez dans **Administration> Système> Authentification**.
3. Choisissez une ou plusieurs types d’authentification puis cliquez sur **Mettre à jour**.

![Qalyptus Server System Authentication](/img/docs-images/Qalyptus-server-system-authentication.png)

:::note
Cette page n’est visible que pour Qalyptus Server Business et Qalyptus Server Enterprise. Pour Qalyptus Server Ultimate, les méthodes d’authentification sont gérées dans les paramètres de l’organisation.
:::
