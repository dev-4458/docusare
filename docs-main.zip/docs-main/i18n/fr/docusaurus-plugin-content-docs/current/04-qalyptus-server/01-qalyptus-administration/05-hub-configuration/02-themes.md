---
title: Thèmes
---

Qalyptus Server s’installe avec un thème par défaut (logo et couleurs). Si vous devez changer le thème par défaut en un thème personnalisé, vous pouvez créer de nouveaux thèmes. Le thème par défaut ne peut pas être supprimé.

## Comment créer un nouveau thème ?

1. Connectez-vous à Qalyptus Server en tant qu’administrateur
2. Allez dans Qalyptus Administration > Configuration Hub > Thèmes
3. Cliquez sur **Créer Thème**
4. Entrez un nom pour le thème
5. Saisissez une description (facultatif)
6. Choisissez le thème **Mode** (Light, Dark, Black). Le Mode fait référence à la couleur de fond
7. Entrez vos couleurs préférées
8. Ajoutez une image du logo
9. Cliquez sur Aperçu pour prévisualiser le résultat (thème appliqué temporairement)
10. Cliquez sur **Enregistrer**
11. Actualisez la page pour effacer le thème temporaire

![Qalyptus Server Themes](/img/docs-images/qalyptus-server-themes.png)

## Comment remplacer le thème par défaut par un nouveau thème ?

Un thème doit être affecté à une organisation pour être utilisé. Après avoir créé un thème :

1. Allez dans Configuration Qalyptus> Système> Organisations
2. Editez l’organisation dont vous souhaitez changer le thème
3. Dans l’onglet Vue d’ensemble, sélectionnez le nouveau thème
4. Cliquez sur Enregistrer

![Qalyptus Change Organization Theme](/img/docs-images/qalyptus-change-organization-theme.png)

Comme un thème est affecté à une organisation, vous pouvez avoir plusieurs organisations et chaque organisation avec son thème. Les pages où l’utilisateur n’est pas authentifié (par exemple la page de connexion) sont communes à toutes les organisations. Pour ces pages, vous devez choisir un thème parmi vos thèmes.

1. Allez dans Qalyptus Administration> Paramètres généraux
2. Changer le **Thème par défaut**
3. Cliquez sur **Enregistrer**

![Qalyptus Server Default Theme](/img/docs-images/qalyptus-server-default-theme.png)

## Après avoir appliqué le thème

Après avoir appliqué le thème, l’aspect de Qalyptus changera en utilisant les nouvelles couleurs du thème et l’image du logo.

![Qalyptus  Change Theme](/img/docs-images/qalyptus-change-theme.png)

:::note
La fonctionnalité Thèmes est disponible uniquement avec Qalyptus Server Ultimate.
:::
