---
title: Ressources
---

Dans Qalyptus HUB, en plus des applications Qlik Sense et des rapports , il est possible de fournir aux utilisateurs des liens vers des ressources externes. Exemple : lien vers des pages web, lien vers des fichiers dans SharePoint, …etc.

Une ressource est une URL valide vers n’importe quelle page Web ou fichier. l’URL doit commencer par HTTP:// ou HTTPS://.

Si vous gérez plusieurs Organisations, une ressource est affectée à une organisation.

Pour créer une ressource, procédez comme suit :

1. Connectez-vous à Qalyptus Server
2. Allez dans Administration Qalyptus > Configuration Hub > Ressources
3. Cliquez sur **Créer Ressource**
4. Entrez un nom pour la ressource
5. Saisissez une description (facultatif)
6. Entrez un lien vers la ressource (doit être une URL valide)
7. Choisissez une organisation (si vous gérez plusieurs organisations)
8. Cliquez sur **Enregistrer**

![Qalyptus Server Create Resources](/img/docs-images/qalyptus-server-create-resource.png)

La ressource sera visible par les utilisateurs dans Qalyptus HUB.

![Qalyptus Server Resources](/img/docs-images/qalyptus-server-resources.png)
