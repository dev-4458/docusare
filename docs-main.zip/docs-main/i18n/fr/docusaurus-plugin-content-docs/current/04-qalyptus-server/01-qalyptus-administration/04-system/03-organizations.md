---
title: Organizations
---

Cette fonctionnalité apporte beaucoup de flexibilité dans la gestion de vos utilisateurs et contenus dans Qalyptus. Vous pouvez créer plusieurs organisations pour séparer les utilisateurs et le contenu (Projets, rapports, tâches, ressources, Qlik Apps). Chaque organisation aura ses membres, son contenu, ses types d’authentification et son thème.

Vous pouvez imaginer différents scénarios où il est intéressant d’avoir plusieurs organisations.

- Lorsque vous avez différentes filiales. Créer une organisation pour chaque filiale ; séparer les membres, le contenu, et le thème (chaque filiale avec son logo et ses couleurs). Lorsqu’un utilisateur de la filiale A crée une tâche, il ne peut utiliser que les rapports et les destinataires de la filiale A.
- Lorsque vous gérez des applications et des rapports pour les employés et les clients. Créer deux organisations ; séparer le contenu, les membres, la méthode d’authentification (Exemple : authentification LDAP pour les employés et authentification SAML pour les clients)
- Vous êtes un partenaire Qlik OEM ou MSP (Managed Service Provider). Séparez le contenu de vos clients et appliquez votre design. Vous offrirez une expérience incroyable aux utilisateurs ; ils trouveront en un seul endroit leurs applications, mashups, rapports, ressources, abonnement aux rapports, …etc.
- De nombreux autres scénarios peuvent être imaginés en fonction de votre industrie et des besoins de votre entreprise.

![Qalyptus Server Organizations](/img/docs-images/qalyptus-server-organizations.png)

## L’Organisation par défaut

Qalyptus Server s’installe avec une organisation nommée Default (et nom d’affichage : Qalyptus). Si vous maintenez un environnement d’organisation unique sur Qalyptus Server, celui-ci devient l’organisation avec laquelle vous travaillez. Si vous ajoutez des organisations, l’organisation par défaut devient l’une des organisations que vous pouvez gérer.
L’organisation par défaut ne peut pas être supprimée.

:::note
La fonctionnalité Organisations est disponible uniquement avec Qalyptus Server Ultimate.
:::
