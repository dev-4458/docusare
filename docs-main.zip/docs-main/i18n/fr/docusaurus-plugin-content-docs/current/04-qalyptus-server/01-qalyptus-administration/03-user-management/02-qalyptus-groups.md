---
title: Groupes Qalyptus
---

Vous pouvez organiser les utilisateurs de Qalyptus Server en groupes pour faciliter la gestion de plusieurs utilisateurs. Vous pouvez créer des groupes sur le serveur ou importer des groupes à partir d’Active Directory et d’Azure AD.

Par défaut, seul les utilisateurs avec le rôle Administrator peuvent créer, modifier et supprimer des groupes. Il est possible de permettre la gestion des groupes à certains utilisateurs en leur affectant un rôle avec des permissions de création, modification ou suppression de groupes.

Les groupes Active Directory et Azure AD sont créer au même temps que la [ création des utilisateurs](/products/qalyptus/qalyptus-server/qalyptus-administration/user-management/qalyptus-users).

## Ajouter des groupes locaux

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans Administration > **Gestion Utilisateurs**.
3. Sélectionnez l’onglet Groupes et cliquez Saisissez un nom dans le champ **Nom de groupe**, puis cliquez sur **Créer Groupe**.

![Qalyptus Server Groups](/img/docs-images/Qalyptus-server-groups.png)

## Ajouter des utilisateurs à un groupe

Tous les utilisateurs sont ajoutés automatiquement au groupe système “All users” qui contient l’ensemble des utilisateurs.

Pour ajouter des utilisateurs à un groupe, procédez comme suit :

1. Choisissez un groupe et cliquez sur le bouton **Action** pour afficher le menu des actions.

![Qalyptus Server Groups Edit Members](/img/docs-images/Qalyptus-server-groups-edit-members.png)

2. Cliquez sur **Éditer membres**.
3. Sélectionnez la liste des utilisateurs que vous voulez ajouter au groupe, puis cliquez sur **Ajouter**.
4. Cliquez **Enregistrer**.
