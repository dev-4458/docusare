---
title: Serveur de messagerie SMTP
---

Qalyptus Server peut envoyer des e-mail aux utilisateurs pour les informer de la disponibilité de leurs rapports. Vous devez toutefois d’abord configurer le serveur SMTP que Qalyptus Server utilise pour envoyer les e-mails.

Pour configurer SMTP, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans **Administration > Système > Serveur de messagerie SMTP**.
3. Cliquez sur **Configurer un nouveau serveur de messagerie SMTP**.

![Qalyptus Server SMTP](/img/docs-images/Qalyptus-server-smtp.png)

4. Renseignez les informations suivantes :

- **Nom** : Donnez un nom à votre Serveur de messagerie SMTP.
- **Description (Optionnel)** : Il s’agit de la description du serveur de messagerie.
- **Nom d’expédition** : Tapez le nom d’utilisateur que va utiliser le serveur SMTP pour envoyer les messages.
- **Adresse d’expédition** : Tapez l’adresse que va utiliser le serveur SMTP pour envoyer les messages.
- **Préfixe pour tous les objets d’e-mail (optionnel)** : Si vous renseignez ce champ, tous les objets des e-mails que va envoyer Qalyptus Serveur seront préfixé de la valeur de ce champ.
- **Nom Hôte** : Entrez l’adresse du serveur SMTP.
- **Port SMTP** : Entrez le numéro du port du serveur SMTP.
- **SSL** : Cochez cette case si votre serveur utilise le chiffrement SSL.
- **Nom d’utilisateur**: Renseignez le nom d’utilisateur du serveur.
- **Mot de passe** : Renseignez le mot de passe du serveur.
- **E-mail de test** : Entrez un e-mail qui va vous permettre de tester la connexion au serveur SMTP.

5. Cliquez sur **Tester Connexion** pour vérifier si Qalyptus Server arrive à se connecter au serveur SMTP avec les informations renseignées.
6. Cliquez sur **Enregistrer**.

Si le test de connexion a échoué :

- Assurez-vous que le serveur SMTP est accessible et que le port est ouvert. Ouvrez le CMD et tapez cette commande: telnet [smtp-server] [port]. Si une page vide apparaît, cela signifie que le serveur est accessible et que le port est ouvert, sinon le serveur n’est pas accessible ou le port n’est pas ouvert.
- Vérifiez l’activité SMTP de l’e-mail de test. Le chemin par défaut du fichier journal est : `C:\ProgramData\Qalyptus\QalyptusServer\Log\[current-date]\SMTP activity`
