---
title: Qalyptus Hub – Général
---

Dans cette section, vous modifiez les paramètres suivants :

- **Adresse Qlik Sense Server (facultatif)** : Qalyptus utilisera cette adresse pour synchroniser votre application Qlik Sense avec Qalyptus Hub
- **Utilisateur Qlik Sese (facultatif)** : pour synchroniser toutes les applications Qlik Sense, vous devez saisir un utilisateur Qlik Sense avec le rôle d’administrateur
- **Abonnement** : **Nom de l’expéditeur** : Lorsqu’un utilisateur s’abonne pour recevoir des rapports, Qalyptus utilisera ce nom comme nom d’expéditeur.
- **Abonnement** : **à partir d’un e-mail** : lorsqu’un utilisateur s’abonne pour recevoir des rapports, Qalyptus utilisera cet e-mail comme e-mail d’expéditeur.
- **Abonnement : pied de page d’e-mail personnalisé (facultatif)** : lorsqu’un utilisateur s’abonne pour recevoir des rapports, Qalyptus ajoute le texte à la fin de l’e-mail.

## Configurer Qalyptus Hub

Pour modifier l’adresse e-mail d’expédition, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans Administration > Configuration Hub> Général.
3. Cliquez sur Editer.
4. Saisissez les informations souhaitées
5. Cliquez sur Enregistrer.

![Qalyptus Server Hub Configuration](/img/docs-images/qalyptus-server-hub-configuration.png)
