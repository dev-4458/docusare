---
title: Fournisseurs d’identité
---

En plus de l’authentification avec les identifiants Windows et l’e-mail/mot de passe, Qalyptus prend en charge l’authentification SAML 2 à l’aide de fournisseurs d’identité comme Okta, Auth0, Azure AD, Ping Identity, …

L’authentification avec SAML est également disponible dans nos extensions Qlik Sense : Qalyptus On-demand et Qalyptus Self-Reporting.

Vous pouvez configurer un ou plusieurs fournisseurs d’identité.

![Qalyptus SSO Identity Providers](/img/docs-images/qalyptus-sso-identity-providers.png)

## Configurer un fournisseur d’identité (IdP)

Pour configurer votre fournisseur d’identité, procédez comme suit :

1. Se connecter à Qalyptus Server en tant qu’administrateur
2. Accédez à Administration de Qalyptus > Système > Fournisseurs d’identité
3. Cliquez sur Créer fournisseur d’identité
4. Entrez un nom
5. Saisissez une description (facultatif)
6. Cochez l’option Signer la demande d’authentification Si vous souhaitez signer la demande d’authentification et si elle est prise en charge par votre IdP
7. Utilisez le fichier de métadonnées ou les informations ci-dessous dans les paramètres de votre fournisseur d’identité.

- URL du service consommateur d’assertion (ACS)
- ID d’entité du fournisseur de services (SP)
  Le fichier de métadonnées contient toutes les informations sur le fournisseur de services (SP).
  Qalyptus récupère automatiquement les certificats du Fournisseur d’Identité.

8. Entrez le fournisseur d’ID d’entité par l’IdP (URL de l’émetteur)
9. Saisissez l’URL de connexion unique (URL SSO)
10. Saisissez le libellé du bouton. Exemple : Connectez-vous avec Okta
11. Cliquez sur **Enregistrer**

![Qalyptus Create IDP](/img/docs-images/qalyptus-create-idp.png)

Si votre IDP est Ping Identity, ajoutez l’attribut **Email Address** avec la valeur **email** dans les paramètres de l’application.

![Ping Identity Attribute Mappings](/img/docs-images/Ping-Identity-Attribute-mappings.png)

## Utiliser le fournisseur d’identité

Un fournisseur d’identité doit être ajouté à une organisation. Seuls les membres (utilisateurs) de l’organisation peuvent utiliser le fournisseur d’identité en question.

Vous pouvez ajouter plusieurs fournisseurs d’identité à une organisation. Le membre de l’organisation verra un bouton de connexion pour chaque fournisseur d’identité.

Si une organisation n’utilise qu’un seul fournisseur d’identité, l’utilisateur est automatiquement redirigé pour s’authentifier (le bouton de connexion n’est pas affiché).

### Page de connexion

![Qalyptus Server Login](/img/docs-images/qalyptus-saml-Qalyptus-Server-Login.png)

### Paramètres d’authentification Qalyptus On-Demand

![Qalyptus On Demand Auth](/img/docs-images/qalyptus-on-demand-auth.png)
