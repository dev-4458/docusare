---
title: Sauvegarde et Restauration
---

Un administrateur Qalyptus Server doit effectuer régulièrement la maintenance de la base de données, surveiller l’utilisation du disque sur le serveur, supprimer les fichiers inutiles, et sauvegarder Qalyptus Server et ses données. Grâce à ces étapes, vous assurez l’efficacité maximale de Qalyptus Server.

Qalyptus Server intègre une fonctionnalité de sauvegarde et restauration qui vous facilite le processus de sauvegarde et restauration de la base de données.

Le fichier de sauvegarde va être stocké sur le même ordinateur que votre instance Qalyptus Server, à cet endroit : C:\ProgramData\Qalyptus\QalyptusServer\export.

:::important
Important : La restauration doit se faire en utilisant un fichier crée avec la même version. Dans le cas contraire, la restauration échouera. Si vous désinstallez et réinstallez Qalyptus, assurez-vous d’utiliser l’utilisateur de la base de données (nom d’utilisateur et mot de passe) de l’installation précédente.
:::

## Créer une sauvegarde

Pour créer une sauvegarde, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server.
2. Allez dans **Administration> Système> Sauvegarde et restauration**.
3. Cliquez sur **Créer une sauvegarde**.

![Qalyptus Server System Backup Restore](/img/docs-images/Qalyptus-server-system-backup-restore.png)

4. Saisissez les informations dans les champs suivants :

- **Activé** : Choisissez d’activer ou de désactiver la sauvegarde.
- **Nom** : Entrez un nom pour la sauvegarde.
- **Description** : Entrez une description pour la sauvegarde (optionnel).
- **Programmer** : Choisissez le mode de sauvegarde : Manuellement ou Automatiquement. Si vous choisissez Automatiquement, précisez la fréquence de lancement de la sauvegarde.

5. Cliquez sur **Enregistrer**.

## Restaurer la base de données

Pour restaurer la base de données de Qalyptus Server, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server.
2. Allez dans **Administration> Système> Sauvegarde et restauration**.
3. Cliquez sur **Restaurer**.
4. Entrez le chemin vers le fichier de sauvegarde. Le fichier doit être sur le même ordinateur que votre instance Qalyptus Server et doit être créé avec la même version de Qalyptus.
5. Cliquez sur **Restaurer**.
