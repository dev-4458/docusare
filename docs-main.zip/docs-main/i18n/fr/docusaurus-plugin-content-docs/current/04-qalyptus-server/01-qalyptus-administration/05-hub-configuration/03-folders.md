---
title: Dossiers
---

Les dossiers vous permettent d’organiser les applications Qlik Sense dans Qalyptus HUB. Lorsque vous synchronisez vos applications Qlik Sense avec Qalyptus Hub, les applications s’affichent dans des dossiers et sous-dossiers.

Pour créer un dossier, procédez comme suit :

1. Connectez-vous à Qalyptus Server
2. Allez dans Qalyptus Administration > Configuration Hub > Dossiers
3. Cliquez sur Créer Dossier
4. Entrez le nom du dossier
5. Choisissez le dossier Parent
6. Cliquez sur Enregistrer

## Ajouter une application Qlik Sense à un dossier

Lorsque une application est synchronisée avec Qalyptus Hub, elle est enregistrée dans le dossier par défaut spécifié dans les paramètres de synchronisation. Pour modifier l’emplacement de l’application et l’ajouter à un autre dossier, procédez comme suit :

1. Allez dans Administration Qalyptus > Configuration du Hub > Applications
2. Modifiez l’application dont vous souhaitez modifier le dossier
3. Sélectionnez le nouveau dossier
4. Cliquez sur Enregistrer

Dans Qalyptus Hub, l’application apparaîtra dans le nouveau dossier.

![Qalyptus Server Change App Folder](/img/docs-images/qalyptus-server-change-app-folder.png)

## Applications et dossiers dans Qalyptus Hub

Dans Qalyptus Hub, toutes les applications du dossier racine (“/”) et les dossiers dont un parent est le dossier racine, apparaîtront dans le niveau “Mon Hub”.

![Qalyptus Server Folders Hub](/img/docs-images/qalyptus-server-folders-hub.png)
