---
title: Les paramètres généraux
---

La page paramètres généraux contint les éléments ci-dessous :

![Qalyptus General Settings](/img/docs-images/Qalyptus-general-settings.png)

- **Dossier temporaire** : il s’agit de l’emplacement où seront sauvegardés les fichiers temporaires généré par Qalyptus Server.
- **Fichiers de modèle** : Il s’agit de l’emplacement où seront sauvegardés les fichiers modèle lors de l’importation de vos projets Qalyptus.
- **Dossier Logs** : Il s’agit de l’emplacement où seront sauvegardés les différents fichier les fichiers journaux que génère Qalyptus Server.
- **Langue par défaut du site** : Il s’agit de la langue qui sera utilisée par Qalyptus Server (fichiers journaux, notification mail, message aux utilisateur non authentifiés, …). Cette langue ne doit pas être confondue avec la langue choisie par l’utilisateur pour son profile.
- **Jours pour garder les requêtes à la demande** : Choisissez le nombre de jours pendant lesquels vous souhaitez conserver l’historique d’exécution des demandes. Mettez 0 pour un nombre illimité de jours.
- **Priorité des requêtes à la demande** : Priorité des requêtes effectuées via l’exécution manuelle d’une tâche, l’extension Qalyptus On-Demand et l’API. Ordre de prioritaire de 1 à 100.
- **Priorité de la tâche d’abonnement** : Priorité des tâches créées en s’abonnant à un rapport dans Qalyptus Hub ou en s’abonnant à un objet Qlik Sense à l’aide de l’extension Qalyptus Notify. Ordre prioritaire de 1 à 100.
- **Message de mail par défaut** : Il s’agit d’un corps de mail par défaut qui s’affichera automatiquement dans la partie E-mail lors ce que vous planifier l’exécution d’une tâche.
