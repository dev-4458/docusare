---
title: Utilisateurs Qalyptus
---

Toute personne devant accéder à Qalyptus Server, que ce soit pour parcourir, publier, modifier du contenu ou administrer le site, doit être ajoutée en tant qu’utilisateur. Les administrateurs et les utilisateurs disposant de droits nécessaires ont les options suivantes pour ajouter des utilisateurs :

- Ajouter des utilisateurs locaux.
- Ajouter des utilisateurs à partir d’Active Directory.
- Ajouter des utilisateurs à partir d’Azure AD.

Par défaut, seul les utilisateurs avec le rôle Administrator peuvent créer, modifier et supprimer des utilisateurs. Il est possible de permettre la gestion des utilisateurs à certains utilisateurs en leur affectant un rôle avec des permissions de création, modification ou suppression d’utilisateurs.

## Ajouter des utilisateurs locaux

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans Administration > **Gestion Utilisateurs**.
3. Sélectionnez l’onglet **Utilisateurs** et cliquez sur **Ajouter des utilisateurs** puis **Créer Utilisateur**.

![Qalyptus Server Create Users](/img/docs-images/Qalyptus-server-create-users.png)

4. Saisissez les informations dans les champs suivants :

- **Activé** : Choisissez d’activer ou de désactiver le compte de l’utilisateur.
- **Nom complet** : Tapez le nom d’affichage de l’utilisateur (Exemple : David Page).
- **Nom d’utilisateur** : Tapez un nom unique pour l’utilisateur.
- **E-mail** : E-mail de l’utilisateur. Il doit être unique.
- **Compte de domaine** : Renseignez ce champ si vous voulez que l’utilisateur puisse se connecter avec ses identifiants Windows. Il doit être unique.
- **Langue** : Choisir la langue de l’utilisateur. Cette option peut être modifiée ultérieurement dans les paramètres du profil utilisateur.
- **Demander à l’utilisateur de créer son mot de passe** : Cochez cette case pour envoyer un e-mail à l’utilisateur avec un lien lui permettant de créer son mot de passe afin d’avoir ses identifiants Qalyptus. Si vous ne cochez pas cette case, l’utilisateur pourra créer son mot de passe dans l’interface de connexion de Qalyptus Server en cliquant sur le lien “Mot de passe oublié“.

- Ajouter un ou plusieurs rôle pour l’utilisateur. Pour cela, sélectionnez un rôle puis cliquez sur **Ajouter**.

5. Cliquez sur **Enregistrer**

## Importer des utilisateurs depuis Excel

Pour automatiser le processus d’ajout d’utilisateurs à Qalyptus, vous pouvez créer un fichier Excel contenant des informations sur les utilisateurs, puis importer le fichier.

Pour importer des utilisateurs depuis Excel :

1. Connectez-vous à Qalyptus Server en tant qu’administrateur.
2. Accédez à Administration> **Gestion Utilisateurs**.
3. Sélectionnez l’onglet Utilisateurs et cliquez sur **Ajouter des utilisateurs**, puis **Importer à partir d’Excel**.
4. Sélectionnez **Parcourir**.
5. Sélectionnez votre fichier Excel.
6. Cliquez sur **Importer les utilisateurs**.

![Qalyptus Server Import Users from Excel](/img/docs-images/Qalyptus-server-import-users-excel.png)

Vous devez utiliser un fichier Excel qui respecte l’ordre des colonnes attendues. Seule la première feuille sera utilisée. Veuillez télécharger et utiliser le modèle et suivre les instructions disponibles dans chaque colonne.

## Ajouter des utilisateurs à partir d’Active Directory

Pour ajouter des utilisateurs depuis Active Directory, faire ce qui suit :

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans Administration > **Gestion Utilisateurs**.
3. Sélectionnez l’onglet **Annuaires Utilisateurs**, cliquez sur **Créer Annuaire** et choisissez **Active Directory**.

![Qalyptus Server Import Users from Active Directory](/img/docs-images/Qalyptus-server-users-active-directory.png)

4. Saisissez les informations dans les champs suivants :

- **Nom** : Tapez le nom de l’annuaire.
- **Chemin** : Tapez le chemin LDAP.
- **Nom d’utilisateur** : Ce champ est optionnel. Si besoin, tapez le nom d’utilisateur de l’Active Directory.
- **Mot de passe**: Ce champ est optionnel. Si besoin, tapez le nom le mot de passe de l’Active Directory.
- **Filtre LDAP** : Ce champ est optionnel. Si besoin, vous pouvez appliquer un filtres sur les utilisateurs à importer.
- **Demander aux nouveaux utilisateurs de créer leur mot de passe** : Cochez cette case pour envoyer un e-mail à chaque nouvel l’utilisateur avec un lien lui permettant de créer son mot de passe afin d’avoir ses identifiants Qalyptus. Si vous ne cochez pas cette case, l’utilisateur pourra créer son mot de passe dans l’interface de connexion de Qalyptus Server en cliquant sur le lien “Mot de passe oublié“.
- **Rôle par défaut** : Vous pouvez attribuer un rôle aux utilisateurs qui seront importés d’Active Directory.
- **Synchronisation** : Vous pouvez soit lancer manuellement l’importation des utilisateurs soit programmer l’importation. Choisissez l’option Automatiquement pour programmer l’importation des utilisateurs.

5. Cliquez sur **Enregistrer**
6. Pour importer et synchroniser les utilisateurs, retournez à la page **Administration > Gestion Utilisateurs > Annuaires Utilisateurs**
7. Cliquez sur le bouton à droit de l’Active Directory à synchroniser, puis cliquez sur **Synchroniser**.

![Qalyptus Server Sync users from active directory](/img/docs-images/Qalyptus-server-users-active-directory-sync.png)

## Ajouter des utilisateurs à partir d’Azure AD

Avant de créer une importation Azure AD, vous devez enregistrer une application sur votre Azure AD. [ Voir ici comment le faire.](https://docs.microsoft.com/en-us/graph/auth-register-app-v2).

Pour ajouter des utilisateurs depuis Azure AD, faire ce qui suit :

1. Connectez vous à Qalyptus Server en tant que administrateur.
2. Allez dans Administration > **Gestion Utilisateurs**.
3. Sélectionnez l’onglet **Annuaires Utilisateurs**, cliquez sur **Créer Annuaire** et choisissez **Azure AD**.
   ![Qalyptus Server users from Azure AD](/img/docs-images/Qalyptus-server-users-azure-ad.png)
4. Saisissez les informations dans les champs suivants :

- **Nom** : Tapez le nom de l’annuaire.
- **Application ID** : Tapez l’ID d’application (client).
- **Application ID** : Tapez l’ID de l’annuaire (locataire).
- **Application ID** : Tapez la Clé Secret client nécessaire pour s’authentifier auprès d’Azure AD.
- **Demander aux nouveaux utilisateurs de créer leur mot de passe** : Cochez cette case pour envoyer un e-mail à chaque nouvel l’utilisateur avec un lien lui permettant de créer son mot de passe afin d’avoir ses identifiants Qalyptus. Si vous ne cochez pas cette case, l’utilisateur pourra créer son mot de passe dans l’interface de connexion de Qalyptus Server en cliquant sur le lien “Mot de passe oublié“.
- **Rôle par défaut** : Vous pouvez attribuer un rôle aux utilisateurs qui seront importés d’Azure AD.
- **Synchronisation** : Vous pouvez soit lancer manuellement l’importation des utilisateurs soit programmer l’importation. Choisissez l’option Automatiquement pour programmer l’importation des utilisateurs.

5. Cliquez sur Enregistrer
6. Pour importer et synchroniser les utilisateurs, retournez à la page **Administration > Gestion Utilisateurs > Annuaires Utilisateurs**
7. Cliquez sur le bouton à droit de l’Azure AD à synchroniser, puis cliquez sur Synchroniser.

:::note
La synchronisation permet d’importer les nouveaux utilisateurs et groupes et de supprimer les utilisateurs et groupes qui n’existent plus dans Active Directory ou Azure AD.
:::
