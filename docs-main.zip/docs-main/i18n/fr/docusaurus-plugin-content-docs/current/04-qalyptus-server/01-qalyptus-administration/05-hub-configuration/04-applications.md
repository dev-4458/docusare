---
title: Applications Qlik Sense
sidebar_label: Applications
---

Dans cette section, vous configurez et gérez la synchronisation des applications Qlik Sense avec Qalyptus Hub. Cela permettra aux utilisateurs de trouver au même endroit (Qalyptus HUB) leurs applications Qlik, leurs rapports et d’autres ressources.

:::note
Comme dans Qlik Sense Hub, un utilisateur ne verra que les applications auxquelles il a droit.
:::

## Synchroniser les applications Qlik Sense

Pour synchroniser les applications Qlik Sense avec Qalyptus, procédez comme suit :

1. Connectez-vous à Qalyptus Server
2. Assurez-vous que l’adresse du serveur Qlik Sense et un utilisateur Qlik Sense sont saisis dans Contigurate Hub > Général. Voir cette section pour plus de détails.
3. Allez dans Qalyptus Administration > Configuration Hub > Applications
4. Cliquez sur **Synchronisation**
5. Une nouvelle fenêtre apparaît
6. Sélectionnez le **Dossier par défaut pour les nouvelles applications**
7. Choisissez une programmation parmi vos programmations existants
8. Cliquez sur **Enregistrer**
9. Vous pouvez exécuter la synchronisation manuellement en cliquant sur **Synchroniser**

![Qalyptus Server Change App Folder](/img/docs-images/qalyptus-server-synchronization.png)

À la fin du processus de synchronisation, les nouvelles applications apparaîtront, les applications existantes seront mises à jour et les applications supprimées dans Qlik Sense seront supprimées.

Vous pouvez synchroniser une application spécifique. Cela synchronisera uniquement les métadonnées de cette application.

## Configurations disponibles pour une application Qlik Sense

Pour une meilleure expérience utilisateur, vous pouvez configurer chaque application Qlik Sense pour qu’elle apparaisse de la manière souhaitée dans Qalyptus HUB.

- Vous pouvez choisir dans quel dossier ou sous-dossier l’application sera située
- Si vous gérez différentes Organisations, vous pouvez choisir une organisation pour l’application. Seuls les membres de l’organisation peuvent voir l’application (un membre doit également être autorisé dans Qlik Sense)
- Créez un mashup. Vous pouvez facilement créer un mashup personnalisé et le lier à l’application. Les utilisateurs pourront ouvrir l’application en tant qu’application Qlik Sense standard ou en tant que mashup
- Choisissez si vous souhaitez autoriser d’ouvrir l’application en tant qu’application standard, comme un mashup, ou les deux
- Choisissez ce qui se passera lorsque l’utilisateur cliquera sur l’image de l’application : ouvrir l’application en tant qu’application standard ou en tant que mashup. Cette option dépend du choix de l’option précédente.

![Qalyptus Server Configure App](/img/docs-images/qalyptus-server-configure-app.png)

## Créer un mashup avec une application Qlik Sense

Dans Qalyptus Hub, vous pouvez autoriser l’ouverture d’une application Qlik Sense de manière standard (comme dans Qlik Sense Hub) ou en tant que mashup personnalisé.

Voici comment créer un mashup :

1. Dans Qalyptus Administration> Configuration Hub> Applications, Editer une application
2. Sélectionnez un Modèle de Mashup
3. Cliquez sur Configurer
4. Une nouvelle fenêtre apparaît
5. Donnez un nom au Mashup
6. Si nécessaire, saisissez un autre ID de thème Qlik Sense (facultatif)
7. Sélectionnez les feuilles de l’application que vous souhaitez ajouter au mashup
8. Renommer les feuilles (facultatif)
9. Modifier l’ordre des feuilles (facultatif)
10. Pour chaque feuille, afficher ou non la barre d’outils des sélections
11. Mettre les feuilles en groupes (facultatif)
12. Cliquez sur Aperçu pour voir le résultat
13. Cliquez sur Enregistrer

![Qalyptus Server Configure App Mashup](/img/docs-images/qalyptus-server-configure-app-mashup.png)

Dans l’option “Ouvrir en tant que”, choisissez “Mashup” ou “Application et Mashup”

![Qalyptus Server Configure App Mashup](/img/docs-images/qalyptus-server-configure-app-mashup-options.png)

Dans Qalyptus HUB, l’application peut désormais être ouverte avec le Mashup configuré.

![Qalyptus Server App Mashup Opened](/img/docs-images/qalyptus-server-hub-open-app-as-mashup.png)

**L’application ouverte en tant que Mashup**

![Qalyptus Server C](/img/docs-images/qalyptus-server-open-app-with-mashup.png)
