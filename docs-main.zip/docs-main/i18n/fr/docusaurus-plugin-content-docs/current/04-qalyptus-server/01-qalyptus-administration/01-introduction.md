---
title: Introduction
---

Après l’installation de Qalyptus Server, la première étape consiste à configurer Qalyptus Server avant de commencer à générer les rapports.

Dans cette section, nous aborderons les éléments suivants :

- Les paramètres généraux
- La Gestion des utilisateurs
- Système

## Administration de Qalyptus Server (en anglais)

<iframe width="560" height="315" src="https://www.youtube.com/embed/fNlpQUN3qBQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>