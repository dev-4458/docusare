---
title: Origines Autorisées
---

Avec Qalyptus Server API, vous pouvez faire des actions, comme exécuter des taches, depuis des applications web externes. Pour des raisons de sécurité, vous pouvez choisir la liste des adresses autorisées à faire des appels vers votre Qalyptus Server.

Exemple : Si vous souhaitez utiliser l’extension Qalyptus On-Demand pour générer vos rapports Qalyptus depuis Qlik Sense, vous devez ajouter l’adresse de votre serveur Qlik Sense en tant que origine autorisée.

## Ajouter une origine

Pour ajouter une adresse autorisée, suivez les étapes suivantes :

1. Connectez vous à Qalyptus Server
2. Allez dans Administration> Système> Origines Autorisées.
3. Cliquez Ajouter Origine

![Qalyptus Server System Trusted Origins](/img/docs-images/Qalyptus-server-system-trusted-origins.png)

4. Saisissez les informations dans les champs suivants :

- **Nom** : Entrez un nom pour l’origine.
- **Description** : Entrez une description pour l’origine (optionnel).
- **Adresse** : Entrez l’adresse à autoriser.

5. Cliquez sur **Enregistrer**.
