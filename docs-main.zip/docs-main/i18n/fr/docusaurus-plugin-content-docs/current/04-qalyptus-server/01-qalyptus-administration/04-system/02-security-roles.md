---
title: Rôles de sécurité
---

Lorsque vous ajoutez des utilisateurs à Qalyptus Server, vous devez leur appliquer un rôle. Les rôles correspondent au niveau maximum d’accès qu’un utilisateur peut avoir sur Qalyptus Server. Avec les permissions, le rôle détermine qui peut publier, modifier, supprimer ou uniquement voir le contenu, ou qui peut gérer les utilisateurs et administrer.

Lors de l’installation de Qalyptus Server, trois rôles par défaut sont créés : Administrators, Developers et Users. Vous pouvez voir les permissions de ces rôles sans pouvoir les modifier ou les supprimer.

## Créer un rôle

Les d’autorisations de contenu détermine le niveau d’accès dont un utilisateur dispose sur Qalyptus Server. les autorisations peuvent être appliquées sur tous les projets ou sur des projets spécifiques.

:::note
Un utilisateur peut avoir plusieurs rôles. Dans ce cas, ses droits sont l’union des permissions de ses rôles.
:::

Pour créer un rôle, suivez les étapes ci-dessous :

1. Connectez vous à Qalyptus Server.
2. Allez dans **Administration> Système> Rôles de Sécurité**.
3. Cliquez sur **Créer Rôle**.
   ![Qalyptus Server System Roles](/img/docs-images/Qalyptus-server-system-roles.png)

4. Saisissez les informations dans les champs suivants:

- **Activé** : Choisissez d’activer ou de désactiver le rôle.
- **Nom** : Entrez le nom du rôle.
- **Description** : Entrez une description pour le rôle (optionnel).
- **Permissions** : Choisissez les permissions du rôle.
  - Pour les Projets (connections, filtres et rapports) et les Tâches, il possible d’appliquer des permissions sur des projets spécifiques. Cochez la case “Tous les projets” pour appliquez des permissions à tous les projets présent dans Qalyptus Server. Si vous souhaitez sélectionnez des projets en particulier, décochez la case et sélectionnez les projets de votre choix

5. Cliquez sur **Enregistrer**.
