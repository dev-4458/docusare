---
title: Tableau de bord
---

Afin d’avoir une vision globale sur l’utilisation de Qalyptus Server, accédez au tableau de bord de **Qalyptus** en cliquant sur le menu **Qalyptus** **Administration** qui se trouve à coté de votre nom d’utilisateur, puis cliquez sur **Tableau de bord**. Ce tableau de bord vous permet d’avoir simultanément des informations sur l’ensemble des entités de votre Qalyptus Server.

![Qalyptus Server Dashboard](/img/docs-images/Qalyptus-server-dashboard.png)

Vous trouverez dans cette page les éléments suivants :

- **Projets** : Il s’agit du nombre de projets dans Qalyptus Server. Vous avez également une information sur le nombre de projets utilisés dans au moins une tâche programmée.
- **Rapports** : Il s’agit du nombre de rapports dans Qalyptus Server. Vous avez également une information sur le nombre de rapports utilisés dans une ou plusieurs tâches.
- **Destinations** : Il s’agit du nombre de destinations dans Qalyptus Server. Vous avez également une information sur le nombre de destinations utilisés dans une ou plusieurs tâches.
- **Tâches** : Il s’agit du nombre de tâches dans Qalyptus Server avec une information sur le nombre de tâches qui ont une ou plusieurs programmations.
- **Répartition de l’état des tâches** : Il s’agit d’un graphique en secteur qui représente la répartition des tâches programmées en fonction de leur statut.
- **Programmées pour les 7 prochains jours** : Affiche la liste des tâches programmées qui vont s’exécuter dans les 7 prochains jours avec la date et l’heure de l’exécution.

Dans la page Tableau de bord et dans l’onglet **Administrateurs**, vous trouverez la liste des utilisateurs ayant un rôle d’administrateur.
