---
title: Profil Utilisateur
---

Dans Qalyptus Server, votre page de profil vous permet d’afficher des informations sur votre compte et de gérer vos informations d’identification, ainsi que les options de l’interface utilisateur dans un emplacement centralisé.

En haut d’ page, cliquez sur l’image de votre profil, puis sélectionnez **Profil**. La page ci-dessous s’affiche.

![Qalyptus Server User Profile](/img/docs-images/Qalyptus-server-user-profile.png)

Sur cette page, vous pouvez apporter les modifications suivantes :

- l’image de votre profil : Cliquez sur le lien **Changer**, puis charger votre image.
- Le mot de passe Qalyptus : Cliquez sur **Changer mot de passe** et entrez votre mot de passe actuel et votre nouveau mot de passe, puis cliquez sur **Mettre à jou**r.
- La langue d’interface : Sélectionnez une langue dans la liste déroulante **Langue**.
- Le fuseau horaire de l’abonnement : Sélectionnez le **fuseau horaire** qui sera utilisé pour exécuter vos abonnements aux rapports.
