---
title: Présentation
id: presentation
---

**Qalyptus** est conçu pour vous aider à créer des rapports à partir des plates-formes Qlik. Avec Qalyptus, vous pouvez créer des rapports personnalisés à l’aide de graphiques, de tableaux et de variables. Qalyptus vous permet de générer des rapports dans différents formats et de les distribuer à un nombre illimité d’utilisateurs.

Qalyptus est conçu pour simplifier la génération de vos rapports à partir de modèles que vous avez conçus. La plateforme Qalyptus est composée de deux outils:

Qalyptus Desktop : qui vous permet de concevoir des modèles et de créer des rapports

Qalyptus Serveur : vous permet de planifier, générer et distribuer des rapports.

# Caractéristiques principales

Vous trouverez ci-dessous les principales caractéristiques de Qalyptus. D’autres fonctionnalités seront bientôt disponibles.

- Rapports avec les formats Microsoft Office
- Rapports à partir de multiples documents QlikView et applications Qlik Sense
- Exporter des rapports au format PDF, Excel, Word, PowerPoint, Html, Csv, Tiff, Xps, Pps, …
- Dénomination dynamique des rapports
- Rapports d’itération (crée un rapport pour chaque valeur de dimension)
- Sauvegarde des rapports dans des dossiers ou dans des services de stockage de fichier (FTP, Dropbox, OneDrive, Google Drive, …)
- Envoi des rapports par mail
- Génération de rapports à la demande depuis Qlik Sense
- Génération de rapports avec Conditions
- Gestion avancée des permissions
- Duplication des Modèles, rapports et tâches
- Filtrer avec des champs
- Filtrer avec des variables
- Filtrer avec des favoris
- Réutiliser un modèle existant
- Notifications d’échec de tâche
- Multi-langues
- Les journaux
