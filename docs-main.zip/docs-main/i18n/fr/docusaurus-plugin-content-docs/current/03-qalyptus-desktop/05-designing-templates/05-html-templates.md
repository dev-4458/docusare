---
title: Les modèles HTML
---

Dans cette section, nous allons créer un modèle HTML à l’aide d’objets Qlik Sense.

Pour créer un modèle HTML, allez dans l’onglet Modèles et cliquez sur le bouton Créer. Votre écran ressemblera à ceci:

![Qalyptus HTML Template](/img/docs-images/qalyptus_excel_template.png)

1. Dans le menu déroulant Type, sélectionnez HTML
2. Donnez un nom à votre modèle. Exemple: Modèle Performance HTML
3. Il est recommandé d’ajouter une description
4. Vous avez deux options pour créer un nouveau modèle. Vous pouvez cliquer ![](/img/docs-images/open-template.png) pour créer un nouveau fichier HTML ou cliquer ![](/img/docs-images/browse-file.png) pour créer votre modèle à partir d’un fichier HTML existant
5. Enregistrez votre travail

Cliquez ![](/img/docs-images/open-template.png) pour créer un nouveau fichier HTML. Votre écran ressemblera à ceci :

![Qalyptus HTML Template File](/img/docs-images/qalyptus-html-template-file.png)

1. Un fichier HTML est ouvert dans Qalyptus
2. Connexions: liste des connexions Qlik Sense et QlikView créées dans la page **Connexions**
3. Variables: liste des variables Qlik des connexions sélectionnées. Sélectionnez celles que vous souhaitez utiliser
4. Objets: liste des tableaux, graphiques et Eléments Principaux des connexions sélectionnées. Sélectionnez ceux que vous souhaitez utiliser
5. Utilisé: vous trouverez ici les objets et les variables que vous souhaitez utiliser dans votre modèle
6. Le bouton Enregistrer vous permet d’enregistrer le modèle
7. Le bouton Aperçu vous permet d’avoir un aperçu du rapport

## Add objects to create the template

This short video will show how to use your Qlik Sense objects to create a simple HTML template.

<iframe width="560" height="315" src="https://www.youtube.com/embed/RL96r3kgATY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Options avancées

### 1- Ajouter un filtre à un objet

En plus d’appliquer des filtres au niveau du rapport et au niveau de la tâche, vous pouvez appliquer un filtre pour chaque objet Qlik que vous utilisez dans votre modèle.

Faites un clic droit sur l’objet pour lequel vous souhaitez ajouter un filtre, puis sélectionnez **Propriétés**. Dans l’écran Propriétés, sélectionnez le filtre à appliquer parmi les filtres disponibles.
Un seul filtre peut être appliqué à un objet.

![Qalyptus Object Filter HTML](/img/docs-images/Qalyptus-object-filter-html.png)

### 2- Exporter un objet Qlik Sense en tant qu’image avec une dimension différente de la dimension d’utilisation dans le fichier modèle

Lorsque vous souhaitez utiliser un objet Qlik Sense (graphique ou tableau) en tant qu’image dans votre modèle de rapport, faites glisser et déposer l’objet dans le fichier modèle. Qalyptus créera une image de substitution que vous pourrez redimensionner. Lorsque vous générez le rapport, Qalyptus exporte l’objet Qlik Sense avec la dimension de l’image de substitution et le place à la place de l’image de substitution.

Il est possible d’exporter l’image avec une grande ou une petite taille par rapport à la taille de l’image de substitution. Par exemple, exporter l’image avec 1200 x 800 px et utiliser-la dans le fichier avec la taille 1000 x 600 px.

Sélectionnez l’option **Dimensions d’export personnalisées** dans les Propriétés de l’objet, puis entrez la valeur **Hauteur** et **Largeur**.

![Export Image With Custom Size](/img/docs-images/export-image-with-custom-size.png)

Exporter un objet de grande taille permet d’obtenir plus d’informations ; car Qlik Sense peut masquer certaines informations lorsque vous réduisez la taille de l’objet.

**Graphique avec une petite taille (taille d’exportation = taille d’utilisation)**

![Chart small size](/img/docs-images/Chart-small-size.png)

**Le même graphique avec une grande taille d’exportation (taille d’exportation > taille d’utilisation)**

![Chart large size](/img/docs-images/Chart-large-size.png)

### 3- Répétez les graphiques et les tableaux dans une div pour chaque valeur d’une dimension

Vous pouvez répéter le contenu d’une div HTML pour chaque valeur d’un champ de dimension. Vous pouvez imbriquer les niveaux de répétition autant de fois que vous le souhaitez.

<iframe width="560" height="315" src="https://www.youtube.com/embed/83YYLcUrsPI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Statuts

Un modèle peut avoir trois statuts différents :

- <span style={{color: "green"}}>Modèle valide</span>
- <span style={{color: "red"}}>Fichier inexistant</span>
- <span style={{color: "red"}}>Aucun objet ou variable utilisé</span>
