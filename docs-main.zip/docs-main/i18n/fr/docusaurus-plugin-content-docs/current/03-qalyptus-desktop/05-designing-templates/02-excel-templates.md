---
title: Les modèles Excel
---

Dans cette section, nous allons créer un modèle Excel à l’aide d’objets Qlik Sense.

Pour créer un modèle Excel, allez dans l’onglet **Modèles** et cliquez sur le bouton **Créer**. Votre écran ressemblera à ceci :
![Qalyptus Excel Template](/img/docs-images/qalyptus_excel_template.png)

1. Dans le menu déroulant **Type**, sélectionnez Excel
2. Donnez un nom à votre modèle. Exemple: Performance Excel template
3. Il est recommandé d’ajouter une description
4. Vous avez deux options pour créer un nouveau modèle. Vous pouvez cliquer ![](/img/docs-images/open-template.png) pour créer un nouveau fichier Excel ou cliquer ![](/img/docs-images/browse-file.png) pour créer votre modèle à partir d’un fichier Excel existant
5. Enregistrez votre travail

Cliquez ![](/img/docs-images/open-template.png) pour créer un nouveau fichier Excel. Votre écran ressemblera à ceci :

![Qalyptus Excel Template File](/img/docs-images/qalyptus_excel_template-file.png)

1. Un fichier Excel est ouvert dans Qalyptus
2. Connexions: liste des connexions Qlik Sense et QlikView créées dans la page **Connexions**
3. Variables: liste des variables Qlik des connexions sélectionnées. Sélectionnez celles que vous souhaitez utiliser
4. Objets: liste des tableaux, graphiques et Eléments Principaux des connexions sélectionnées. Sélectionnez ceux que vous souhaitez utiliser
5. Utilisé: vous trouverez ici les objets et les variables que vous souhaitez utiliser dans votre modèle
6. Le bouton Enregistrer vous permet d’enregistrer le modèle
7. Le bouton Aperçu vous permet d’avoir un aperçu du rapport

## Ajouter des objets pour créer le modèle

Dans cette courte vidéo, vous verrez comment utiliser vos objets Qlik Sense pour créer un modèle Excel simple.

<iframe width="560" height="315" src="https://www.youtube.com/embed/pKtDxV5C9nM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Options avancées

### 1- Ajouter un filtre à un objet

En plus d’appliquer des filtres au niveau du rapport et au niveau de la tâche, vous pouvez appliquer un filtre pour chaque objet Qlik que vous utilisez dans votre modèle.

Faites un clic droit sur l’objet pour lequel vous souhaitez ajouter un filtre, puis sélectionnez **Propriétés**. Dans l’écran Propriétés, sélectionnez le filtre à appliquer parmi les filtres disponibles.
Un seul filtre peut être appliqué à un objet.

![Qalyptus Object Filter Excel](/img/docs-images/Qalyptus-object-filter-excel.png)

### 2- Ne pas insérer de nouvelles lignes

Lorsque vous utilisez un tableau, Qalyptus, par défaut, insère de nouvelles lignes pour conserver la même mise en page de vos différents objets. Mais dans certains cas, vous voudrez peut-être que Qalyptus n’insère pas de lignes; par exemple, lorsque vous avez plusieurs objets les uns à côté des autres.

Vous avez la possibilité de ne pas insérer de lignes lors de l’exportation d’un tableau.

Faites un clic droit sur un objet tableau ou tableau croisé dynamique, puis sélectionnez **Propriétés**. Dans l’écran Propriétés, cochez la case **Ne pas insérer lignes**.

![Not Insert Rows](/img/docs-images/Not-insert-rows.png)

### 3- Choisissez la présentation des lignes de tableau croisé dynamique

Vous pouvez choisir comment vous souhaitez exporter un tableau croisé dynamique. Vous avez le choix entre : Par défaut (les paramètres choisis dans Qlik Sense), Tout développer ou Tout réduire.

![PivotTable Rows Presentation](/img/docs-images/PivotTable-rows-presentation.png)

### 4- Exporter un objet Qlik Sense en tant qu’image avec une dimension différente de la dimension d’utilisation dans le fichier modèle

Lorsque vous souhaitez utiliser un objet Qlik Sense (graphique ou tableau) en tant qu’image dans votre modèle de rapport, faites glisser et déposer l’objet dans le fichier modèle. Qalyptus créera une image de substitution que vous pourrez redimensionner. Lorsque vous générez le rapport, Qalyptus exporte l’objet Qlik Sense avec la dimension de l’image de substitution et le place à la place de l’image de substitution.

Il est possible d’exporter l’image avec une grande ou une petite taille par rapport à la taille de l’image de substitution. Par exemple, exporter l’image avec 1200 x 800 px et utiliser-la dans le fichier avec la taille 1000 x 600 px.

Sélectionnez l’option **Dimensions d’export personnalisées** dans les Propriétés de l’objet, puis entrez la valeur **Hauteur** et **Largeur**.

![Export Image with Custom Size](/img/docs-images/export-image-with-custom-size.png)

Exporter un objet de grande taille permet d’obtenir plus d’informations ; car Qlik Sense peut masquer certaines informations lorsque vous réduisez la taille de l’objet.

**Graphique avec une petite taille (taille d’exportation = taille d’utilisation)**

![Chart small size](/img/docs-images/Chart-small-size.png)

**Le même graphique avec une grande taille d’exportation (taille d’exportation > taille d’utilisation)**

![Chart large size](/img/docs-images/Chart-large-size.png)

### 5- Répétez les graphiques et les tableaux dans la même feuille ou créez une feuille pour chaque valeur d’une dimension

Qalyptus permet de répéter les données par dimension dans un rapport. Vous pouvez répéter des images, des tableaux et des variables.

Vous pouvez répéter le contenu d’une feuille pour créer une nouvelle feuille pour chaque valeur d’un champ de dimension.

Vous pouvez également répéter vos objets Qlik Sense sur une seule feuille pour une valeur de champ. Vous pouvez imbriquer les niveaux de répétition autant de fois que vous le souhaitez.

Voyez comment vous pouvez le faire.

<iframe width="560" height="315" src="https://www.youtube.com/embed/0CZPq0Bwp7k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

### 6- Répétez la ligne d’en-tête du tableau sur les pages pour une exportation PDF

Pour répéter la première ligne d’en-têtes de colonne sur toutes les pages lorsque vous avez une feuille de calcul volumineuse et complexe, faites glisser et déposez les colonnes de l’objet tableau puis:

1. Dans Excel, cliquez sur l’onglet **Mise en page**
2. Dans le groupe **Mise en page**, cliquez sur **Imprimer les titres**
3. Sous l’onglet **Feuille**, dans le champ **Lignes à répéter en haut**, cliquez sur l’icône à droite
4. Sélectionnez la ligne que vous souhaitez voir apparaître en haut de chaque page. Appuyez sur la touche **Entrée**
5. Cliquez ensuite sur **OK**

![Repeat Table Header Excel](/img/docs-images/Repeat-table-header-Excel.png)

Voici le résultat

![Repeat Table Header Excel Result](/img/docs-images/Repeat-table-header-excel-result.gif)

## Statuts

Un modèle peut avoir trois statuts différents :

- <span style={{color: "green"}}>Modèle valide</span>
- <span style={{color: "red"}}>Fichier inexistant</span>
- <span style={{color: "red"}}>Aucun objet ou variable utilisé</span>
