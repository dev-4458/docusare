---
title: Introduction
---

Qalyptus vous permet de créer vos rapports personnalisés à l’aide de modèles.

Créez un modèle à l’aide d’Office Excel, Word et PowerPoint pour générer des rapports dans des formats standard tels que PDF, Excel, Word, PowerPoint et HTML.

:::note
Lorsque vous créez un modèle, vous pouvez l’utiliser dans un ou plusieurs rapports. Si plusieurs rapports doivent utiliser le même modèle, vous pouvez conserver un seul modèle et être sûre que les rapports utilisent le même modèle.
:::

Voir comment créer:

- [Des modèles Excel](/products/qalyptus/qalyptus-desktop/designing-templates/excel-templates)
- [Des modèles Word](/products/qalyptus/qalyptus-desktop/designing-templates/word-templates)
- [Des modèles PowerPoint](/products/qalyptus/qalyptus-desktop/designing-templates/powerpoint-templates)
- [Des modèles HTML](/products/qalyptus/qalyptus-desktop/designing-templates/html-templates)
