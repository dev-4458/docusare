---
title: Générer des rapports
---

Pour générer vos rapports Qalyptus, vous devez créer des tâches qui contiendront les rapports à générer.

Une tâche peut contenir un ou plusieurs rapports avec un ou plusieurs formats.

Vous pouvez ajouter des filtres à une tâche. Qalyptus applique des filtres de tâches et de rapports avant de générer des rapports. En savoir plus sur [les filtres](/products/qalyptus/qalyptus-desktop/create-filters).

Pour créer une tâche, allez dans l’onglet **Tâches** et cliquez sur le bouton **Créer**. Votre écran ressemblera à ceci:

![Qalyptys Tasks](/img/docs-images/qalyptys_tasks.png)

1. Donnez un nom à votre rapport. Exemple : Performance task
2. Il est recommandé d’ajouter une description
3. Dans le menu déroulant Destination, sélectionnez Performance files. Cette destination a été créée dans [ l’onglet Destination](/products/qalyptus/qalyptus-desktop/create-destinations).
4. Cliquez sur le bouton **Rapports** pour ajouter des rapports à votre tâche. Une nouvelle fenêtre s’ouvrira

Nous allons ajouter deux rapports à la tâche.

- Le premier est le rapport d’itération : rapports sur les performances commerciales par marché régional.
- Le second est un rapport unique : un rapport sur les performances commerciales de toute l’entreprise.

![Qalyptys Task Reports](/img/docs-images/qalyptus_task_reports.png)

1. Cliquez ![](/img/docs-images/add-task-report.png) pour ajouter un rapport
2. Dans le menu déroulant **Rapport**, sélectionnez un rapport.
3. Dans le menu déroulant **Format**, sélectionnez un format avec lequel le rapport sera généré.
4. Cliquez sur le bouton **OK** pour valider votre travail.

Enfin, cliquez sur Enregistrer pour créer et enregistrer la tâche. Votre tâche est maintenant créée et peut être exécutée.

![Qalyptys Task Created](/img/docs-images/qalyptus_task_created.png)

Sélectionnez la tâche et cliquez sur **Exécuter** pour générer vos rapports. À la fin de la génération, Qalyptus créera six fichiers avec l’extension Pptx et un fichier avec l’extension PDF.

## Statuts

Une tâche peut avoir cinq statuts différents:

- <span style={{color: "green"}}>Tâche valide</span>
- <span style={{color: "red"}}>Aucune destination ou rapport affecté à la tâche</span>
- <span style={{color: "red"}}>La destination de la tâche n’est pas valide</span>
- <span style={{color: "red"}}>Les rapports de la tâche ne sont pas valides</span>
- <span style={{color: "red"}}>Les filtres de la tâche ne sont pas valides</span>

:::note
Une tâche ne peut pas être exécutée s’il y a une ou plusieurs erreurs.
:::
