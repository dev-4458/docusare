---
title: Prise en main
---

Dans cette section, vous apprendrez avec la vidéo comment créer votre premier projet Qalyptus en 5 minutes.

Pour créer et générer vos rapports avec Qalyptus, vous devez :

- Créez une connexion à votre application Qlik Sense ou QlikView.
- Créez une destination pour stocker vos fichiers.
- Créer un modèle de rapport (Excel, Word, PowerPoint, ..).
- Créer un rapport en utilisant un modèle.
- Et enfin créer une tâche et commencer la génération.

## Commencer avec Qalyptus (en anglais)

<iframe width="560" height="315" src="https://www.youtube.com/embed/KR55Ve_JE1A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
