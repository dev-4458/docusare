---
title: Create reports
---

Qalyptus vous permet de créer des rapports QlikView et Qlik Sense basés sur des modèles personnalisés.

## Créer un rapport simple

Pour créer un rapport, allez dans l’onglet **Rapports** et cliquez sur le bouton **Créer**. Votre écran ressemblera à ceci :

![Qalyptus Report](/img/docs-images/qalyptus_report.png)

1. Donnez un nom à votre rapport. Exemple : rapport Performance PowerPoint report
2. Il est recommandé d’ajouter une description
3. Dans le menu déroulant Modèle, sélectionnez Performance PowerPoint report.
4. Si vous le souhaitez, vous pouvez attribuer un nom dynamique à votre rapport en cliquant sur le bouton Nom dynamique. Plus de détails dans la section Créer un rapport d’itération.
5. Vous pouvez filtrer vos données avant de générer votre rapport en ajoutant un ou plusieurs filtres. En savoir plus [sur les filtres](/products/qalyptus/qalyptus-desktop/create-filters).
6. Enfin, cliquez sur Enregistrer pour créer et enregistrer le rapport.

Votre rapport est créé et peut être utilisé dans les tâches.

## Créer un rapport d’itération

Avec Qalyptus, vous pouvez également créer votre rapport par dimension. Par exemple: Année, Région ou Vendeur. Vous pouvez utiliser une dimension ou combiner plusieurs dimensions telles que Année-> Vendeur.

Pour créer un rapport de itération, procédez comme suit:

- Suivez les mêmes étapes pour créer un rapport simple.
- Cliquez sur le bouton Champs d’itération. Une nouvelle fenêtre s’ouvrira.

![Qalyptus Interaction Fields](/img/docs-images/qalyptus_iteration_fields.png)

1. Sélectionnez la connexion **Performance** dans la liste des connexions.
2. Choisissez le champ **Region Market** dans la liste Champs.
3. Cliquez sur le bouton **Ajouter**.
4. Votre filtre est ajouté.
5. Cliquez sur le bouton **OK** pour valider votre travail.

Lorsque vous générez le rapport, vous aurez six fichiers différents car il y a six valeurs dans le champ **Region Market.**

:::note
Pour être sûr que chaque nom de fichier sera unique, vous devez attribuer un nom dynamique à votre rapport. Pour que le nom soit unique, il doit contenir les valeurs du champ d’itération ou une variable avec une valeur unique pour chaque valeur du champ d’itération.
:::

Dans notre cas, nous allons créer un nom dynamique composé du nom du rapport et de la valeur du champ de vision : Performance PowerPoint report_Region Market

Pour créer un nom dynamique, cliquez sur le bouton **Nom dynamique**. Une nouvelle fenêtre s’ouvrira.

![Qalyptus Dynamic Name](/img/docs-images/qalyptus_dynamic_name.png)

1. Cliquez sur **Nom du rapport**.
2. Cliquez sur **Champs d’itération**.
3. Les champs Nom du rapport et Itération sont ajoutés au nom dynamique.
4. Par défaut, le séparateur est “\_”. Vous pouvez le changer.
5. Cliquez sur le bouton **OK** pour valider votre travail.

Votre écran ressemblera à ceci :

![Qalyptus Interaction Report](/img/docs-images/qalyptus_iteration_report.png)

Enfin, cliquez sur **Enregistrer** pour créer et enregistrer le rapport.

Votre rapport est créé et peut être utilisé dans les tâches.

## Créer un rapport d’itération avec un champ lié entre plusieurs applications Qlik Sense

Vous pouvez créer un rapport d’itération à l’aide du même champ de dimension dans plusieurs applications Qlik Sense. Par exemple, créer un rapport pour les commerciaux à l’aide de deux applications Qlik Sense contenant le champ Commerciaux. Qalyptus parcourera les valeurs des deux champs simultanément et générera les fichiers.

![Linked Iteration Fields](/img/docs-images/Linked-Iteration-fields.png)

Il existe des limite pour cette fonctionnalité.

- Le champ d’itération doit avoir le même nom dans toutes les applications à lier.
- Qalyptus va prendre dans l’ordre le premier champ comme champ de référence, il va parcourir les valeurs de ce champ. Si dans les autres applications la valeur existe mais qu’elle n’est pas disponible (en couleur gris), elle sera tout de même sélectionnée dans ces applications. Si le champ de référence ne contient pas une valeur X et que cette valeur existe dans les autres applications, la valeur ne sera pas sélectionnée et aucun rapport ne sera généré pour cette valeur.
- La fonctionnalité ne fonctionne pas comme attendu quand on utilise plusieurs champs imbriqués.

## Statuts

Un rapport peut avoir quatre statuts différents :

- <span style={{color: "green"}}>Report valide</span>
- <span style={{color: "red"}}>Aucun modèle assigné à ce rapport</span>
- <span style={{color: "red"}}>Le modèle de ce rapport n’est pas valide</span>
- <span style={{color: "red"}}>Un ou plusieurs filtres de ce rapport ne sont pas valides</span>
