---
title: Publier un projet
---

Lorsque votre projet Qalyptus est prêt, vous pouvez le publier sur Qalyptus Server afin d’automatiser la génération et la distribution des rapports et le mettre à disposition d’autres utilisateurs.

## Publier depuis Qalyptus Desktop

Pour publier votre projet depuis Qalyptus Desktop vers Qalyptus Server suivez les étapes ci-dessous.

1. Ouvrez Qalyptus Desktop.
2. Si vous n’êtes pas déjà connecté à Qalyptus Server, connectez-vous :

- Cliquez sur le bouton Paramètres
- Allez dans l’onglet Mon compte.
- Entrez l’adresse de votre Qalyptus Server et cliquez sur Connecter.
- Vous serez redirigé vers Qalyptus Server pour l’authentification.
- Après une authentification réussie, vous verrez un message de confirmation.

![Qalyptys Server My Account](/img/docs-images/qalyptus-server-my-account.png)

3. Fermez la page des **Paramettres**
4. Cliquez sur le bouton **Publier sur le serveur** ![](/img/docs-images/qalyptus-publish-to-server-icon.png)
5. Une fenêtre s’ouvre. Si vous souhaitez publier les fichier modèle également, cochez la case Publier les fichier modèles.
6. Cliquez sur le bouton Publier.
7. Un message de confirmation s’affiche si votre projet est correctement publié.

Une fois la publication effectuée, votre projet est disponible sur Qalyptus Server dans l’onglet **Projet** avec toutes ses informations.

A tout moment, vous pouvez publier à nouveau le projet pour le mettre à jour sur Qalyptus Server.

## Utiliser le moteur de serveur Qalyptus

Cette fonctionnalité permet d’utiliser le moteur de Qalyptus Server pour actualiser les connexions et générer les rapports. Cela signifie que Qlyptus Desktop ne communiquera pas directement avec Qlik Sense et n’utilisera pas les ressources (RAM et CPU) de la machine sur laquelle il est installé.

### Quand utiliser cette option?

- Lorsque vous ne souhaitez pas installer les certificats Qlik Sense sur le PC sur lequel Qalyptus Desktop est installé. La communication avec Qlik Sense se fait uniquement via Qalyptus Server.
- Lorsque vous travaillez avec une application Qlik Sense volumineuse. Qalyptus Desktop est un programme 32 bits. Un programme qui utilise 32 bits de RAM ne peut adresser que 4 Go. Qalyptus Server est un programme 64 bits.

:::note
Les fichiers modèles sont stockés au niveau de la machine de Qalyptus Server à cet emplacement : `\ProgramData\Qalyptus\QalyptusServer\Templates\<nom du projet>`. Pendant la publication, cochez Publier les fichiers modèles pour enregistrer automatiquement les fichiers modèles sur Qalyptus Server.
:::
