---
title: Créer des filtres
---

Qalyptus vous permet d’appliquer des filtres aux objets, rapports et tâches avant de générer vos rapports. Les filtres peuvent être avec des valeurs statiques ou dynamiques en utilisant les expressions Qlik Sense ou QlikView . Les expressions doivent utiliser les règles et la syntaxe Qlik Sense ou QlikView et renvoyer une valeur unique.

:::note
Les filtres sont évalués dans l’ordre suivant: tâche -> rapport – objet.

Exemple: Si le filtre utilisé dans la tâche est “Ville = Paris, Munich” et que le filtre utilisé dans le rapport est “Ville = Londres”, le filtre qui sera appliqué est “Ville = Londres”.
:::

Le filtre n’écrasera pas nécessairement les sélections antérieures. Un filtre peut être ajouté à la sélection actuelle s’il est appliqué à une valeur possible d’un champ.

Avec Qalyptus, vous pouvez créer trois types de filtres:

- **Filtrer avec des champs**
- **Filtrer avec des variables**
- **Filtrer avec des favoris**

Pour créer un filtre, allez dans l’onglet **Filtres** et cliquez sur le bouton **Créer**. Votre écran ressemblera à ceci :

![Qalyptus Create Filter Start Page](/img/docs-images/qalyptus-create-filter-start-page.png)

1. Donnez un nom à votre filtre. Exemple: marché européen
2. Il est recommandé d’ajouter une description
3. Cliquez sur le bouton Ajouter des **Valeurs**

Votre écran ressemblera à ceci :

![Qalyptus Create Filter](/img/docs-images/qalyptus-create-filter.png)

Votre filtre peut être constitué de valeurs de champ, de variables et de favoris. Notez que l’ordre est important. Ajoutez les éléments du filtre dans l’ordre dans lequel vous souhaitez que Qalyptus les applique.

## Filtrer avec des champs

En utilisant la connexion “Executive Dashboard”, nous allons créer un filtre sur le champ **Region**. Nous voulons filtrer sur les pays européens.

- Le champ **Region** contient les valeurs suivantes : Germany, Japan, Nordic, Spain, UK and USA
- Notre filtre sera: **Region** = Germany, Nordic, Spain, UK

Pour créer le filtre, cliquez sur le bouton **Ajouter un champ**. Votre écran ressemblera à ceci :

![Qalyptus Filter Fields Values](/img/docs-images/qalyptus-filter-fields-values.png)

1. Sélectionnez la connexion **Executive Dashboard** dans la liste des connexions
2. Choisissez le champ **Region** dans la liste des champs
3. La case à cocher **Effacer la sélection** vous permet d’effacer les sélections de champs. Si cette case est cochée, les valeurs ajoutées ne sont pas prises en compte. Dans notre cas, **laissez la case Effacer la sélection** décochée
4. Cliquez sur le bouton **Ajouter**
5. Maintenant, ajoutez les quatre valeurs sur lesquelles vous souhaitez filtrer : Germany, Nordic, Spain, UK. Vous remarquez que l’évaluation par défaut est “valeur”. Dans le menu déroulant Evaluation, vous pouvez choisir parmi:

   - Valeur: Utilisez cette option pour définir une valeur statique. Exemple: **Germany**
   - Valeur d’évaluation (`=,>,> =, <, <=, <>`) : Choisissez cette option pour sélectionner une ou plusieurs valeurs à l’aide d’une expression Qlik ou d’une valeur statique. Exemple 1 avec le champ Year : >=Max (Year) -2. Exemple 2 : > 2010

6. Cliquez sur le bouton **OK** pour valider votre travail

Votre travail est validé et votre écran ressemblera à ceci :

![Qalyptus Filter Fields](/img/docs-images/qalyptus-filter-fields.png)

## Filtrer avec des variables

Pour créer un filtre à l’aide d’une variable, cliquez sur le bouton **Ajouter une variable**. Votre écran ressemblera à ceci :

![Qalyptus Filter Variables](/img/docs-images/qalyptus-filter-variables.png)

1. Sélectionnez la connexion **Executive Dashboard** dans la liste des connexions
2. Sélectionnez une variable à laquelle vous assignerez une valeur. Dans notre cas, sélectionnez **vCurrentYear**
3. Attribuez à la variable la valeur suivante : **=Max(Year)**
4. S’agissant d’une formule QlikView, cochez la case **Calculer**
5. Cliquez sur le bouton **OK** pour valider votre travail.

## Filtrer avec des favoris

Pour créer un filtre à l’aide d’un favori, cliquez sur le bouton Ajouter un favori. Votre écran ressemblera à ceci :

![Qalyptus Filter Bookmarks](/img/docs-images/qalyptus-filter-bookmarks.png)

1. Sélectionnez la connexion **Executive Dashboard**
2. Sélectionnez le favori à appliquer
3. Cliquez sur **OK**

Votre travail est validé et votre écran ressemblera à ceci :

![Qalyptus Create Filter Values](/img/docs-images/qalyptus-create-filter-values.png)

Cliquez sur le bouton **OK** pour valider.

La fenêtre se ferme et vous pouvez cliquer sur le bouton **Enregistrer** pour enregistrer et créer votre filtre. Voir le résultat.

![Qalyptus Filters Result](/img/docs-images/qalyptus-filters-result.png)

## Usage

Les filtres peuvent être utilisés pour filtrer un objet, un rapport ou une tâche. Regardez :

- [Ajouter un filtre à un objet](/products/qalyptus/qalyptus-desktop/designing-templates/excel-templates#1--add-a-filter-to-an-object)
- [Créer des rapports](/products/qalyptus/qalyptus-desktop/create-reports)
- [Générer des rapports](/products/qalyptus/qalyptus-desktop/generate-reports)

## Statuts

Un filtre peut avoir deux statuts différents :

- <span style={{color: "green"}}>Filtre valide</span>
- <span style={{color: "red"}}>Aucun champ ou variable dans le filtre actuel</span>
