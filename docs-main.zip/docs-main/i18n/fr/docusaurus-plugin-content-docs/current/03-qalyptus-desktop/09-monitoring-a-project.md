---
title: Suivi d’un projet
---

Avec Qalyptus, vous avez la possibilité de connaître à tout moment le statut des différentes entités. Si, par exemple, le chemin d’accès à un fichier d’un modèle n’existe plus, vous le saurez avant de lancer la génération du rapport.

Dans l’image ci-dessous, vous pouvez voir que le fichier du modèle **Performance PowerPoint template** est introuvable.

![Qalyptys File Not Found Error](/img/docs-images/qalyptus_file_not_found_error.png)

Le modèle **Performance PowerPoint template** est utilisé par deux rapports. Par conséquent, les deux rapports seront également en état d’erreur. Une fois que l’erreur de modèle est corrigée, l’état du rapport passera automatiquement à valide. Voir ci-dessous.

![Qalyptys Report Error](/img/docs-images/qalyptys_report_error.png)

La tâche **Performance task** a un statut en erreur car elle contient les deux rapports **Performance PowerPoint Iteration report** et **Performance PowerPoint simple report** qui ont un statut en erreur. Une fois que l’erreur du modèle est corrigée, le statut des rapports et celui de la tâche deviennent automatiquement valides.

![Qalyptys Task Error](/img/docs-images/qalyptus_task_error.png)

## Qalyptus Information

Qalyptus vous permet de voir en un coup d’œil le statut de toutes les entités de votre projet ainsi que des informations importantes sur votre projet. Voir l’image ci-dessous.

![Qalyptys Info](/img/docs-images/qalyptus_info.png)
