---
title: Connexion à Qlik Sense
---

Dans cette section, vous verrez comment créer une connexion avec une application Qlik Sense.

## Exigences

- Si vous utilisez Qlik Sense Desktop, Qalyptus et Qlik Sense Desktop doivent être installés sur le même ordinateur.
- Vous devez installer le certificat Qlik Sense si Qalyptus s’exécute sur un ordinateur différent de celui de Qlik Sense Enterprise ou si Qalyptus est installé sur la même machine que Qlik Sense mais que l’utilisateur des services Qlik Sense est différent de l’utilisateur Qalyptus.

Dans notre cas, nous allons créer une connexion à l’application “Executive Dashboard”.

## Ouvrez Qalyptus et commencez

La première chose que vous voyez après avoir ouvert Qalyptus Desktop est la **page Connexion**. Ici, vous créez vos connexions vers l’application Qlik Sense.

Cliquez sur le bouton **Créer** pour créer une nouvelle connexion. Votre écran ressemblera à ceci :

![Create QlikSense Connection](/img/docs-images/qalyptus-create-qliksense-connection.png)

1. Donnez un nom à votre connexion
2. Il est recommandé d’ajouter une description
3. Choisissez Qlik Sense comme source
4. Indiquez l’adresse du serveur Qlik Sense (pour Qlik Sense Desktop : http://localhost:4848). Pour vous simplifier la vie, vous pouvez entrer l’adresse par défaut du serveur Qlik Sense dans ![](/img/docs-images/settings-icon.png) \*\*> Paramètres généraux. La prochaine fois, l’adresse du serveur sera renseignée automatiquement.
5. Choisissez une application Qlik Sense. Cliquez sur le bouton à droite pour voir la liste de toutes les applications Qlik Sense disponibles sur votre serveur. Choisissez une application et cliquez sur le bouton OK.
6. Entrez le compte de domaine Windows d’un **utilisateur Qlik Sense** que Qalyptus utilisera pour se connecter à Qlik Sense. Cet utilisateur sera utilisé dans toutes les interactions entre Qalyptus et Qlik Sense (création de connexion et génération de rapport). Lorsque le projet est publié sur Qalyptus Server, Qalyptus Server utilisera cet utilisateur pour se connecter à Qlik Sense. Si vous n’entrez pas de compte de domaine utilisateur Qlik Sense, Qalyptus utilisera le compte de domaine Windows qui exécute Qalyptus.
7. Si l’application Qlik Sense utilise un thème, cochez **Appliquer le thème** pour utiliser le même thème des graphiques dans les rapports qui seront générés par Qalyptus.
8. Cochez la case **Par défaut** si vous souhaitez établir la connexion actuelle comme connexion par défaut. Lorsque vous ouvrez l’éditeur de modèle, cette connexion sera sélectionnée par défaut.
9. Enfin, cliquez sur **Enregistrer** pour créer et enregistrer la connexion. Tous les objets, champs et variables de l’application Qlik Sense seront récupérés.

Maintenant, votre connexion nommée **Executive Dashboard** est créée et prête à être utilisée.

![QlikSense Connection List](/img/docs-images/qalyptus-QlikSense-connection_list.png)

## Modification ou suppression d’une connexion

Pour modifier ou supprimer une connexion :

1. Aller à la liste des connexions
2. Faites un clic droit sur la connexion que vous souhaitez modifier ou supprimer
3. Si vous souhaitez modifier, cliquez sur **Editer** et si vous souhaitez supprimer, cliquez sur **Supprimer**.

:::warning
Attention, vous ne pouvez pas supprimer une connexion utilisée par d’autres entités. Avant de supprimer la connexion, vous devez supprimer toutes les entités utilisant la connexion.
:::

## Statut

Une connexion peut avoir deux statuts différents :

- <span style={{color: "green"}}>Connexion valide</span>
- <span style={{color: "red"}}>Fichier non trouvé</span>
