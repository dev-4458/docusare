---
title: Connexion à un document QlikView
---

Dans cette section, vous verrez comment créer une connexion avec un document QlikView.

## Exigences

Pour utiliser correctement Qalyptus, assurez-vous que les éléments ci-dessous sont complétés.

- Qalyptus et QlikView doivent être installés sur le même ordinateur
- QlikView Desktop Personal Edition (version gratuite) non pris en charge
- Ne pas utiliser “états alternatifs” dans le document QlikView
- Ne pas utiliser les déclencheurs de feuille et de document
- Ne pas utiliser la propriété de la liste “Toujours une valeur sélectionnée”
- Ne pas activer le mode ‘WebView’

Si votre document QlikView ne répond pas à l’un des quatre derniers éléments de la liste ci-dessus, créez une copie du document et supprimez les options non prises en charge.

Utilisez ce nouveau document QlikView pour créer vos rapports avec Qalyptus.

Vous voulez créer et générer des rapports sur les ventes à partir de votre document QlikView **Retail Store Performance.qvw**.

## Ouvrez Qalyptus et commencez

La première chose que vous voyez après avoir ouvert Qalyptus Desktop est la page **Connexion**. C’est ici que vous allez créer vos connexions au document QlikView.

Cliquez sur le bouton **Créer** pour créer une nouvelle connexion. Votre écran ressemblera à ceci :

![Qalyptus QlikView Connection](/img/docs-images/qalyptus-QlikView-connection.png)

1. Donnez un nom à votre connexion
2. Il est recommandé d’ajouter une description
3. Choisissez **QlikView** comme source
4. Si vous souhaitez créer une connexion à partir d’un serveur QlikView, cochez le serveur qvp et donnez l’adresse du serveur. Pour vous simplifier la vie, vous pouvez entrer l’adresse par défaut du **serveur qvp** dans ![](/img/docs-images/settings-icon.png) > Paramètres généraux. La prochaine fois, l’adresse du serveur sera renseignée automatiquement.
5. Choisissez un document QlikView. Si la case à cocher **Serveur Qvp** n’est pas cochée, lorsque vous cliquez sur le bouton ajouter, vous allez parcourir pour ouvrir un document QlikView sur votre ordinateur local. Si la case à cocher Serveur Qvp n’est pas cochée, lorsque vous cliquez sur le bouton, la liste de tous les documents QlikView présents sur votre serveur QlikView s’affichent. Choisissez un document et cliquez sur le bouton OK.
6. Si le document QlikView est protégé, renseignez l’ID utilisateur et le mot de passe.
7. Cochez la case Défaut, si vous voulez mettre la connexion actuelle comme étant une connexion par défaut.
8. Enfin, cliquez sur Enregistrer pour créer et enregistrer la connexion. Tous les objets, champs et variables du document QlikView seront récupérés.

Maintenant, votre connexion nommée Performance est créée et prête à être utilisée.

![Connection List](/img/docs-images/connection-list.png)

## Modification ou suppression d’une connexion

Pour modifier ou supprimer une connexion :

1. Aller à la liste des connexions
2. Faites un clic droit sur la connexion que vous souhaitez modifier ou supprimer
3. Si vous souhaitez modifier, cliquez sur **Modifier** et si vous souhaitez supprimer, cliquez sur **Supprimer**.

:::warning
Attention, vous ne pouvez pas supprimer une connexion utilisée par d’autres entités. Avant de supprimer la connexion, vous devez supprimer toutes les entités utilisant la connexion.
:::

## Statut

Une connexion peut avoir deux statuts différents :

- <span style={{color: "green"}}>Connexion valide</span>
- <span style={{color: "red"}}>Fichier non trouvé</span>
