---
title: Introduction
---

Lors de la création de votre projet Qalyptus, la première étape consiste à créer une connexion avec vos documents QlikView ou applications Qlik Sense. Ainsi, pour créer vos rapports, vous pouvez utiliser une ou plusieurs sources de connexion.

Vous pouvez créer et mettre à jour une connexion existante à tout moment.

Continue avec:

- [Connexion à un document QlikView](/products/qalyptus/qalyptus-desktop/create-connections/connection-to-a-qlikview-document)
- [Connexion à une application Qlik Sense](/products/qalyptus/qalyptus-desktop/create-connections/connection-to-a-qlik-sense-app)
