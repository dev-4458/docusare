---
title: Les paramètres
---

Pour accéder aux paramètres de Qalyptus, cliquez sur ![](/img/docs-images/settings-icon.png) .

Dans la page qui apparaîtra, vous avez trois onglets :

1. Paramètres généraux
2. Apparence
3. Licence
4. Mon compte
5. A propos

## Paramètres généraux

Pour le bon fonctionnement de Qalyptus Desktop et pour améliorer votre expérience d’utilisation, Qalyptus utilise des variables.

- **Dossier temporaire**: répertoire dans lequel les fichiers temporaires sont enregistrés.
- **Dossier de documents** : emplacement par défaut des applications QlikView. Utilisé lors de la création de connexions.
- **Dossier des aperçus** : emplacement où les fichiers de prévisualisation sont enregistrés.
- **Serveur qvp par défaut** : adresse par défaut de votre serveur QlikView qvp. Il apparaîtra automatiquement chaque fois que vous créez une nouvelle connexion.
- **Serveur Qlik Sense** : adresse par défaut de votre serveur Qlik Sense. Il apparaîtra automatiquement chaque fois que vous créez une nouvelle connexion.
- **Dossier des journaux** : répertoire dans lequel les fichiers journaux de l’application Qalyptus sont enregistrés.
- **Préfixe du nom des journaux** : vos fichiers journaux ont le format suivant: “Préfixe de fichier_yyyymmdd”. Vous pouvez personnaliser le préfixe de fichier.

## Apparence

Dans cet onglet, vous pouvez changer la langue d’interface de Qalyptus ainsi que d’autre paramètres d’affichage.

## License

Dans cet onglet, vous pouvez récupérer le propriétaire de la licence (compte de domaine Windows) ainsi que mettre à jour votre licence.

## Mon compte

Cet onglet vous permet de renseigner l’adresse de votre Qalyptus Server et de choisir le mode d’authentification nécessaires pour publier votre projet dans Qalyptus Server.

### Utiliser le moteur Qalyptus Server

Cette fonctionnalité permet d’utiliser le moteur de Qalyptus Server pour actualiser les connexions et générer les rapports. Cela signifie que Qlyptus Desktop ne communiquera pas directement avec Qlik Sense et n’utilisera pas les ressources (RAM et CPU) de la machine sur laquelle il est installé.

Quand utiliser cette option ?

- Lorsque vous ne souhaitez pas installer les certificats Qlik Sense sur le PC sur lequel Qalyptus Desktop est installé. La communication avec Qlik Sense se fait uniquement via Qalyptus Server.
- Lorsque vous travaillez avec une application Qlik Sense volumineuse. Qalyptus Desktop est un programme 32 bits. Un programme qui utilise 32 bits de RAM ne peut adresser que 4 Go. Qalyptus Server est un programme 64 bits.

## A propos

Dans cet onglet, vous accédez à des informations sur Qalyptus Desktop.
