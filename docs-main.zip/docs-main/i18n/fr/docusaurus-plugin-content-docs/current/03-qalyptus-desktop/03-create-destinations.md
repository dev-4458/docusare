---
title: Créer des destinations
---

Pour stocker vos fichiers générés par Qalyptus, vous devez spécifier une destination lors de la création de tâches.

Pour créer une destination, allez dans l’onglet **Destinations** et cliquez sur le bouton **Créer**. Votre écran ressemblera à ceci :

![Create Destination](/img/docs-images/cerate-destination.png)

1. Donnez un nom à votre destination
2. Il est recommandé d’ajouter une description
3. Choisissez un répertoire où vous allez stocker les fichiers
4. Enfin, cliquez sur **Enregistrer** pour créer et enregistrer la destination.

Maintenant, votre destination nommée **Performance Files** est créée et prête à être utilisée.

![Destination List](/img/docs-images/destination_list.png)

## Statut

Une destination peut avoir deux statuts différents :

- <span style={{color: "green"}}>Répertoire valide</span>
- <span style={{color: "red"}}>Répertoire inexistant</span>
