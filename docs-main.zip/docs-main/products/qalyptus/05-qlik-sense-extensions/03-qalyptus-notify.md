---
title: Qalyptus Notify
---

Qalyptus Notify allows you to subscribe to a Qlik Sense Sheet or an entire Qlik Sense App. By subscribing, you receive a snapshot of a sheet or an App as an image or PDF by email at regular intervals without logging in to Qlik Sense.

## Qalyptus Notify Overview

<iframe width="560" height="315" src="https://www.youtube.com/embed/AfgeOkrJEOQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Install Qalyptus Notify

Qalyptus Notify is a Qlik Sense extension that uses Qalyptus Server Engine. In the video below, we will see how to install the Qalyptus Server and then import the Qalyptus Notify extension into Qlik Sense Server Enterprise.

:::note
You do not need a Qalyptus Server license to use Qalyptus Notify.
:::

We will see the following:

- Ensure the necessary rights to connect to Qlik Sense
- Open Qlik Sense Service Ports (Only for installation in a separate machine)
- Export Qlik Sense certificates
- Import and configure Qalyptus Notify

## Install and configure Qalyptus Notify

<iframe width="560" height="315" src="https://www.youtube.com/embed/k-iFsNa4vX8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
