---
title: Qalyptus On-Demand
---

Using the Qlik Sense extension **Qalyptus On-Demand**, you can generate your reports created with Qalyptus directly from a Qlik Sense application.

Qalyptus use the Qlik Sense user profile to generate the report. In other words, Qalyptus will consider the existing Section Access in the application when generating the report. If, for example, the user only has access to his department’s data, when generating the report, only the data of his department will be visible on the report.

Note that you must add the domain account (DOMAIN\username) of the [user in their information](/products/qalyptus/qalyptus-server/qalyptus-administration/user-management/qalyptus-users).

## Qalyptus On-Demand Overview

<iframe width="560" height="315" src="https://www.youtube.com/embed/0SVACyVLoAs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Configure Qalyptus On-Demand

Qalyptus On-Demand needs Qalyptus Server to generate the reports. Before using Qalyptus On-Demand, you need to install and configure Qalyptus Server. Se how to [install Qalyptus Server](/products/qalyptus/deploying-qalyptus/install-qualyptus-server).

:::note
Where can I find the Qalyptus On-Demand extension? After installing Qalyptus Server you will find Qalyptus On-Demand in the folder: C:\ProgramData\Qalyptus\Extensions
:::

### 1- Allow using Qalyptus On-Demand

Qalyptus On-Demand is a Qlik Sense extension that uses the Qalyptus API to communicate with Qalyptus Server. For security reasons, you must add the Qlik Sense address as a trusted origin, choose the users who will be allowed to use Qalyptus On-Demand, and choose which reports you want to be visible to users on Qalyptus On-Demand.

### 1-1 Add Qlik Sense address as a trusted origin

Every time you want to communicate with Qalyptus Server from another web application, you need to add the address of this application in the list of the trusted origins.

To add the Qlik Sense address as a trusted origin in Qalyptus Server, do the following:

- Connect to Qalyptus Server
- Go Qalyptus Administration> System> **Trusted Origins**
- Click **Add Origin**
- Enter a name for the origin
- Enter a description (optional)
- Enter the address of your Qlik Sense. Example: https://qlik-sense-url.com
- Click **Save**

![Add trusted origin](/img/docs-images/qalyptus-server-add-trusted-origin.png)

### 1-2 Attribute permissions to the users

For users who you want to allow to use Qalyptus On-Demand, you need to attribute them a Role that contains the permission “**Use API, Qalyptus On-Demand and Qalyptus Self-Reporting.**”

For more details on creating and attributing a role to users, see the section: [Security Roles](/products/qalyptus/qalyptus-server/qalyptus-administration/system/security-roles).

![API permissions](/img/docs-images/qalyptus-server-api-permissions.png)

### 1-3 Make reports available for Qalyptus On-Demand

By default, reports are not visible in **Qalyptus On-Demand**. For each report, you need to choose the users that can view it and generate it in Qalyptus On-demand.

To choose the users that can view and generate a report in Qalyptus On-Demand, do the following:

- Connect to Qalyptus Server
- Go to the **Reports** page
- Edit the report you want to make visible for the users. Example: **Sales analysis**
- Select the tab **API and On-Demand report restrictions**
- Click **Add Users** or **Add Groups**
- Add users and/or groups. If you want to allow all users, choose the default group “**All users.**”
- Click **Save**

![Qalyptus Server On Demand User](/img/docs-images/qalyptus-server-on-demand-users.png)

### 2- Import Qalyptus On-Demand in Qlik Sense QMC

To use the extension Qalyptus On-Demand in Qlik Sense, you need to import it in the Qlik Sense QMC. Qalyptus On-Demand is a zip file that you can find in the machine where Qalyptus Server is installed at this location: “C:\ProgramData\Qalyptus\Extensions” or in your Qalyptus account on the [Download](https://my.qalyptus.com/my-account/download-archives/) page.

To import Qalyptus On-Demand in the QMC, do the following:

- Connect to the Qlik Sense **QMC** as administrator
- Go to the page **Extensions**
- Click **Import**
- Browse to the Qalyptus On-Demand zip file
- Click **Import**

![Import on demand](/img/docs-images/qalyptus-server-import-qalyptus-on-demand.png)

Now Qalyptus On-Demand is ready to be used in Qlik Sense sheets.

### 3- Add Qalyptus On-Demand to a Qlik Sense sheet

To use Qalyptus On-Demand, you must add it to a Qlik Sense sheet. Qalyptus On-Demand appears in a sheet as a button.

To add Qalyptus On-Demand to a sheet, do the following:

- Open a Qlik Sense sheet for which you have edit rights
- Click **Edit sheet**, top right
- In the left area, go to **Custom objects> Qalyptus bundle**
- Drag-and-drop Qalyptus On-Demand

![Drag and drop on demand](/img/docs-images/qalyptus-server-drag-and-drop-qalyptus-on-demand.png)

Now we need to configure Qalyptus On-demand to communicate with Qalyptus Server.

In the edit mode of the Qlik Sense sheet, select the Qalyptus On-Demand button to start the configuration.

![On Demand Edit Mode](/img/docs-images/qalyptus-serverqalyptus-on-demand-edit-mode.png)

### Authentication section

- Add your Qalyptyus Server address. Example: https://qalyptus-server-url.com:3994
- Choose the authentication method from the available methods:
  - Windows authentication (Windows username and password of the user): available with Qalyptus Server Enterprise and Qalyptus Server Ultimate
  - Qalyptus credentials (email and password of a user created in Qalyptus Server): available with Qalyptus Server Business, Qalyptus Server Enterprise, and Qalyptus Server Ultimate
  - SSO with SAML (a user authenticate using a [Configured Identity Provider](/products/qalyptus/qalyptus-server/qalyptus-administration/system/identity-providers)): available with Qalyptus Server Ultimate

![Qalyptus Server On Demand Auth Options](/img/docs-images/qalyptus-server-qalyptus-on-demand-auth-options.png)

### Settings section

- Ignore existing report filters: If you check this option, if a user runs a report that contains a filter, Qalyptus will not apply the filter defined in the report. Qalyptus will only apply the current selections if there is.
  If the option is not checked and the user makes selections, Qalyptus will add the Selections as filters to the existing report filters. Because the order of the filters is important, the selections will be added after the existing report filters.
- Override report app with current app: For the current selections to be taken into account when generating a report, the report must be created with a Qlik Sense app whose ID is the same as the ID of the current app. Check this option if you want Qalyptus to replace the application ID used in the reports with the current app ID. Use this option only if the current application contains the same objects as the application used to create the report.

  - Examples:

    Example 1: You created a report using the app1 (ID=xxx) published in stream S1. This same app exists in stream S2 with an ID=yyy, and you want to generate a report with the current selections from the app with ID=yyy.

    Example 2: You created a report using app1 (ID=xxx); you want to generate a report with the current selections from an app generate with ODAG (On-Demand App Generation) method. The new app generated with ODAG will have a different ID.

### Appearance section

In this section, you can customize the Qalyptus On-Demand button label and the button design.

### 4- Use Qalyptus On-Demand

### Authentication

In the Qlik Sense sheet, click the button Qalyptus On-Demand. The first time, the user must authenticate with the authentication method chosen.

- If the authentication method is Windows authentication, the user must enter his Windows credentials: username in this format DOMAIN\username and his Windows password.
- If the authentication method is Qalyptus credentials, the user must exist in Qalyptus Server and create a password. The user must use his email and the created password. If the user exists in Qalyptus Server and has not yet created a password, he can generate a password on the login page of the Qalyptus Server by clicking the link **Forgotten password?**
- If the authentication method is SSO with SAML, if you have configured one Identity Provider in Qalyptus Server, the user will be automatically redirected to the Identity Provider Login page. If you have configured more than one Identity Provider, the user will see a Login button for each Identity Provider.

### Generate a report

After authentication, the user will see the list of reports to which he is entitled.

To generate a report, choose a report in the report list, click **Run now**, and choose the output format.

Follow the execution status in the **Status** tab. At the end of the execution, you can download the report, delete the execution entry or run the report again.

![Qalyptus On Demand Overview](/img/docs-images/qalyptus-on-demand-overview.png)

Qalyptus administrators can manage the report executions in Qalyptus Server. If the execution failed, you could access the log file to learn more about the error.

To access the execution status in Qalyptus Server, go to the **Status** page> **On-Demand requests**.

![Qalyptus On Demand Status](/img/docs-images/qalyptus-server-qalyptus-on-demand-status.png)
