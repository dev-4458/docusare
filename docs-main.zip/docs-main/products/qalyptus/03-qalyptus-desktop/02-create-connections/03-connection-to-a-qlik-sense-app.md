---
title: Connection to a Qlik Sense App
---

In this section, you will see how to create a connection with a Qlik Sense App.

## Requirement

- If you use Qlik Sense Desktop, Qalyptus and Qlik Sense Desktop must be installed on the same machine.
- You need to install Qlik Sense Certificate if Qalyptus is running on a different machine than Qlik Sense Enterprise or if Qalyptus is installed on the same machine as Qlik Sense but the Qlik Sense services user is different from the Qalyptus user.

In our case, we will create a connection to the app “Executive Dashboard.”

## Open Qalyptus and begin

The first thing you see after you open Qalyptus Desktop is the **Connection page**. Here you create your connections to Qlik Sense app.

Click **Create** button to create a new connection. Your screen will look something like this:

![Create QlikSense Connection](/img/docs-images/qalyptus-create-qliksense-connection.png)

1. Give a name to your connection
2. It is recommended to add a description
3. Choose **Qlik Sense** as a source
4. Give the Qlik sense server address (for Qlik Sense Desktop: http://localhost:4848). You can enter the default Qlik Sense Server address in ![](/img/docs-images/settings-icon.png) **> General Settings** to make your life easier. The next time, the server address will be filled in automatically.
5. Choose a Qlik Sense app. Click the button on the right to see the list of all available Qlik Sense apps on your server. Choose an application and click the OK button.
6. Enter the Windows domain account of a **Qlik Sense user** that Qalyptus will use to connect to Qlik Sense. This user will be used in all interactions between Qalyptus and Qlik Sense (connection creation and report generation). When the project is published to Qalyptus Server, Qalyptus Server will use this user to connect to Qlik Sense. If you do not enter a Qlik Sense user domain account, Qalyptus will use the Windows domain account that is running Qalyptus.
7. If the Qlik Sense application uses a theme, Check to **Apply theme** to use the same chart’s theme in the reports which Qalyptus will generate.
8. Check the check box **Default** if your want makes the current connection as the default connection. When you open the template editor, this connection will be selected by default.
9. Finally, click **Save** to create and save the connection. All objects, fields, and variables of the Qlik Sense app will be retrieved.

Now your connection named Executive Dashboard is created and ready for use.

![QlikSense Connection List](/img/docs-images/qalyptus-QlikSense-connection_list.png)

## Modifying or deleting a connection

To modify or delete a connection:

1. Go to the connections list
2. Right-click on the connection you want to modify or delete
3. If you want to modify click **Edit** and if you want to delete click **Delete**

:::warning
Warning, you can not delete a connection that is used by others entities. Before deleting the connection you need to delete all the entities using the connection.
:::

## Status

A connection can have two different status:

- <span style={{color: "green"}}>Valid Connection </span>
- <span style={{color: "red"}}>File not found</span>
