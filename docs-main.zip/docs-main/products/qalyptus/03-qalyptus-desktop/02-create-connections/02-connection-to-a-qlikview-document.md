---
title: Connection to a QlikView document
---

In this section you will see how create a connection with a QlikView document.

## Requirement

To use correctly Qalyptus, make sure that the items below are completed.

- Qalyptus and QlikView must be installed in the same machine
- QlikView Desktop Personal Edition (free version) not supported
- Do not use ‘alternate states’ in the QlikView document
- Do not use sheet and document triggers
- Do not use ‘Always one selected’ list box property
- Do not activate ‘WebView’ mode

If your QlikView document does not respond to one of the last four items in the list above, create a copy of the document and remove unsupported options.

Use this new QlikView document for creating your reports with Qalyptus.

You want to create and generate sales reports from you QlikView document **Retail Store Performance.qvw**.

## Open Qalyptus and begin

The first thing you see after you open Qalyptus Desktop is the **Connection page**. Here you create your connections to QlikView Document.

Click **Create** button to create a new connection. Your screen will look something like this:

![Qalyptus QlikView Connection](/img/docs-images/qalyptus-QlikView-connection.png)

1. Give a name to your connection
2. It is recommended to add a description
3. Choose **QlikView** as a source
4. If you want to create a connection from a **QlikView Server**, check Qvp Server and give the server address. To make your life easier, you can enter the default Qvp Server address in ![](/img/docs-images/settings-icon.png) > **General Settings**. The next time, the server address will be filled in automatically.
5. Choose a QlikView document. If the **Qvp Server** check box is unchecked, when you click on the button Add, you will browse to open a QlikView document on your local machine. If the **Qvp Server** check box is unchecked, when you click on the button, list of all QlikView documents that are present on your QlikView server is displayed. Choose a document and click the OK button.
6. If the QlikView document is protected, Fill in the **User Id** and the **Password**.
7. Check the check box **Default**, if your want make the current connection as the default connection.
8. Finally, click **Save** to create and save the connection. All objects, fields, and variables of the QlikView document will be retrieved.

Now your connection named Performance is created and ready for use.

![Connection List](/img/docs-images/connection-list.png)

## Modifying or deleting a connection

To modify or delete a connection:

1. Go to the connections list
2. Right click on the connection you want to modify or delete
3. If you want to modify click **Edit** and if you want to delete click **Delete**

:::warning
Warning, you can not delete a connection that is used by others entities. Before deleting the connection you need to delete all the entities using the connection.
:::

## Status

A connection can have two different status:

- <span style={{color: "green"}}>Valid Connection </span>
- <span style={{color: "red"}}>File not found</span>
