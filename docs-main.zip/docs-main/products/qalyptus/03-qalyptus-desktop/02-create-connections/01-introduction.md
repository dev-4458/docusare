---
title: Introduction
---

The first step when creating your Qalyptus project is to create a connection to your QlikView documents or Qlik Sense Apps. Thus, to create your reports you can use one or more sources connection.

You can create and update an existing connection any time.

Continue with:

- [Connection to a QlikView document](/products/qalyptus/qalyptus-desktop/create-connections/connection-to-a-qlikview-document)
- [Connection to a Qlik Sense app](/products/qalyptus/qalyptus-desktop/create-connections/connection-to-a-qlik-sense-app)
