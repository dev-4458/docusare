---
title: Generate reports
---

To generate your Qalyptus reports, you need to create tasks that will contain the reports to generate.

A task can contain one or more reports with one or more formats.

You can add filters to a task. Qalyptus applies task and report filters before generating reports. see more [about filters](/products/qalyptus/qalyptus-desktop/create-filters).

To create an task, go to **Tasks** tab and click **Create** button. Your screen will look something like this:

![Qalyptys Tasks](/img/docs-images/qalyptys_tasks.png)

1. Give a name to your report. Example: Performance task
2. It is recommended to add a description
3. In the **Destination** drop-down menu select Performance files. This destination was [created in Destinations tab](/products/qalyptus/qalyptus-desktop/create-destinations).
4. Click **Reports** button to add reports to your task. A new window will open

We will add two reports to the task.

- The first one is Iteration report: Reports for sales performance by Region Market
- The second one is a single report: A report for sales performance for all the company

![Qalyptys Task Reports](/img/docs-images/qalyptus_task_reports.png)

1. Click ![](/img/docs-images/add-task-report.png) to add a report
2. In **Report** drop-down menu select a report
3. In **Format** drop-down menu select a format with which the report will be generated.
4. Click **OK** button to validate you work.

Finally, click **Save** to create and save the task. You task is now created and can be started.

![Qalyptys Task Created](/img/docs-images/qalyptus_task_created.png)

Select the task and click **Run** to generate your reports. At the end of the generation Qalyptus will create six files with Pptx extension and one file with PDF extension.

## Status

A task can have five different status:

- <span style={{color: "green"}}>Valid task</span>
- <span style={{color: "red"}}>No destination or report assigned to task</span>
- <span style={{color: "red"}}>Task destination is not valid</span>
- <span style={{color: "red"}}>Task reports are not valid</span>
- <span style={{color: "red"}}>Task filters are not valid</span>

:::note
A task can not be started if there is one or more errors.
:::
