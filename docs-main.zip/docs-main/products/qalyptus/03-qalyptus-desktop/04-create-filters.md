---
title: Create filters
---

Qalyptus allows you to apply filters on Objects, Reports, and tasks before generating your reports. Filters can be static values or calculated values using Qlik Sense or QlikView expressions. Expressions must use Qlik Sense or QlikView rules and syntax and return a single value.

:::note
Filters are evaluated in the following order: task -> report -> object.

Example: If the filter used in the task is “City = Paris, Munich” and the filter used in the report is “City = London”, the filter that will be applied is “City = London”.
:::

The filter will not necessarily overwrite past selections. A filter can be added to the current selection if it is applied to a possible value of a field.

With Qalyptus you can create three types of filters:

- **Filter with fields**
- **Filter with variables**
- **Filter with bookmarks**

To create a filter, go to the **Filters** tab and click **Create** button. Your screen will look something like this:

![Qalyptus Create Filter Start Page](/img/docs-images/qalyptus-create-filter-start-page.png)

1. Give a name to your filter. Example: _European market_
2. It is recommended to add a description
3. Click Add **Values** button

Your screen will look something like this:

![Qalyptus Create Filter](/img/docs-images/qalyptus-create-filter.png)

Your filter may consist of field values, variables, and bookmarks. Note that the order is important. Add the filter items in the order in which you want Qalyptus to apply them.

## Filter with fields

Using the connection “Executive Dashboard”, we will create a filter on the **Region** field. We want to filter on the European countries.

- The **Region** field contains the following values: Germany, Japan, Nordic, Spain, UK, and the USA
- Our filter will be: **Region** = Germany, Nordic, Spain, UK

To create the filter, click **Add field** button. Your screen will look something like this:

![Qalyptus Filter Fields Values](/img/docs-images/qalyptus-filter-fields-values.png)

1. Select the **Executive Dashboard** connection in the connections list
2. Choose **Region** field in the fields list
3. The **Clear Selection** check box allows you to clear the field selections. If this checkbox is checked, the added values are not taken into account. In our case, **leave Clear Selection unchecked**.
4. Click **Add** button
5. Now, add the four values on which you want to filter: Germany, Nordic, Spain, UK. You notice that the default evaluation is “value”. In the Evaluation drop-down menu you can select from:
6. Value: Use this option to set a static value. Example: **Germany**
7. Evaluate value (`)=, >, >=, <, <=, <>`): Choose this option to select one or more values using Qlik expression or static value. Example 1 with the field Year: **>=Max(Year)-2**. Example 2 : >**2010**
8. Click the **OK** button to validate your work

Your work is validated and your screen will look something like this:

![Qalyptus Filter Fields](/img/docs-images/qalyptus-filter-fields.png)

## Filter with variables

To create a filter using a variable, click the **Add variable** button. Your screen will look something like this:

![Qalyptus Filter Variables](/img/docs-images/qalyptus-filter-variables.png)

1. Select the **Executive Dashboard** connection in the connections list
2. Select a variable to which you will assign a value. In our case, select **vCurrentYear**
3. Assign to the variable the following value: **=Max(Year)**
4. Since this is a QlikView formula, the Check **Calculate** check box
5. Click the **OK** button to validate your work

## Filter with Bookmarks

To create a filter using a bookmark, click **Add Bookmark** button. Your screen will look something like this:

![Qalyptus Filter Bookmarks](/img/docs-images/qalyptus-filter-bookmarks.png)

1. Select the Executive Dashboard connection in the connections list
2. Select the bookmark to apply
3. Click **OK**

Your work is validated and your screen will look something like this:

![Qalyptus Create Filter Values](/img/docs-images/qalyptus-create-filter-values.png)

Click the **OK** button to validate.

The window will close and you can click on the **Save** button to save and create your filter. See the result.

![Qalyptus Filters Result](/img/docs-images/qalyptus-filters-result.png)

## Use

Filters can be used to filter an Object, a Report, or a Task. Please see:

- [Add a filter to an object](/products/qalyptus/qalyptus-desktop/designing-templates/excel-templates#1--add-a-filter-to-an-object)
- [Create reports](/products/qalyptus/qalyptus-desktop/create-reports)
- [Generate reports](/products/qalyptus/qalyptus-desktop/generate-reports)

## Status

A filter can have two different states:

- <span style={{color: "green"}}>Valid filter</span>
- <span style={{color: "red"}}>No fields or variables in the current filter</span>
