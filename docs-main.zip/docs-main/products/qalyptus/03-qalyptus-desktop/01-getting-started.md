---
title: Getting Started
---

In this section, you will learn with the video how to create your first Qalyptus project in 5 minutes.

To create and generate your reports with Qalyptus, you will:

- Create a connection to your Qlik Sense or QlikView application.
- Create a destination to store your files.
- Create a report template (Excel, Word, PowerPoint, ..).
- Create a report using a template.
- And finally, create a task and start the generation.

## Getting Started with Qalyptus Desktop

<iframe width="560" height="315" src="https://www.youtube.com/embed/KR55Ve_JE1A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
