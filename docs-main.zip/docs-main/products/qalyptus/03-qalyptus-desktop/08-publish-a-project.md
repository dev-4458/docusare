---
title: Publish a Project
---

When your Qalyptus project is ready, you can publish it on Qalyptus Server to automate the generation and distribution of reports and make them available to other users.

## Publish from Qalyptus Desktop

To publish your project from Qalyptus Desktop to Qalyptus Server, follow the steps below.

1. Open Qalyptus Desktop.
2. If you are not already connected to Qalyptus Server, login:

- Click on the **Settings** button
- Go to the **My Account** tab
- Enter the address of your Qalyptus Server and click **Connect**
- You will be redirected to Qalyptus Server for authentication
- After successful authentication, you will see a confirmation message

![Qalyptys Server My Account](/img/docs-images/qalyptus-server-my-account.png)

3. Close the **Settings** page
4. Click on the button **Publish to the server** ![](/img/docs-images/qalyptus-publish-to-server-icon.png)
5. A window opens. If you want to publish the template files as well, check the **Publish template files** check box.
6. If you are a member of more than one organization, choose the organization to which you want to publish the project.
7. Click the Publish button.
8. A confirmation message appears if your project is successfully published

Once published, your project is available on Qalyptus Server in the Project tab with all its information.

At any time, you can publish the project again to update it on Qalyptus Server.

## Use Qalyptus Server Engine

This feature allows using the Qalyptus Server Engine to refresh the connections and generate the reports. This means that Qlyptus Desktop will not communicate directly with Qlik Sense and will not use the resources (RAM and CPU) of the machine where it is installed.

### When using this option?

- When you do not want to install the Qlik Sense certificates on the PC where Qalyptus Desktop is installed, the communication with Qlik Sense is done only through Qalyptus Server.
- When you work with a voluminous Qlik Sense application, Qalyptus Desktop is 32 bits program. A program that uses 32-bits of RAM can only ever address 4 GB. Qalyptus Server is a 64-bits program.

:::note
Template files are stored on Qalyptus Server machine at this location: `\ProgramData\Qalyptus\QalyptusServer\Templates\<projet name>`. During the publication, check Publish template files to automatically save template files to Qalyptus Server.
:::
