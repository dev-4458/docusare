---
title: Monitoring a project
---

With Qalyptus you have the opportunity to know at any time the status of the different entities. If, for example, the path to a template file no longer exists, you will know it before launching the report generation.

In the image below, you can see that the template file of the template **Performance PowerPoint template** can not be found.

![Qalyptys File Not Found Error](/img/docs-images/qalyptus_file_not_found_error.png)

The template **Performance PowerPoint template** is used by two reports. Therefore, the two report will be also in error status. Once the template error is corrected, the report status will automatically change to valid. See below.

![Qalyptys Report Error](/img/docs-images/qalyptys_report_error.png)

The task **Performance task** is in error status because it contains the two reports **Performance PowerPoint Iteration report** and **Performance PowerPoint simple report** which have an error status. Once the template error is corrected, the reports and task status will automatically change to valid

![Qalyptys Task Error](/img/docs-images/qalyptus_task_error.png)

## Qalyptus Info

Qalyptus allows you to see in one look the status of all of the entities in your project as well as important information about your project. See the image below.

![Qalyptys Info](/img/docs-images/qalyptus_info.png)
