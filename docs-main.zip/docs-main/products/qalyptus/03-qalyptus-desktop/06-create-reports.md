---
title: Create reports
---

Qalyptus allows you to create QlikView and Qlik Sense reports based on custom templates.

## Create a simple report

To create a report, go to the **Reports** tab and click **Create** button. Your screen will look something like this:

![Qalyptus Report](/img/docs-images/qalyptus_report.png)

1. Give a name to your report. Example: _Performance PowerPoint report_
2. It is recommended to add a description
3. In the **Template** drop-down menu, select Performance PowerPoint template
4. If you want, you can give a dynamic name to your report by clicking the Dynamic name button. More details are in **Create an Iteration report** section.
5. You can filter your data before generating your report by adding one or more filters. See more [about filters](/products/qalyptus/qalyptus-desktop/create-filters).
6. Finally, click **Save** to create and save the report.

Your report is created and can be used in Tasks.

## Create an Iteration report

With Qalyptus, you can also create your report by dimension. For example, Year, Region, or Seller. You can use one dimension or combine several dimensions such as Year->Seller.

To create an Iteration report, do the following:

- Follow the same steps to create a simple report
- Click the **Iteration fields** button. A new window will open

![Qalyptus Interaction Fields](/img/docs-images/qalyptus_iteration_fields.png)

1. Select the **Performance** connection in the connections list
2. Choose **Region Market** field in the Fields list
3. Click **Add** button
4. Your filter is added
5. Click the **OK** button to validate your work

You will have six different files when you generate the report because there are six values in the **Region Market** field.

:::note
To be sure that each file name will be unique, you need to give a dynamic name to your report. For the name to be unique, it should contain either the values of the iteration field or a variable with a unique value for each value of the iteration field.
:::

In our case, we will create a dynamic name composed of the name of the report and the value of the field of view: _Performance PowerPoint report_Region Market_.

To create a dynamic name, click the **Dynamic name** button. A new window will open.

![Qalyptus Dynamic Name](/img/docs-images/qalyptus_dynamic_name.png)

1. Click **Report** name
2. Click **Iteration fields**
3. The Report name and Iteration fields are added to the dynamic name
4. By default, the separator is “\_”. You can change it
5. Click the **OK** button to validate your work

Your screen will look something like this:

![Qalyptus Interaction Report](/img/docs-images/qalyptus_iteration_report.png)

Finally, click **Save** to create and save the report.

Your report is created and can be used in Tasks.

## Create an Iteration report with a linked field between multiple Qlik Sense applications

You can create an Iteration report using the same dimension field in multiple Qlik Sense applications. For example, create a report for the salespersons using two Qlik Sense apps that contain the field Salesperson. Qalyptus will loop throw the values of the two fields simultaneously and generate the files.

![Linked Iteration Fields](/img/docs-images/Linked-Iteration-fields.png)

There are limits to this feature.

- The Iteration field must have the same name in all the applications to be linked.
- Qalyptus will take the first field in order as a reference field, it will iterate over the values of this - field. If in the other applications the value exists but is not available (in gray color), it will still be selected in these applications. If the reference field does not contain an X value and this value exists in other applications, the value will not be selected and no report will be generated for that value.
- The functionality does not work as expected when using multiple nested fields.

## Status

A report can have four different statuses:

- <span style={{color: "green"}}>Valid report</span>
- <span style={{color: "red"}}>No template assigned to this report</span>
- <span style={{color: "red"}}>The template of this report is not valid</span>
- <span style={{color: "red"}}>One or more filters of this report are not valid</span>
