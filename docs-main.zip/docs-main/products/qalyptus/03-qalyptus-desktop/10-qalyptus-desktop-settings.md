---
title: Qalyptus Desktop Settings
---

To access the Qalyptus settings, click ![](/img/docs-images/settings-icon.png) .

On the page that will appear, you have three tabs:

1. General Settings
2. Appearance
3. License
4. My account
5. About

## General Settings

For the proper functioning of Qalyptus and to improve your experience of use, Qalyptus uses variables.

- **Temporary folder**: The directory where temporary files are saved.
- **Document folder**: The default location for QlikView applications. Used when creating connections.
- **Preview folder**: The location where the preview files are saved.
- **Default qvp server**: The default address of your qvp server. It will automatically appear each time you create a new connection.
- **Qlik Sense Server**: The default address of your Qlik Sense server. It will automatically appear each time you create a new connection.
- **Logs folder**: The directory where the log files for the Qalyptus application are saved.
- **File prefix**: Your log files have the following format: “File prefix_yyyymmdd”. You can customize the File prefix.

## Appearance

In this tab, you can change the interface language of Qalyptus as well as other display settings.

## License

In this tab, you can retrieve the license owner (Windows domain account) and update your license.

## My account

This tab allows you to enter the address of your Qalyptus Server and to choose the authentication mode necessary to publish your project in Qalyptus Server.

### Use Qalyptus Server Engine:

This feature allows using the Qalyptus Server Engine to refresh the connections and generate the reports. This means that Qlyptus Desktop will not communicate directly with Qlik Sense and will not use the resources (RAM and CPU) of the machine where it is installed.

When using this option?

- When you do not want to install the Qlik Sense certificates on the PC where Qalyptus Desktop is installed. The communication with Qlik Sense is done only through Qalyptus Server.
- When you work with a voluminous Qlik Sense application. Qalyptus Desktop is 32 bits program. A program that uses 32-bits of RAM can only

## About

In this tab, you see information about Qalyptus.
