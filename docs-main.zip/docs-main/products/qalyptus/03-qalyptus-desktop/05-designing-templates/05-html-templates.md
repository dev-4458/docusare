---
title: HTML templates
---

In this section, we will create an HTML template using Qlik Sense objects.

To create an HTML template, go to the **Templates** tab and click **Create** button. Your screen will look something like this:

![Qalyptus HTML Template](/img/docs-images/qalyptus_excel_template.png)

1. In the Type drop-down menu, select HTML
2. Give a name to your template. Example: Performance HTML template
3. It is recommended to add a description
4. You have two options to create a new template. You can click ![](/img/docs-images/open-template.png) to create a new HTML file or click ![](/img/docs-images/browse-file.png) to create your template from an existing HTML file.
5. Save your work

Click ![](/img/docs-images/open-template.png) to create a new HTML file. Your screen will look something like this:

![Qalyptus HTML Template File](/img/docs-images/qalyptus-html-template-file.png)

1. An HTML file is open in the Qalyptus
2. Connections: list of the Qlik Sense and QlikView connections created in the **Connections** page
3. Variables: list of the Qlik variables of the selected connections. Select the ones you want to use
4. Objects: list of the Tables, Charts, and Master Items of the selected connections. Select the ones you want to use
5. Used: here, you will find the objects and variables you want to use in your template.
6. Save button allows you to save the template.
7. The preview button allows you to have a preview of the report

## Add objects to create the template

This short video will show how to use your Qlik Sense objects to create a simple HTML template.

<iframe width="560" height="315" src="https://www.youtube.com/embed/RL96r3kgATY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Advanced options

### 1- Add a filter to an object

In addition to applying filters at the report and task levels, you can apply a filter for each Qlik object you use in your template.

Right-click on the object you want to add a filter, then select **Properties**. In the Properties screen, select the filter to apply from the available filters.
Only one filter can be applied to an object.

![Qalyptus Object Filter HTML](/img/docs-images/Qalyptus-object-filter-html.png)

### 2- Export a Qlik Sense object as an image with a dimension different from the usage dimension in the template file

When you want to use a Qlik Sense object (chart or table) as an image in your report template, drag and drop the object to the template file. Qalyptus will create a placeholder image that you can resize. When you generate the report, Qalyptus will export the Qlik Sense object with the dimension of the placeholder image and put it in the place of the placeholder image.

It is possible to export the image with large or small size as the placeholder image size. For example, export the image 1200 x 800 px and use it in the file with the size 1000 x 600 px.

Select the option **Custom export dimensions** in the object Properties, then enter the **Height** and **Width** value.

![Export Image With Custom Size](/img/docs-images/export-image-with-custom-size.png)

Exporting an object with a large size allows you to get more information; because Qlik Sense can hide some information when you reduce the object’s size.

**Chart with a small size (export size = size of use )**

![Chart small size](/img/docs-images/Chart-small-size.png)

**The same chart with a large export size (export size > size of use )**

![Chart large size](/img/docs-images/Chart-large-size.png)

### 3- Repeat charts and tables in a div for each value of a dimension

You can repeat the contents of an HTML div for each value in a dimension field. You can nest the repeat levels as many times as you want.

<iframe width="560" height="315" src="https://www.youtube.com/embed/83YYLcUrsPI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Status

A template can have three different status:

- <span style={{color: "green"}}>Valid template </span>
- <span style={{color: "red"}}>File not found</span>
- <span style={{color: "red"}}>No objects or variables used</span>
