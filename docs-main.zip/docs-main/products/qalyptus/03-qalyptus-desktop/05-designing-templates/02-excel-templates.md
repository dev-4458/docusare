---
title: Excel templates
---

In this section, we will create an Excel template using Qlik Sense objects.

To create an Excel template, go to the **Templates** tab and click **Create** button. Your screen will look something like this:
![Qalyptus Excel Template](/img/docs-images/qalyptus_excel_template.png)

1. In the **Type** drop-down menu, select Excel
2. Give a name to your template. Example: Performance Excel template
3. Add a description (optional)
4. You have two options to create a new template. You can click ![](/img/docs-images/open-template.png) to create a new Excel file or click ![](/img/docs-images/browse-file.png) to create your template from an existing Excel file.
5. Save your work

Click ![](/img/docs-images/open-template.png) to create a new Excel file. Your screen will look something like this:

![Qalyptus Excel Template File](/img/docs-images/qalyptus_excel_template-file.png)

1. An Excel file is open in the Qalyptus application
2. Connections: list of the Qlik Sense and QlikView connections created in the Connections page
3. Variables: list of the Qlik variables of the selected connections. Select the ones you want to use
4. Objects: list of the Tables, Charts, and Master Items of the selected connections. Select the ones you want to use
5. Used: here, you will find the objects and variables you want to use in your template
6. Save button allows you to save the template
7. The preview button allows you to have a preview of the report

## Add objects to create the template

This short video will show how to use your Qlik Sense objects to create a simple Excel template.

<iframe width="560" height="315" src="https://www.youtube.com/embed/pKtDxV5C9nM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

## Advanced options

### 1- Add a filter to an object

In addition to applying filters at the report and task levels, you can apply a filter for each Qlik object you use in your template.

Right-click on the object you want to add a filter, then select **Properties**. In the Properties screen, select the filter to apply from the available filters.
Only one filter can be applied to an object.

![Qalyptus Object Filter Excel](/img/docs-images/Qalyptus-object-filter-excel.png)

### 2- Not insert new rows

When you use a table, Qalyptus, by Default, inserts new rows to keep the same layout of your different objects. But in some cases, you may want Qalyptus not to insert rows, for example, when you have several objects next to each other.

You have the option of not inserting rows when exporting a table.

Right-click on a table or pivot table object, then select **Properties**. In the Properties screen, check the checkbox, **Not insert rows**.

![Not Insert Rows](/img/docs-images/Not-insert-rows.png)

### 3- Choose pivot table rows presentation

You can choose how you want to export a pivot table. You have the choice between Default (the settings selected in Qlik Sense), Extend all, or Collapse all.

![PivotTable Rows Presentation](/img/docs-images/PivotTable-rows-presentation.png)

### 4- Export a Qlik Sense object as an image with a dimension different from the usage dimension in the template file

When you want to use a Qlik Sense object (chart or table) as an image in your report template, drag and drop the object to the template file. Qalyptus will create a placeholder image that you can resize. When you generate the report, Qalyptus will export the Qlik Sense object with the dimension of the placeholder image and put it in the placeholder image.

It is possible to export the image with large or small size as the placeholder image size. For example, export the image 1200 x 800 px and use it in the file with the size 1000 x 600 px.

Select the option **Custom export dimensions** in the object Properties, then enter the **Height** and **Width** value.

![Export Image with Custom Size](/img/docs-images/export-image-with-custom-size.png)

Exporting an object with a large size allows you to get more information; because Qlik Sense can hide some information when you reduce the object’s size.

**Chart with a small size (export size = size of use )**

![Chart small size](/img/docs-images/Chart-small-size.png)

**The same chart with a large export size (export size > size of use )**

![Chart large size](/img/docs-images/Chart-large-size.png)

### 5- Repeat charts and tables in the same sheet or create a sheet for each value of a dimension

Qalyptus allows repeating data by dimension in a report. You can repeat Images, Tables, and Variables.

You can repeat the same sheet’s contents for each value in a dimension field. You can also repeat your Qlik Sense objects on a single sheet for a field value. You can nest the repeat levels as many times as you want.

See how you can do it.

<iframe width="560" height="315" src="https://www.youtube.com/embed/0CZPq0Bwp7k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

### 6- Repeat table header row across pages for a PDF export

To repeat the first row of column headers on all pages when you have a large and complex worksheet, drag and drop the columns of the table object then:

1. In Excel, click the **Page Layout** tab
2. In the **Page Setup** group, click **Print Titles**
3. Under the **Sheet** tab, in the **Rows to repeat at top** field, click on the icon on the right.
4. Select the row you wish to appear at the top of every page. Press the **Enter** key
5. Then click **OK**

![Repeat Table Header Excel](/img/docs-images/Repeat-table-header-Excel.png)

Here is the result:

![Repeat Table Header Excel Result](/img/docs-images/Repeat-table-header-excel-result.gif)

## Status

A template can have three different states:

- <span style={{color: "green"}}>Valid template </span>
- <span style={{color: "red"}}>File not found</span>
- <span style={{color: "red"}}>No objects or variables used</span>
