---
title: Introduction
---

Qalyptus allows you to create your custom reports by using templates.

You can create templates using Office Excel, Word, and PowerPoint to generate reports in standard formats such as PDF, Excel, Word, PowerPoint, and HTML.

:::note
When you create a template you can use it in one or more reports. If multiple reports need to use the same template, you can maintain a single template and be sure the reports use the same template.
:::

See how to create:

- [Excel templates](/products/qalyptus/qalyptus-desktop/designing-templates/excel-templates)
- [Word templates](/products/qalyptus/qalyptus-desktop/designing-templates/word-templates)
- [PowerPoint templates](/products/qalyptus/qalyptus-desktop/designing-templates/powerpoint-templates)
- [HTML templates](/products/qalyptus/qalyptus-desktop/designing-templates/html-templates)
