---
title: Create schedules
---

The **Schedules** page displays the list of schedules with their name, type, frequency, number of tasks, and description.

To create a new schedule:

1. On Qalyptus Server, go to the **Schedules** tab

![Qalyptus Server Schedules](/img/docs-images/Qalyptus-server-schedules.png)

2. Click **Create Schedule**

![Qalyptus Schedule](/img/docs-images/qalyptus-schedule.png)

3. Enter the information in the following fields:

- **Name**: Enter the name of the schedule
- **Frequency**: Choose the frequency of the programming. You can set: Once, Hourly, Daily, Weekly, Monthly, or Yearly
- Choose the **Start** and the **End** Date
- Select your preferred **Time zone**
- Choose the task **execution** type: Parallel or Serial.
  When you choose Parallel, the task can run simultaneously with other tasks.
  If you choose Serial, the task will run separately from other tasks.
  If a serial task is running, the tasks that run after it will be in the queue. If a serial task is executed when other tasks are running, it is queued until all the tasks are completed.
- Set a **Priority** from 1 to 100, where 1 is the highest priority. Priority will be assigned to those tasks in which the schedule is used. If two tasks are pending in the queue, the one with the higher priority runs first.

4. Click **Save**.

To edit an existing schedule:

1. On Qalyptus Server, go to the **Schedules** tab
2. Click on the **Action** button of the schedule you want to edit
3. Click **Edit**
4. Make your changes, and then click **Save**
