---
title: Introduction
---

In order to generate and distribute your reports created from Qlik Sense and QlikView automatically, it is necessary to set the generation times and distribution means.

- [Create destinations](/products/qalyptus/qalyptus-server/distribute-reports/create-destinations)
- [Creating schedules](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules)
- [Create tasks](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/create-tasks)
- [Tasks status](/products/qalyptus/qalyptus-server/distribute-reports/tasks-status)

## Publishing Reports with Qalyptus

<iframe width="560" height="315" src="https://www.youtube.com/embed/veRBObpxyHU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
