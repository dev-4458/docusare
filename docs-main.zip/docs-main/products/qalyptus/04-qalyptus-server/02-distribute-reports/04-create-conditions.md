---
title: Create conditions
---

You can add one or more conditions to execute a task in Qalyptus Server. The task is only executed if all the conditions are satisfied.

:::note
The task is only executed if all the conditions assigned to the task (All reports) are satisfied. After execution, Qalyptus will evaluate the conditions applied to each report, if the conditions are not satisfied, report generation is skipped.
:::

To create a Condition, do the flowing:

1. On Qalyptus Server, go to the **Conditions** Page
2. Click **Create Condition**
3. Enter a **Name**
4. Add a description if you want
5. Choose a **Project** to associate to the condition
6. Click **Save**
7. Then click **Edit**
8. In the **Rules** tab, click **Add Rule**.

A condition is composed of different rules. For a condition to be satisfied, all the rules must be satisfied.
You can create a rule by comparing:

- A variable to a custom value
- A variable to the result of a Qlik expression
- A variable to another variable
- Check if a chart has values or not
- A KPI to a custom value
- A KPI to the result of a Qlik expression
- A KPI to a variable

![Qalyptus Condition Rules](/img/docs-images/qalyptus-condition-rules.png)

1. Click **Add**
2. Then click **Save**
