---
title: Tasks status
---

It is important to follow the execution of the report generation tasks. Tasks statuses are available on the **Status** page.

This page contains two parts: **Scheduled Tasks**, **On-demand requests**, and **Report subscriptions**.

## Scheduled tasks

In this tab, you will find all tasks that have at least one programming. The tab contains the following items:

Run button and Stop task.

- **Task Name**.
- **Name of the programming**.
- **Flag** if the task is active or not.
- **Status**: Job Status (Never, Queued, Running, Stopped, Error, Completed).
- **Last Execution**: The start date of the last run.
- **Next Execution**: Date of the next run of the task.
- **Action/Open log file**: Download and open the log file linked to the task’s last execution.

## On-demand requests

This tab contains all tasks and reports run on demand. Tasks and reports run from the [Tasks](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/create-tasks), Reports page or outside (with the Qalyptus API). Example: On-demand generation of reports from Qlik Sense App using [Qalyptus On-Demand](https://github.com/qalyptus/qalyptus-sense-on-demand) extension.

This tab contains the following items:

- **Run** and **Stop** button.
- **Title** of the task or report.
- **Source** of the element.
- The output **format** of the report (s).
- **Name of the project** to which the item is linked.
- **Status**: Execution Status (Never, Queued, Running, Stopped, Error, Completed).
- **Last Execution**: The start date of the last run.
- **End of execution**: The end date of the last run.
- **Action/Download**: Download the result of the run if its source is: **On-demand** or **Report**.
- **Action/Open log file**: Download and open the log file linked to the last run.
- **Action/Delete**: Delete the item.

## Report subscriptions

This tab contains all the subscriptions to reports created by users. A subscription is a scheduled task to generate a report and send it to a user by email.

This tab contains the following elements:

- Name of the report.
- The subject of the email.
- The name of the owner of the subscription.
- The schedule was chosen to receive the report.
- The last status of the task execution.
- Date of the last execution of the task.
- Date of the next execution of the task.

In the **Action** menu, it is possible to see the log of the execution of the task, modify the subscription, and unsubscribe a user from a report.

:::note
When a task send reports by email, Qalyptus generate a log file for each email sent by Qalyptus. In this file, you can see the status of the SMTP activity. If you don’t receive an email sent by Qalyptus, you can check the log file to understand why.

In the task log, you see the path to the folder that contains the email log files.
:::
