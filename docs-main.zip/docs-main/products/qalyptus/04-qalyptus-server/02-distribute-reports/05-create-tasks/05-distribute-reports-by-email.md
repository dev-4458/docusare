---
title: Distribute reports by email
---

When the task is running, you can send an email to users to distribute reports or notify them.

To configure the email that will be sent to users at the end of reports generation, follow the steps below:

1. On the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Distribution> Email**.
3. Check the checkbox **Send email**.
4. Enter the sender’s email address in the **From** field.
5. In the **CC** field, you can add the users’ email addresses in a copy of the email (optional). Separate email addresses with a comma.
6. You can add the users’ email addresses in the **BCC** field who will be in a hidden copy of the email (optional). Separate email addresses with a comma.
7. Enter a subject for the email in the **Subject** field.
8. In the **Message** field, enter the message for the email. In addition to the text, you can add:

   - HTML reports: You can embed HTML reports directly in the body of the email. In the message editor, click on the “**Reports**” button and select the report to embed. The name of the report can also be added to the subject of the email. Before using the HTML report, you need to add it to the task reports list.
   - Qlik Sense and QlikView variables: In the message editor, click on the “**Variables**” button to add variables to the message. Variables can also be used in the subject line of the email.
   - Tags: Start writing # to add tags. The available labels are the user’s first name, the user’s email, the list of reports, and the destinations’ list.
   - Images: Click the image button to insert an image into the message.

9. To attach the reports to the email, check the **Attaching Files** checkbox. All reports in the task tab Reports with the “Email attachment” checkbox enabled will be attached.
10. Click **Save**
