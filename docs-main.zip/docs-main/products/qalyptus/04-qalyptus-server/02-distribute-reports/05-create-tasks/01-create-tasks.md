---
title: Create tasks
---

In this section, we will see how to create tasks and schedule the execution of a task. A task can be executed on-demand or can be run recurrently using [Schedules](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules).

To create a task, follow these steps:

1. On Qalyptus Server, go to the **Tasks** tab.
2. Click the **Create Task** button.
3. The window below is displayed.

![Qalyptus Create Task](/img/docs-images/qalyptus-create-task.png)

4. Enter the task name and choose a project with which the task will be associated.
5. Click **Save**.
6. Then click **Publish**.
7. The window below will display.

![Qalyptus Publish Task](/img/docs-images/qalyptus-publish-task.png)

## Send a notification after task execution

You can send an email notification at the end of a task to inform people of the task’s status; the task ended with errors, warnings, or success. The log file of the task is attached to the email.
For each task, you can choose which status you want to send a notification for and the recipients.

## Send reports to test recipients

When you schedule a task to send reports to recipients, you may want to receive the emails at a specific email address to ensure that every recipient receives the email with the expected text and attachments.

After activating the **Test mode**, the emails will be sent to a specific email address at the end of the task execution. The email object will be prefixed with the original recipient’s email address.

If you have 20 recipients in your task and enter your email address when you activate the **Test mode**, you will receive 20 emails, and the recipients will receive nothing. If everything is OK, disable the Test mode, and the recipients will receive the emails at the next execution of the task.

![Qalyptus Task Test Mode](/img/docs-images/qalyptus-task-test-mode.png)

## Publish reports

To publish reports with this task, follow these steps:

- [Add reports](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-reports)
- [Add filters](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-filters)
- Choose the distribution methods: [Folder](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-to-folders), [Email](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-by-email), [Qalyptus Hub](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/distribute-reports-to-the-qalyptus-hub)
- [Add recipients](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-recipients-of-published-reports)
- [Add schedules](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-schedules-to-a-task)
- [Add conditions](/products/qalyptus/qalyptus-server/distribute-reports/create-tasks/add-conditions-to-a-task)
