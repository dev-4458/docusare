---
title: Distribute reports to the Qalyptus Hub
---

You can distribute reports to the Qalyptus Hub. The Hub allows users to view, download and subscribe to reports to which they are entitled.

To publish reports of a tasks to the Hub, follow these steps:

1. In the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Distribution> Hub**.
3. Check the checkbox **Publish reports to Hub**.
4. Enter the **maximum number of file occurrences** to keep. Enter 0 to not limit the number of occurrences. If for example you enter the number 5, Qalyptus will keep only the last 5 versions of each file. Older versions will be deleted.
5. Click **Save**.
