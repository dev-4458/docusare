---
title: Distribute reports to folders
---

Qalyptus Server can distribute reports to folders on a hard disk or on a remote server via FTP. Before adding destinations, you must create the destinations in the [Destinations](/products/qalyptus/qalyptus-server/distribute-reports/create-destinations) page.

To add destinations to a task, follow these steps:

1. In the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Distribution > Destinations**.
3. Click **Add Destinations**.
4. A window appears.
5. Select one or more destinations.
6. Click **Add**.
7. Click **Save**.
