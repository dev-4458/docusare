---
title: Add recipients of published reports
---

In this section, you will be able to add the users or group of users that will be the recipients of the reports published with a task.

The users you will add can receive the email sent during the execution of the task and/or have access to the reports in the Qalyptus Hub.

To add recipients, follow these steps:

1. On the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Recipients**.
3. Click **Add Users**.
4. A window opens.
5. Select one or more users.
6. Select the **Send e-mail** checkbox to allow the user to receive the distribution email.
7. Select the **Can see in Hub** checkbox to allow the user to view reports in the Qalyptus Hub.
8. Click **Add**.
9. Click **Save**.

To add a group of users, follow the same steps by clicking on the **Add Groups** button.
