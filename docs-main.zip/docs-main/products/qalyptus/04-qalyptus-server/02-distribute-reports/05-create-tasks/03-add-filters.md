---
title: Add filters to a task
---

Qalyptus allows you to apply [filters](/products/qalyptus/qalyptus-desktop/create-filters) to tasks before generating your reports. To add filters to a task, follow these steps:

1. In the **Tasks** page, click on the name of a task to edit it.
2. Go to the **Filters** tab.
3. Click **Add Filters**.
4. A window appears.
5. Select one or more filters.
6. Click **Add**.
7. If necessary, order the filters using the ↓ and ↑ buttons.
8. Click **Save**.
