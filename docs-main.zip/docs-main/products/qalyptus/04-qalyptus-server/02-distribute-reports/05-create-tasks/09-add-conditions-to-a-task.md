---
title: Add conditions to a task
---

To run a task only if certain conditions are met, you should assign one or more Conditions to the task.

To add a condition to a task, follow these steps:

1. On the **Tasks** page, click on the name of a task to edit it
2. Go to the tab **Conditions**
3. Click on **Add Conditions**
4. A window opens
5. Select one or more conditions
6. Choose if you want to apply the condition **to the task** or **reports**

   - **To the task**: Qalyptus will evaluate the condition before starting to generate the reports. The condition is evaluated after applying the task filters
   - **To reports**: Qalyptus will evaluate the condition only for the selected reports. The condition is evaluated after applying the report filters. If the report is an Iteration report, you can choose, in the **Reports** tab, between:
     - Evaluating the condition before starting the generation of the report
     - Evaluating the condition for each Iteration (before generating each of the report files)

7. Click **Add**
8. Click **Save**

:::note
The task is only executed if all the conditions assigned to the task are satisfied. After execution, Qalyptus will evaluate the conditions applied to each report, if the conditions are not satisfied, report generation is skipped.
:::
