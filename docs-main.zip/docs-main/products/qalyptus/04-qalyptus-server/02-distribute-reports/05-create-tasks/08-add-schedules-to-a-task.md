---
title: Add schedules to a task
---

To schedule a task and allow it to run automatically, you should assign one or more [schedules](/products/qalyptus/qalyptus-server/distribute-reports/create-schedules) to it.

To add a schedule to a task, follow these steps:

1. On the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Schedules**.
3. Click on **Add Schedules**.
4. A window opens.
5. Select one or more schedules.
6. Click **Add**.
7. Click **Save**.

The list of scheduled tasks is visible on the page **Status > Scheduled tasks**.

:::note
A scheduled task will run on the date and time of its schedules only if it is active.
:::
