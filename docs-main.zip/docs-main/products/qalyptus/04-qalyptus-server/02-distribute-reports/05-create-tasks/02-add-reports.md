---
title: Add reports
---

To add reports to a task, follow these steps:

1. After creating a task, click on the **Publish** button. Or, on the **Tasks** page, click on the name of a task to edit it.
2. Go to the tab **Reports**.
3. Click **Add Report**.
4. A window appears.
5. Select a report from the available reports in the **Report** drop-down list.
6. Select the report output **format** from the available formats.

![Qalyptus Publish Report](/img/docs-images/qalyptus-publish-report.png)

For more flexibility, you can choose for each report added to a task how do you want to distribute it:

- Save to folder
- Publish to Qalyptus Hub
- Email attachment
- Email embedment (for HTML reports)

7. If the selected report is a report that contains an Iteration, other options are displayed.

![Qalyptus Publish Iteration Report](/img/docs-images/qalyptus-publish-iteration-report.png)

- **Zip files in the destination folder**: If you check this checkbox, the files generated and saved in a folder will be compressed into a Zip file.
- **Zip files when sent by email**: If you check this checkbox, the reports sent as an email attachment will be grouped in a zip file.
- **If a condition is applied, evaluate it for each iteration**: If you check this checkbox, Qalyptus will evaluate the report’s conditions before generating each file of the report.

- **Folder storage**: This option allows you to use a Qlik Sense or QlikView variable to distribute each file created during an Iteration to one or more specific destinations.

  - Example 1: You want to create a report by **City**, and you want each report to be saved in a folder with the name of the city: `D:\Marketing Files\<City name>`. In this case, you need to create a variable in the report source application (Qlik Sense or QlikView), which will have a value the storage path of each file according to the selected city. The definition of the variable will look like this: vStoragePathCityReport = ‘D:\Marketing Files\’&City_name. Assuming that City_name is a field that contains cities. Thus, the city = Paris report will be saved in the folder: `D:\Marketing Files\Paris`.
  - Example 2: You now want to generate reports by City and save the files in folders with the name of the city’s country. In this case your variable will look like this: vStoragePathCityReport = ‘D:\Marketing Files\’&County_name. Assuming that County_name is a field that contains countries. Thus, the report for the city = Paris will be saved in the folder: ‘D:\Marketing Files\France’
  - Example 3: To save a file in several folders, separate the path list with a comma, for example, using the “Concat ()” function. If, for example, you want to save the file of each city in folders bearing the names of managers of the city, the variable will look like this: vStoragePathCityReport = Concat(‘D:\Marketing Files\’&Manager_name, ‘,’). Assuming that Manager_name is a field that contains city managers.

- **Email distribution**: This option allows you to use a Qlik Sense or QlikView variable to distribute by email each file created during an Iteration to one or more recipients. This option works the same way as Folder storage. Please watch the video below to see how to send the same report to different users with different data.

:::note
The scenario in the video uses the users’ Email, but you can use the users’ Domain Account.
:::

<iframe width="560" height="315" src="https://www.youtube.com/embed/YvnyjlrsBIk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

- **Visibility in the HUB**: This option allows you to use a Qlik Sense or QlikView variable to limit access to each file created during an Iteration in Qalyptus Hub. This option works the same way as Folder storage.
  - Example 1: You can generate reports by **Seller** and publish them in the Qalyptus Hub portal. If you want each seller to only see their report, in this case, you need to create a variable that will have a value equal to the seller’s email or domain account during the iteration. Thus, each seller will only be able to see their report.
  - Example 2: You want a seller’s report to be visible in Qalyptus Hub only for the seller and his Manager. In this case, your variable must contain the ID (email or domain account) of the seller and his manager, separating them with a comma.

8. Click the Add button.

9. Then Click Save.
