---
title: Dashboard
---

In order to have a global view on the use of Qalyptus Server, access the Qalyptus Dashboard by clicking on the **Qalyptus Administration** menu which is next to your user name, then click **Dashboard**. This dashboard allows you to simultaneously have information on all the entities of your Qalyptus Server.

![Qalyptus Server Dashboard](/img/docs-images/Qalyptus-server-dashboard.png)

You will find in this page the following elements:

- **Projects**: This is the number of projects in Qalyptus Server. You also have information on the number of projects used in at least one scheduled task.
- **Reports**: This is the number of reports in Qalyptus Server. You also have information on the number of reports used in one or more tasks.
- **Destinations**: This is the number of destinations in Qalyptus Server. You also have information on the number of destinations used in one or more tasks.
- **Tasks**: This is the number of tasks in Qalyptus Server with information on the number of tasks that have one or more schedules.
- **Tasks Status distribution**: This is a sector chart that represents the distribution of scheduled tasks based on their status.
- **Scheduled for the next 7 days**: Displays the list of scheduled tasks that will run in the next 7 days with the date and time of execution.

On the Dashboard page and in the **Administrators** tab, you will find the list of users with an administrator role.
