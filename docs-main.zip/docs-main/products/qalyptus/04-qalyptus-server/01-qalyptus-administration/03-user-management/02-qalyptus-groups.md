---
title: Qalyptus Groups
---

You can organize Qalyptus Server users into groups to make it easier to manage multiple users. You can create groups on the server or import groups from Active Directory and Azure AD.

By default, only users with the Administrator role can create, edit, and delete groups. It is possible to allow groups to be managed by certain users by assigning them a role with permissions to create, modify or delete groups.

Active Directory and Azure AD groups are created at the same time as [user creation](/products/qalyptus/qalyptus-server/qalyptus-administration/user-management/qalyptus-users).

## Add local groups

1. Log in to Qalyptus Server as an administrator.
2. Go to Administration> **User Management**.
3. Select the **Groups** tab and click Enter a name in the **Group Name** field and click **Create Group**.

![Qalyptus Server Groups](/img/docs-images/Qalyptus-server-groups.png)

## Add users to a group

All users are automatically added to the system group “**All users**” which contains all users.

To Add users to a group, follow these steps:

1. Choose a group and click the **Action** button to display the actions menu.

![Qalyptus Server Groups Edit Members](/img/docs-images/Qalyptus-server-groups-edit-members.png)

2. Click **Edit Members**.
3. Select the list of users you want to add to the group, and click **Add**.
4. Click **Save**.
