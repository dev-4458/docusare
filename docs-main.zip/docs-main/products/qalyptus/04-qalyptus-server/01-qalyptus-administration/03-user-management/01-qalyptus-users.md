---
title: Qalyptus Users
---

Anyone who needs to access Qalyptus Server, whether to browse, publish, modify content, or administer the site, must be added as a user. Administrators and users with the necessary rights have the following options to add users:

- Add local users.
- Add users from Active Directory.
- Add users from Azure AD.

By default, only users with the Administrator role can create, edit, and delete users. It is possible to allow user management for certain users by assigning them a role with permissions to create, modify or delete users.

## Add local users

1. Log in to Qalyptus Server as an administrator.
2. Go to Administration> **User Management**.
3. Select the **Users** tab and click **Add Users**, then **Create User**.

![Qalyptus Server Create Users](/img/docs-images/Qalyptus-server-create-users.png)

4. Enter the information in the following fields:

- **Enable**: Choose to enable or disable the user’s account.
- **Display name**: Type the display name of the user (Example: David Page).
- **Username**: Type a unique name for the user.
- **Email**: User’s email. It must be unique.
- **Domain Account**: Fill in this field if you want users to log in with their Windows credentials. It must be unique.
- **Language**: Choose the language of the user. This option can be changed later in the user profile settings.
- **Ask the user to create his password**: Check this checkbox to send an e-mail to the user with a link allowing him to create his password to have his Qalyptus credentials. If you do not check this box, the user can create his password in the Qalyptus Server login interface by clicking on the “Forgotten password” link.
- Add **roles for the user**.

5. Click **Save**

## Import Users from Excel

To automate adding users to Qalyptus, you can create an Excel file that contains user’s information and then import the file.

To import Users from Excel:

1. Log in to Qalyptus Server as an administrator.
2. Go to Administration> **User Management**.
3. Select the Users tab and click **Add Users**, then **Import from Excel**.
4. Select **Browse**.
5. Select your Excel File.
6. Click **Import Users**.

![Qalyptus Server Import Users from Excel](/img/docs-images/Qalyptus-server-import-users-excel.png)

You must use an Excel file that respects the order of the expected columns. Only the first sheet will be used. Please download and use the template and follow the instructions available in each column.

## Add users from Active Directory

To add users from Active Directory, do the following:

1. Log in to Qalyptus Server as an administrator.
2. Go to Administration> **User Management**.
3. Select the **Users Directories** tab, click **Create Directory**, and choose **Active Directory**.

![Qalyptus Server Import Users from Active Directory](/img/docs-images/Qalyptus-server-users-active-directory.png) 4. Enter the information in the following fields:

- **Name**: Type the name of the directory.
- **Path**: Type the LDAP path.
- **Username**: This field is optional. If necessary, type the user name of the Active Directory.
- **Password**: This field is optional. If necessary, type the name of the Active Directory password.
- **LDAP filter**: This field is optional. If needed, you can apply a filter on the users to import.
- **Ask new users to create their password**: Check this checkbox to send an email to each new user with a link allowing them to create their password to have their Qalyptus credentials. If you do not check this box, the user can create his password in the Qalyptus Server login interface by clicking on the “Forgotten password” link.
- **Default role**: You can assign a role to users who will be imported from Active Directory.
- **Synchronization**: You can either manually start importing users or schedule the import. Choose the Automatically option to schedule the import of users.

5. Click **Save**
6. To import and synchronize users, return to the **Administration> User Management> User Directories** page
7. Click the button to the right of the Active Directory to synchronize, and then click **Synchronize**.

![Qalyptus Server Sync users from active directory](/img/docs-images/Qalyptus-server-users-active-directory-sync.png)

## Add users from Azure AD

Before creating Azure AD importation, you need to register an app on your Azure AD. See [here](https://docs.microsoft.com/en-us/graph/auth-register-app-v2) how to do it.

To add users from Azure AD, do the following:

1. Log in to Qalyptus Server as an administrator.
2. Go to Administration> User Management.
3. Select the Users Directory tab, click Create Directory, and choose Azure AD.
   ![Qalyptus Server users from Azure AD](/img/docs-images/Qalyptus-server-users-azure-ad.png)
4. Enter the information in the following fields:

- **Name**: Type the name of the directory.
- **Application ID**: Type the app ID (client).
- **Directory ID**: Type the ID of the directory (tenant).
- **Client Secret key**: Type Client Secret key to be authenticated by Azure AD.
- **Ask new users to create their password**: Check this checkbox to send an email to each new user with a link allowing them to create their password to have their Qalyptus credentials. If you do not check this box, the user can create his password in the Qalyptus Server login interface by clicking on the “Forgotten password” link.
- **Default role**: You can assign a role to users who will be imported from Azure AD.
- **Synchronization**: You can either manually start importing users or schedule the import. Choose the Automatically option to schedule the import of users.

5. Click **Save**
6. To import and synchronize users, return to the **Administration> User Management> User Directories** page
7. Click the button to the right of the Azure AD to synchronize, and then click **Synchronize**.

:::note
Synchronization allows you to import new users and groups and remove users and groups that no longer exist in Active Directory or Azure AD.
:::
