---
title: Qlik Sense Applications
sidebar_label: Applications
---

In this section, you configure and manage the synchronization of the Qlik Sense applications with Qalyptus Hub. This will allow users to find in the same place (Qalyptus HUB) their Qlik Applications, reports, and other resources.

:::note
As in Qlik Sense Hub, a user will see only the applications to which he is entitled.
:::

## Synchronize the Qlik Sense applications

To synchronize the Qlik Sense applications with Qalyptus, follow these steps:

1. Connect to Qalyptus Server
2. Ensure that the Qlik Sense server address and a Qlik Sense user are entered in Hub Configuration> General. See this section for more details.
3. Go to Qalyptus Administration> Hub Conbfiguration> Apps
4. Click **Synchronization**
5. A new window appears
6. Select the **Default folder for the new apps**
7. Choose a **Schedule** from your existing schedules
8. Click **Save**
9. You can run the Synchronise manually by clicking **Synchronize**

![Qalyptus Server Change App Folder](/img/docs-images/qalyptus-server-synchronization.png)

At the end of the synchronization process, the new applications will appear, the existing apps will be updated, and the applications deleted in Qlik Sense will be removed.

You can synchronize a specific application. This will only sync metadata for that app.

## Available configurations for a Qlik Sense application

For a better user experience, you can configure each Qlik Sense application to appear in the desired way in Qalyptus HUB.

- You can choose in which folder or subfolder the application will be located
- If you manage different Organizations, you can choose an organization for the app. Only the members of the organization can see the application (a member must also be authorized in Qlik Sense)
- Create a Mashup. You can easily create a custom mashup and linked it to the app. Users will be able to open the app as a standard Qlik Sense app or as a mashup
- Choose if you want to allow to open the app as a standard app, like a mashup, or both
- Choose what will happen when the user clicks on the app’s Thumbnail: Open the app as a standard app or as a mashup. This option depends on the choice of the previous option.

![Qalyptus Server Configure App](/img/docs-images/qalyptus-server-configure-app.png)

## Create a mashup with a Qlik Sense application

In Qalyptus Hub, you can authorize to open a Qlik Sense application in the standard way (like in Qlik Sense Hub) or as a custom mashup.

Here is how to create a mashup:

1. In Qalyptus Administration> Hub Configuration> Apps, edit an app
2. Select a **Mashup template**
3. Click **Configure**
4. A new window appears
5. Give a name to the Mashup
6. If needed, enter another Qlik Sense theme id (optional)
7. Select the sheets of the application you want to add to the mashup
8. Rename the sheets (optional)
9. Change the order of the sheets (optional)
10. For each sheet, show or not the selections toolbar
11. Put the sheets in groups (optional)
12. Click **Preview** to see the result
13. Click **Save**

![Qalyptus Server Configure App Mashup](/img/docs-images/qalyptus-server-configure-app-mashup.png)

In the option “Open as”, choose “Mashup” or ” App and Mashup”

![Qalyptus Server Configure App Mashup](/img/docs-images/qalyptus-server-configure-app-mashup-options.png)

In Qalyptus HUB, the app can now be open with the configured Mashup.

![Qalyptus Server App Mashup Opened](/img/docs-images/qalyptus-server-hub-open-app-as-mashup.png)

**The application opened as Mashup**

![Qalyptus Server C](/img/docs-images/qalyptus-server-open-app-with-mashup.png)
