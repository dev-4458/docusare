---
title: Resources
---

In Qalyptus HUB, in addition to Qlik Sense apps and reports, it is possible to provide users with links to external resources. Example: link to a web page, link to files in SharePoint, …etc.

A resource is a valid URL to any web page or file. the URL must start with HTTP:// or HTTPS://.

If you manage several Organizations, A resource is affected to one organization.

To create a resource, follow these steps:

1. Connect to Qalyptus Server
2. Go to Qalyptus administration> Hub Configuration> Resources
3. Click Create Resource
4. Enter a name to the resource
5. Enter a description (optional)
6. Enter a link to the resource (must be a valid URL)
7. Choose an organization (if you manage multiple organizations)
8. Click **Save**

![Qalyptus Server Create Resources](/img/docs-images/qalyptus-server-create-resource.png)

The resource will be visible to users in Qalyptus HUB.

![Qalyptus Server Resources](/img/docs-images/qalyptus-server-resources.png)
