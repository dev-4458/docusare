---
title: Folders
---

Folders allow you to organize the Qlik Sense applications in Qalyptus HUB. Lorsque vous synchronisez vos applications Qlik Sense avec Qalyptus Hub, les applications s’affichent dans des dossiers et sous-dossiers.

To create a folder, follow these steps:

1. Connect to Qalyptus Server
2. Go to Qalyptus Administration> Hub Configuration> Folders
3. Click **Create Folder**
4. Enter the folder name
5. Choose the folder Parent
6. Click **Save**

## Add a Qlik Sense application to a folder

When an app is synchronized to Qalyptus Hub, it is saved in the default folder specified in the synchronization settings. To change the location of the app and add it to another folder, follow these steps:

1. Go to Qalyptus Administration > Hub Configuration> Apps
2. Edit the app to which you want to change the folder
3. Select the new folder
4. Click **Save**

In Qalyptus Hub, the application will appear in the new folder.

![Qalyptus Server Change App Folder](/img/docs-images/qalyptus-server-change-app-folder.png)

## Apps and Folders in Qalyptus Hub

In Qalyptus Hub, all apps in the root folder (“/”) and folders with a parent is the root folder, will appear in the “My Hub” level.

![Qalyptus Server Folders Hub](/img/docs-images/qalyptus-server-folders-hub.png)
