---
title: Themes
---

Qalyptus Server installs with a default theme (logo and colors). If you need to change the default theme to a custom theme, you can create new thèmes. The default theme cannot be deleted.

## How to create a new theme?

1. Connect to Qalyptus Server as Administrator
2. Go to Qalyptus Administration> Hub Configuration> Themes
3. Click **Create Theme**
4. Enter a name for the theme
5. Enter a description (optional)
6. Choose the theme **Mode** (Light, Dark, Black). The Mode refers to the background color
7. Enter your preferred colors
8. Add a logo image
9. Click Preview to preview the result (theme applied temporarily)
10. Click **Save**
11. Refresh the page to clear the temporary theme

![Qalyptus Server Themes](/img/docs-images/qalyptus-server-themes.png)

## How to replace the default theme with a new theme?

A theme must be affected to an organization to be used. After creating a theme:

1. Go to Qalyptus Configuration> System> Organizations
2. Edit the organization to which you want to change the theme
3. In the **Overview** tab, select the new theme
4. Click **Save**

![Qalyptus Change Organization Theme](/img/docs-images/qalyptus-change-organization-theme.png)

As a theme is affected to an organization, you can have several organizations and each organization with its theme. The pages where the user is not authenticated (for example Login page) are common to all organizations. For these pages, you must choose a theme from your themes.

1. Go to Qalyptus Administration> General Settings
2. Change the **Default Theme**
3. Click **Save**

![Qalyptus Server Default Theme](/img/docs-images/qalyptus-server-default-theme.png)

## After applying the theme

After applying the theme, the Qalyptus aspect will change using the new theme colors and the logo image.

![Qalyptus  Change Theme](/img/docs-images/qalyptus-change-theme.png)

:::note
Themes feature is only available with Qalyptus Server Ultimate.
:::
