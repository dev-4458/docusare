---
title: General
---

In this section, you change the following settings:

- **Qlik Sense Server address (optional)**: Qalyptus will use this address to synchronize your Qlik Sense Application to Qalyptus Hub
- **Qlik Sese user (optional)**: To synchronize all the Qlik Sense Apps, you need to enter a Qlik Sense user with the admin role
- **Subscription: From name**: When a user subscribes to receive reports, Qalyptus will use this name as a sender name.
- **Subscription: From email**: When a user subscribes to receive reports, Qalyptus will use this email as a sender email.
- **Subscription: Custom email footer (optional)**: When a user subscribes to receive reports, Qalyptus will add the text to the end of the email message.

## Configure Qalyptus Hub

To configure Qalyptus Hub, follow the steps below:

1. Log in to Qalyptus Server as administrator
2. Go to **Administration> Hub Configuration> General**
3. Click on **Edit**
4. Enter the desired information
5. Click **Save**

![Qalyptus Server Hub Configuration](/img/docs-images/qalyptus-server-hub-configuration.png)
