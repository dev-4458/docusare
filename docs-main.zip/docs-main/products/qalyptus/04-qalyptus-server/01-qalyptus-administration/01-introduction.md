---
title: Introduction
---

After installing Qalyptus Server, the first step is to configure Qalyptus Server before starting to generate the reports.

In this section, we will discuss the following:

- General Settings
- User Management
- System

## Administering Qalyptus Server

<iframe width="560" height="315" src="https://www.youtube.com/embed/fNlpQUN3qBQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
