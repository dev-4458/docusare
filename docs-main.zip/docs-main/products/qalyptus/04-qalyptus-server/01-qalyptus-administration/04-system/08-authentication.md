---
title: Authentication
---

Authentication verifies the identity of a user. Everyone who needs access to Qalyptus Server, whether to manage the server, publish, browse, or administer a content, must be added as a user to the Qalyptus repository. The authentication method can be performed with Qalyptus credentials or Windows credentials. In all cases, each user identity must be represented in the Qalyptus Server repository.

To choose the authentications to allow in Qalyptus Server:

1. Connect to Qalyptus Server.
2. Go to **Administration> System> Authentication**.
3. Choose one or more authentication types and click **Update**.

![Qalyptus Server System Authentication](/img/docs-images/Qalyptus-server-system-authentication.png)

:::note
This page is only visible for Qalyptus Server Business and Qalyptus Server Enterprise. For Qalyptus Server Ultimate, the authentication methods are managed in Organization settings.
:::
