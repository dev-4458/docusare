---
title: Storage Services
---

Qalyptus Server allows you to save generated reports in folders and in remote storage places using the protocols FTP and SFTP.

In this section, we will see how to create storage file services to use when creating destinations.

## Create an FTP or SFTP service

To create an FTP or SFTP service, follow the steps below:

1. Connect to Qalyptus Server.
2. Go to **Administration> System> Storage Service**.
3. Click **Add Service**
   ![Qalyptus Server System File Storage](/img/docs-images/Qalyptus-server-system-file-storage-services.png)
4. Enter the information in the following fields:

- **Name**: Enter the name of the service.
- **Description**: Enter a description for the service (optional).
- **Default**: Check this box to set this service as the default service.
- **Type**: Choose FTP or SFTP.
- **FTP server**: Hostname of your FTP server.
- **FTP username**: Username of the FTP user.
- **FTP password**: Password of the FTP user.
- **Passive Mode**: This option is available only for FTP. Check this box if you want to use passive mode.

5. Click **Test Connection** to verify access to the service.
6. Click **Save**.
