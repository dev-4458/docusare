---
title: Organizations
---

This feature brings a lot of flexibility to the management of your users and content in Qalyptus. You can create several organizations to separate the users and the content (Projects, reports, tasks, resources, Qlik Apps). Each organization will have its members, content, authentication types, and theme.

You can imagine different scenarios when you need to have several organizations.

- When you have different subsidiaries. Create an organization for each subsidiary; separate members, the content, and the theme (each subsidiary with his logo and colors). When a user of subsidiary A creates a task, he only can use the reports and the recipients in subsidiary A.
- When you manage apps and reports for Employees and Customers. Create two organizations; separate the content, the members, the authentication method (Example: LDAP authentication for employees and SAML authentication for customers)
- You are Qlik OEM or MSP (Managed Service Provider) Partner. Separate your customer’s content and apply your brand. You will offer an amazing experience to the users; they will find in one place their apps, mashups, reports, resources, subscription to reports, …etc.
- Many other scenarios can be imagined depending on your industry and the needs of your business.

![Qalyptus Server Organizations](/img/docs-images/qalyptus-server-organizations.png)

## Default Organization

Qalyptus Server installs with an organization named Default (and Display name: Qalyptus). If you maintain a single-organization environment on Qalyptus Server, this becomes the organization you work with. If you add organizations, the default organization becomes one of the organizations you can manage.

The default organization cannot be deleted.

:::note
Organizations feature is only available with Qalyptus Server Ultimate.
:::
