---
title: Identity Providers
---

In addition to authentication with Windows credentials and email/password, Qalyptus supports SAML 2 authentication using Identity Providers like Okta, Auth0, Azure AD, Ping Identity, …

Authentication with SAML is also available in our Qlik Sense extensions: Qalyptus On-demand and Qalyptus Self-Reporting.

You can configure one or more Identity Providers.

![Qalyptus SSO Identity Providers](/img/docs-images/qalyptus-sso-identity-providers.png)

## Configure an Identity Provider (IdP)

To configure your Identity Provider, do the following:

1. Connect to Qalyptus Server as an administrator
2. Go to Qalyptus Administration > System > Identity Providers
3. Click **Create Identity Provider**
4. Enter a Name
5. Enter a description (optional)
6. Check the option **Sign Auth Request** If you want to sign the Authentication request and if it’s supported by your IdP
7. Use the metadata file or the information below in your Identity Provider Settings.

- Assertion Consumer Service(ACS) URL
- Service Provider(SP) Entity ID
  The metadata file contains all the information about the Service Provider (Qalyptus).
  Qalyptus automatically retrieves the Identity Provider certificates.

8. Enter the Entity ID provided by your IdP (Issuer URL)
9. Enter Singl Sign-On URL (SSO URL) provided by your IdP
10. Enter the Button label. Example: Log in with Okta
11. Click **Save**

![Qalyptus Create IDP](/img/docs-images/qalyptus-create-idp.png)

If your IDP is Ping Identity, add the attribute **Email Address** with the value **email** in the Application settings.

![Ping Identity Attribute Mappings](/img/docs-images/Ping-Identity-Attribute-mappings.png)

## Use Identity Provider

An Identity provider must be added to an organization. Only the members (users) of the organization can use the specific Identity provider.

You can add more than one Identity provider to an organization. The member of the organization will see a Log in button for each Identity Provider.

If an organization uses only one Identity Provider, the user is automatically redirected to authenticate (the login button is not displayed).

### Login Page

![Qalyptus Server Login](/img/docs-images/qalyptus-saml-Qalyptus-Server-Login.png)

### Qalyptus On-Demand authentication settings

![Qalyptus On Demand Auth](/img/docs-images/qalyptus-on-demand-auth.png)
