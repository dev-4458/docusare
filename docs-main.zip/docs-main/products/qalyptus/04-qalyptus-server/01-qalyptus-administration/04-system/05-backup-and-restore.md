---
title: Backup and Restore
---

A Qalyptus Server administrator must perform regular database maintenance, monitor disk usage on the server, delete unnecessary files, and back up Qalyptus Server and its data. Through these steps, you ensure the maximum efficiency of Qalyptus Server.

Qalyptus Server includes a backup and restore feature that makes it easy for you to back up and restore the database.

The backup file will be stored on the same computer as your Qalyptus Server instance, here: C:\ProgramData\Qalyptus\QalyptusServer\export.

:::important
The restore must be done using a file created with the same version. Otherwise, the restore will fail. If you uninstall and reinstall Qalyptus, make sure to use database user (username and password) of the previous installation.
:::

## Create a backup

To create a backup, follow the steps below:

1. Connect to Qalyptus Server.
2. Go to **Administration> System> Backup and Restore**.
3. Click **Create backup**.

![Qalyptus Server System Backup Restore](/img/docs-images/Qalyptus-server-system-backup-restore.png)

4. Enter the information in the following fields:

- **Enable**: Choose whether to enable or disable the backup.
- **Name**: Enter a name for the backup.
- **Description**: Enter a description for the backup (optional).
- **Schedule**: Choose the backup mode: Manually or Automatically. If you choose Automatically, specify how often to start the backup.

5. Click **Save**.

## Restore the database

To restore the Qalyptus Server database, follow the steps below:

1. Connect to Qalyptus Server.
2. Go to Administration> System> Backup and Restore.
3. Click Restore.
4. Enter the path to the backup file. The file must be on the same computer as your Qalyptus Server instance and must be created with the same version of Qalyptus.
5. Click **Restore**.
