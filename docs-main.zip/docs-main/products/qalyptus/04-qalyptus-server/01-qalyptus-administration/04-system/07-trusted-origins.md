---
title: Trusted Origins
---

With Qalyptus Server API, you can do actions, like running tasks, from external web applications. For security reasons, you can choose the list of addresses allowed to make calls to your Qalyptus Server.

Example: If you want to use the Qalyptus On-Demand extension to generate your Qalyptus reports from Qlik Sense, you must add the address of your Qlik Sense server as an trusted origin.

## Add an origin

To add an allowed address, follow these steps:

1. Connect to Qalyptus Server.
2. Go to **Administration> System> Trusted Origins**.
3. Click **Add Origin**.

![Qalyptus Server System Trusted Origins](/img/docs-images/Qalyptus-server-system-trusted-origins.png)

4. Enter the information in the following fields:

- **Name**: Enter a name for the origin.
- **Description**: Enter a description for the origin (optional).
- **Address**: Enter the address to authorize.

5. Click **Save**.
