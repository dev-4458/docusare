---
title: SMTP Mail Server
---

Qalyptus Server can send emails to users to inform them of the availability of their reports. However, you must first configure the SMTP server that Qalyptus Server uses to send emails. To configure SMTP, follow the steps below :

1. Log in to Qalyptus Server as an administrator.
2. Go to **Administration> System> SMTP Mail Server**.
3. Click **Configure a new SMTP mail server**.

![Qalyptus Server SMTP](/img/docs-images/Qalyptus-server-smtp.png)

4. Fill in the following information:

- **Name**: Enter a name for your SMTP Mail Server.
- **Description (Optional)**: This is the description of the mail server.
- **From name**: Type the sender name that the SMTP server will use to send the messages.
- **From address**: Type the address that the SMTP server will use to send the messages.
- **Prefix for all e-mail subjects (optional)**: If you fill in this field, all the subjects of the emails that Qalyptus Server will send will be prefixed with the value of this field.
- **Host Name**: Enter the SMTP server address.
- **SMTP Port**: Enter the SMTP server port number.
- **SSL**: Check this box if your server uses SSL encryption.
- **Username**: Enter the username of the server.
- **Password**: Enter the password of the server.
- **Test Mail**: Enter an email that will allow you to test the connection to the SMTP server.

If the connection test failed:

- Make sure the SMTP server is reachable, and the port is open. Open the CMD and type this command: telnet [smtp-server] [port]. If an empty page appears, it means that the server is accessible and the port is open; otherwise, the server is not accessible, or the port is not open.
- Check the SMTP activity of the test email. The default log file path is: C:\ProgramData\Qalyptus\QalyptusServer\Log\[current-date]\SMTP activity
