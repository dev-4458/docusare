---
title: Security Roles
---

When you add users to Qalyptus Server, you must apply a role to them. Roles are the maximum level of access that a user can have on Qalyptus Server. With permissions, the role determines who can publish, edit, delete, or just view content, or who can manage users and administer.

When installing Qalyptus Server, three default roles are created: Administrators, Developers, and Users. You can see the permissions of these roles without being able to edit or delete them.

## Create a role

The content permissions determines the level of access a user has on Qalyptus Server. Permissions can be applied to all projects or specific projects.

:::note
A user can have multiple roles. In this case, his rights are the union of the permissions of his roles.
:::

To create a role, follow the steps below:

1. Connect to Qalyptus Server.
2. Go to **Administration> System> Security Roles**.
3. Click **Create Role**.
   ![Qalyptus Server System Roles](/img/docs-images/Qalyptus-server-system-roles.png)
4. Enter the information in the following fields:

- **Enable**: Choose to enable or disable the role.
- **Name**: Enter the role name.
- **Description**: Enter a description for the role (optional).
- **Permissions**: Choose role permissions.
  - For Projects (connections, filters and reports) and Tasks, it is possible to apply permissions on specific projects. Check the **“All projects”** checkbox to apply permissions to all projects present in Qalyptus Server. If you want to select specific projects, uncheck the box and select the projects of your choice

5. Click **Save**
