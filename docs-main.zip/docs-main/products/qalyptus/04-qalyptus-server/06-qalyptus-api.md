---
title: Qalyptus API
---

Sometimes you have use cases and requirements that we do not yet offer. Fortunately, it is possible to create your own applications and extend the functionality of Qalyptus.

The tools and APIs that Qalyptus provides developers can integrate, customize, automate and extend the functionality of Qalyptus to your specific business needs.

The Qalyptus API can be integrated into your internal applications or used in Qlik Sense extensions, for example.

Access the [Qalyptus REST API documentation](https://help.qalyptus.com/qalyptus-api/).
