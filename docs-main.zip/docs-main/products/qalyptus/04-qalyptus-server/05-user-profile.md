---
title: User Profile
---

In Qalyptus Server, your profile page lets you see information about your account and manage your credentials, and user interface options in one central place.

At the top of a page, click your profile image, and then select **Profile**. Then you will see the page below.

![Qalyptus Server User Profile](/img/docs-images/Qalyptus-server-user-profile.png)

On this page, you can make the following changes:

- Image of your profile: Click on the **Change** link and upload your image.
- Qalyptus Password: Click **Change password** and enter you current password and your new password, then click **Update**.
- The interface language: Select a language from the **Language** drop-down list.
- Subscription Time Zone: Select the time zone that will be used to run your report subscriptions.
