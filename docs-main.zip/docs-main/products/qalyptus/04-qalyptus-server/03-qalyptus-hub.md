---
title: Qalyptus Hub
---

Qalyptus Hub is a web portal that allows users to view, download and subscribe to reports generated with Qalyptus. You can also access your Qlik Sense applications if they are synchronized.

Qalyptus Hub is a part of Qalyptus Server. By connecting to Qalyptus Server, you will be automatically redirected to the Hub.

![Qalyptus server Hub](/img/docs-images/qalyptus-server-hub.png)

## Qalyptus Hub with a Custom theme

The design of Qalyptus Hub can be custom with your company brand.

![Qalyptus Hub Custom Theme](/img/docs-images/qalyptus-hub-custom-theme.png)

## The different tabs

### Home

On this page, you will find the 6 most recent reports that you have added to your favorites as well as the 6 most recent reports (recently added or recently viewed).

### Applications

This page contains all the synchronized Qlik Sense applications. As in Qlik Sense Hub, a user will see only the applications to which he is entitled.

### Reports

This page contains all the reports for which you have the right to consult.

### Favorites

This page contains all the reports that you have marked as favorites. To remove a report from this list, click the star button.

### Recents

This page contains all of your reports sorted by the date added and the date the report was viewed.

### Subscriptions

On this page, you will find the list of report subscriptions that you have created or that an administrator has created for you. You can edit a subscription to modify it. You can also unsubscribe to stop receiving the report.

### Resources

This page contains links to different resources created by the administrators. Example: PDF files in shared folders, link to files in SharePoint, …etc.

## Possible actions

### Preview a report

To preview a report, simply click on the name of the report you want to preview.

### Version history

Depending on the maximum number of occurrences defined when generating the report, it is possible to access previous versions of the report. To display all versions, click the **Action** menu corresponding to the report, then click **Version History**.

### Download a report

If you have the necessary rights, you can download a report by clicking on the **Action** menu corresponding to the report, then click on **Download**.

You can also download a report from the preview page by clicking on the **Download** button at the top right.

### Mark a report as a favorite

To make it easier to find your most-used reports, you can mark them as a favorite. To mark a report as a favorite, click the favorites star near the report name. To remove a report from favorites, click on the star you used to mark the favorite.

### Subscribe to a report

You can subscribe to reports in order to receive them by email at a frequency of your choice.

To create a subscription, follow these steps:

- Click the **Action** menu for the report you want to subscribe to.
- Click on **Subscribe**.
- A window appears.
- Select the report output **format** from the available formats.
- Enter a **Subject** for the email.
- Add a **message** if you wish.
- In **Schedule**, set the frequency for receiving the report. Choose to receive your report: hourly, daily, weekly, or monthly.
- **Time zone**: The time zone used is the one defined in your profile.
- Click on **Subscribe**.

### Delete a report

If you have the necessary rights, you can delete a report so that it is no longer visible in Qalyptus Hub. Deleting a report means deleting all occurrences of the report.

To delete a report, click the **Action** menu corresponding to the report you want to delete, then click **Delete**.
