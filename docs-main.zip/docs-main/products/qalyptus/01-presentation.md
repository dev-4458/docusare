---
title: Presentation
id: presentation
---

**Qalyptus** is designed to help you create reports from Qlik platforms. With Qalyptus you can create custom reports using charts, tables and variables. Qalyptus let you generate reports in different formats and distribute them to an unlimited number of users.

Qalyptus is designed to simplify generating your reports that are based on templates designed by you. The Qalyptus platform is composed of two tools:

Qalyptus Desktop: that allow you design templates and create reports

Qalyptus Server: Allow you schedule, generate and distribute reports.

# Main features

Below are the main features of Qalyptus. Other features will be available soon.

- Microsoft Office reporting
- Reports from multiple QlikView documents and Qlik Sense applications
- Export reports as PDF, Excel, Word, PowerPoint, Html, Csv, Tiff, Xps, Pps
- Dynamic Report Naming
- Iteration reports (creates report for every value of dimensions)
- Save reports in folders (static or dynamic path) and in File Storage Services (FTP, Dropbox, OneDrive, Google Drive, …)
- Send reports by email
- On-demand generation of reports from Qlik Sense
- Generate reports with Conditions
- Advanced management of permissions
- Duplicate templates, reports and tasks
- Filter with Field values
- Filter with Variables
- Filter with Bookmarks
- Load existing template
- Task failure notifications
- Multi languages
- Logs
