---
title: System requirements for Qalyptus
---

## Qalyptus Desktop

The values below refer to the minimum available hardware and software required to run Qalyptus Desktop.

- Supported Operating Systems (32-bit and 64-bit): Windows 11 and Windows 10
- Minimum RAM requirements: 1 GB
- Minimum Disk space: 300 MB
- Microsoft Office (32-bit or 64-bit): 2007, 2010, 2013, 2016, 2019, 2021, and Office 365 (installed versions only)
- .NET framework 4.7.2 or higher
- Display settings of all monitors: Size of text and apps: 100%, Max Display resolution: 1920×1080
- No internet connection is necessary
- Qalyptus can be installed on the same machine as Qlik Sense / QlikView or on a separate machine

For Qlik Sense

- Qlik Sense supported editions: Qlik Sense Enterprise client-managed and Qlik Sense Desktop
- Open Inbound Port 4747 where the Qlik Sense Engine service is installed
- Open Inbound Ports: 4242 and 4243 where the Qlik Sense Repository and Qlik Sense Proxy services are installed
- Install Qlik Sense Certificates if Qalyptus is installed on a different machine than Qlik Sense or if Qalyptus is installed on the same machine as Qlik Sense but the Qlik Sense services user is different from the Qalyptus user.
- Qalyptus Desktop can be installed on the same domain as Qlik Sense or a different domain.

For QlikView

- QlikView 11 or QlikView 12 installed
- Qalyptus and QlikView must be installed in the same machine
- QlikView Desktop must have an active local license or a Named User CAL from QlikView Server
- QlikView Desktop Personal Edition (free version) not supported

## Qalyptus Server

The values below refer to the minimum available hardware and software required to run Qalyptus Server.

- Supported Operating Systems (64-bit): Microsoft Windows Server 2012 or higher
- Minimum RAM requirements: 2 GB
  Minimum Disk space: 500 MB
- .NET Framework 4.7.2 or higher
- On the machine where Qalyptus Server is installed, open Inbound Port 3994 (default port of Qalyptus Server Service, can be changed)
- No internet connection is necessary
- Qalyptus can be installed on the same machine as Qlik Sense / QlikView or on a separate machine

For Qlik Sense

- Qlik Sense supported editions: Qlik Sense Enterprise client-managed and Qlik Sense Desktop
- Open Inbound Port 4747 where the Qlik Sense Engine service is installed
- Open Inbound Ports: 4242 and 4243 where the Qlik Sense Repository and Qlik Sense Proxy services are installed
- Install Qlik Sense Certificates if Qalyptus is installed on a different machine than Qlik Sense or if Qalyptus is installed on the same machine as Qlik Sense but the Qlik Sense services user is different from the user of Qalyptus Server service.
- Qalyptus Desktop can be installed on the same domain as Qlik Sense or a different domain.

For QlikView

- QlikView 11 or QlikView 12 installed
- Qalyptus and QlikView must be installed in the same machine
- QlikView Desktop must have an active local license or a Named User CAL from QlikView Server
- QlikView Desktop Personal Edition (free version) not supported
