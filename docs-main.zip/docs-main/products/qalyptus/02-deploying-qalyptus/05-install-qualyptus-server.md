---
title: Install Qalyptus Server
---

Installing Qalyptus Server is necessary to schedule the generation and distribution of reports to folders or users by email.

<iframe width="560" height="315" src="https://www.youtube.com/embed/rJvC8OzU3ww" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

To install Qalyptus Server, follow these steps:

1. Download Qalyptus Server on qalyptus.com.
2. Locate the installation file.
3. Launch the installer.
4. On the **Select Setup Language** screen, choose a language and click **Next**.
5. Accept the terms of the license agreement and click **Next**.
6. Choose the installation directory and click **Next**.
7. On the **Ready to Install** screen, click **Install**.
8. On the final installation screen, leave the **Launch Qalyptus Server** checkbox selected, and then click **Finish** to configure Qalyptus Server before first use.
9. **Qalyptus Server Configuration** starts.
   ![Qalyptus Server Configuration General](/img/docs-images/Qalyptus-server-configuration-general.png)
10. Qalyptus Server need to run with a user who must be a **local administrator**. Enter the Domain and the user name in this format: Domain\UserName and its password.
11. The default port number for Qalyptus Server is 3994. You can choose another port number as long as it is not already in use by another program.
12. Qalyptus Server supports http and https protocols. To use Qalyptus Server with https you must install a valid SSL certificate before enabling the https option.
13. Click **Next** to continue.
14. After the first screen data is validated, the **Database Configuration** screen appears.
    ![Qalyptus Server Configuration Database Configuration](/img/docs-images/Qalyptus-server-configuration-database-configuration.png)
15. The port number of the Qalyptus Server database is 4048. You can choose another port number as long as it is not already in use by another program.
16. Enter a username and password of your choice to create a database user required to run your Qalyptus Server instance.
17. Click **Next**.
18. The **Certificates of Qlik Sense** screen appears.
    ![Qalyptus Server Configuration Qlik Sense Certificates](/img/docs-images/Qalyptus-server-configuration-qlik-sense-certificates.png)
19. If you want to install the Qlik Sense certificates, check the box **I want to install Qlik Sense certificates**. Otherwise click **Next**.
20. Specify the file path: client.pfx, server.pfx, root.cer. To export these three certificate files, follow the instructions in this Qlik Sense help page. Important: When exporting certificates, **leave the password field blank**.
21. Click **Install Certificates**.
22. The **Ready for installation** screen appears.
    ![Qalyptus Server Configuration Ready To Install](/img/docs-images/Qalyptus-server-configuration-ready-to-install.png)
23. Click **Install** to install and start the Qalyptus Server services.
24. When the installation is complete, the congratulations screen appears.
    ![Qalyptus Server Configuration Congratulations](/img/docs-images/Qalyptus-server-configuration-congratulations.png)
25. Click **Open Qalyptus Server** to start using Qalyptus Server.
26. Qalyptus Server opens with your default browser on the page below. The first step is to activate Qalyptus Server with a license or start a 30-day trial period.

    ![Qalyptus Server Startup License](/img/docs-images/Qalyptus-server-startup-license.png)

27. Once the license is activated, go to the next step.
    ![Qalyptus Server Startup Register](/img/docs-images/Qalyptus-server-startup-register.png)
28. Enter the information of the first Qalyptus Server user and administrator. These coordinates will allow you to connect to Qalyptus Server. **To log in with Windows Authentication, complete your Domain Account (Domain \ UserName)**.
29. Click **Next**.
30. An **Install** screen is displayed.
31. Click the **Install** button.
32. Once the installation is complete, you will be redirected to the login screen.
    ![Qalyptus Server Login Form](/img/docs-images/Qalyptus-server-login-form.png)
33. On the machine where Qalyptus Server is installed, open **Inbound Port** 3994 for Qalyptus Server service. If you change those default ports in the configuration process, open the ports you have chosen.
34. Open **Inbound Ports** 4747 where the Qlik Sense Engine service is installed and ports: 4242 and 4243 where the Qlik Sense Repository and Qlik Sense Proxy services are installed.
