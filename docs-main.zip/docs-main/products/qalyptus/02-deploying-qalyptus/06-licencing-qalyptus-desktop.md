---
title: Licensing Qalyptus Desktop
---

You can view and manage your Qalyptus Desktop license on the **License** tab in **Settings** page. You may need to add or update your license if you:

- Add a new license for a newly installed Qalyptus Desktop instance.
- Add a new license when your old license has expired.

## Add a new license

To apply your license before it expires, do the following:

1. Obtain the license key you want to update (you can do this by visiting [my-account](https://my.qalyptus.com/my-account/licenses/)).
2. In Qalyptus Desktop, open Settings page and Choose > **License**.
3. The page below appears.
4. In the **License key** text area, paste your license key.
5. Click the **Apply** button to update the Qalyptus Desktop with the new license.

You will now see the new expiration date of the license.

![Qalyptus License Activation](/img/docs-images/qalyptus-license-activation.png)

If your license has expired, when Qalyptus Desktop is launched, a window appears. Click the **Ok** Button, then enter your license key and click **Apply**.

![Qalyptus License Activation 2](/img/docs-images/qalyptus-license-activation-2.png)
