---
title: Install Qalyptus Desktop
---

Install Qalyptus Desktop on computers of users that will create Qalyptus projects: connections, templates, reports, and tasks.

To install Qalyptus Desktop, do the following:

1. Download Qalyptus Desktop from [qalyptus.com](https://www.qalyptus.com/).
2. Locate the installation file.
3. Run the installer.
4. On the **Select Setup Language** screen, choose a language and click Next.
5. Accept the terms in the license agreement and click **Next**.
6. Choose the Destination Folder and click **Next**.
7. On the **Ready to Install** screen, click **Install**.
8. If you want to launch Qalyptus Desktop, let the checkbox **Launch Qalyptus Desktop** checked, and click **Finish**.

## Install and set up your environment to use Qalyptus Desktop with Qlik Sense Enterprise

If you want to use Qalyptus with Qlik Sense Server, you must make certain configurations to allow Qalyptus to connect to your Qlik Sense Server. The video below explains how to do it.

<iframe width="560" height="315" src="https://www.youtube.com/embed/DqlcseUypNY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
