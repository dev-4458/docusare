---
title: Supported languages
---

Qalyptus user interface support the following languages:

- English
- French

The following languages will be added soon : German, Spanish, Portuguese and Italian.

When you change the language, the interface changes language instantly . You don’t need to restart Qalyptus.
