---
title: Generate a license key
---

The Qalyptus Desktop license key is linked to the Windows username of the user who uses Qalyptus Desktop. A Qalyptus Desktop license is assigned to a single Windows user name. Your license will be valid on all PCs as long as you log in with your Windows account.

The Qalyptus Server license key is linked to the ID of the machine where Qalyptus Server is installed. If you want to install Qalyptus Server in a test environment, read the section “Non-production License”.

## Generate a new license

Once your order is completed, go to the [Licences](https://my.qalyptus.com/my-account/licenses) page to generate a license key for each product.

On this page you will find the list of licenses you have purchased. Example: if you buy 3 Qalyptus Desktop licenses, you will see 3 lines corresponding to the 3 licenses with a different Support Entitlement Number (SEN).

![Licenses List](/img/docs-images/licenses-list.jpg)

To generate a new license, do the following:

1. In the license page, click **New license** link
2. A new page will open. Enter the license user full name and email and the Username or Server ID.

- For Qalyptus Desktop, the Username is the user Windows account (Domain\Username). To find it, open Qalyptus Desktop and go to: **Settings > License**
  ![License Activation](/img/docs-images/qalyptus-license-activation.png)
- For Qalyptus Server, the Server ID is the ID of the machine where Qalyptus is installed. To find it, open Qalyptus Server and go to: **Qalyptus Administration> License**
  ![Server License Screen](/img/docs-images/qalyptus-server-license-screen.png)

3. Click **Save**
4. If all its OK, a new license will be created and the user specified will receive the license key by email
5. You will see the license key in place of the link **New license**.

Now the license can be used to [activate the Qalyptus](/products/qalyptus/deploying-qalyptus/licencing-qalyptus-desktop) instance of the specified user.

:::note
Note that the expiration date of the license is calculated from the date of purchase of the license.
:::

## Renew an existing license

You can renew all or a part of your existing licenses any time. We recommend that you renew your licenses sufficiently before the expiration date to avoid any break in use.

To renew an existing license, go to the [Licences](https://my.qalyptus.com/my-account/licenses) page and do the following:

1. Copy the license key you want to renew
2. Click **Renew a license** link
3. A new page will open. Paste the license key and click **Save**
4. If all its OK, a new license will be created and the owner of the license will receive the license key by email
5. You will see the license key in place of the link **Renew a license**.

Note that the expiry date of the new license will be one year longer than the old license.

## Non-Production License (License for test environment)

The Qalyptus Server license allows up to three activations of the same key: one production environment and two non-production environments, as defined in the End User License Agreement. After installing Qalyptus Server on a non-production machine, send us the Qalyptus Server license key of the production environment with the Server ID (of the non-production machine) and we will send you a license key.
