---
title: Licensing Qalyptus Server
---

To view and manage your Qalyptus Server license go to the **License** tab in Administration > System. You may need to add or update your license if you:

- Add a new license for a newly installed Qalyptus Server instance.
- Add a new license when your old license has expired.

## Add a new license

To apply your license before it expires, do the following:

1. Obtain a license key from your account (you can do this by visiting [my-account](https://my.qalyptus.com/my-account/licenses/)).
2. In Qalyptus Server, go to **Administration > System** and Choose > **License**.
3. In the **License key** text area, paste your license key.
4. Click the **Activate** button to update the Qalyptus Server with the new license.

You will now see the new expiration date of the license.
![Qalyptus Server License Screen](/img/docs-images/qalyptus-server-license-screen.png)
