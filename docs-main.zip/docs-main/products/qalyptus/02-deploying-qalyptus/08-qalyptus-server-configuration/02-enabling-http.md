---
title: Enabling HTTP
---

In a default installation of Qalyptus Server, a self-signed certificate is generated and used. You can use Qalyptus Server with HTTP, although this is not recommended.

To enable HTTP, after installing Qalyptus Server, follow these steps:

1. Connect to the machine where Qalyptus Server is installed with the user who runs the **Qalyptus Server** service
2. In the start menu, search **Qalyptus Server Configuration**
3. Click on Qalyptus Server Configuration and go to the **General** tab
4. Enter the username and password of the user who runs the Qalyptus Server service
5. Uncheck the **Use https** box
6. Click on **Save**
7. A confirmation message will be displayed when the changes are taken into account

:::note
Note that once you have chosen to use HTTP, the address of Qalyptus Server with HTTPS will no longer work.
:::

:::note
If Qlik Sense Server is configured to use the HTTPS protocol, using an HTTP protocol to connect Qalyptus can cause a connection problem between Qlik Sense and Qalyptus, especially when you use the extensions Qalyptus Notify and Qalyptus On-Demand .
:::
