---
title: Change the port of the database
---

The default port number of the Qalyptus Server database is **4048**. You can modify the Port number of Qalyptus Server at any time with the number of your choice provided that it is not in use by another application.

To change the database port, follow the steps below:

1. Connect to the machine where Qalyptus Server is installed with the user who runs the **Qalyptus Server** service
2. In the start menu, search **Qalyptus Server Configuration**
3. Click on **Qalyptus Server Configuration** and go to the **Database Settings** tab
4. Enter the new port number in the **Port** field
5. Click on **Save**
6. A confirmation message will be displayed when the port number is changed

:::note
If you have set up ODBC connections with the Qalyptus Server database, remember to modify the Port so that they can continue working.
:::
