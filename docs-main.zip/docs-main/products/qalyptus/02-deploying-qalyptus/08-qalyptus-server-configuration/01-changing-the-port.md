---
title: Change the port of Qalyptus Server
---

The default port of Qalyptus Server is: **3994**. You can change the port number during the installation of Qalyptus or after installation.

To change the port after installing Qalyptus Server, follow the following steps:

1. Connect to the machine where Qalyptus Server is installed with the user who runs the **Qalyptus Server** service
2. In the start menu, search **Qalyptus Server Configuration**
3. Click on **Qalyptus Server Configuration** and go to the **General** tab
4. Enter the username and password of the user who runs the Qalyptus Server service
5. Change the port number. Use a port number not reserved by another application
6. If you are using a certificate other than the self-signed Qalyptus certificate, enter the fingerprint of the certificate you are using in the **Certificate** field
7. Click on **Save**
8. A confirmation message will be displayed when the port number is changed

:::note
Note that once you have changed the port number, the address of Qalyptus Server with the old port number will no longer work.
:::
