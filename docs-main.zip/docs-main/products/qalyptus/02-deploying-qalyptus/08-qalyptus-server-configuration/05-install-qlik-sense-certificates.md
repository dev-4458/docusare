---
title: Install Qlik Sense certificates
---

To use Qalyptus with Qlik Sense, you must have the Qlik Sense certificates installed on the machine where Qalyptus is installed. there are two cases.

## 1- Qalyptus is installed on the same machine as Qlik Sense

If Qalyptus is installed on the same machine as Qlik Sense **you should not install Qlik Sense certificates** because the certificates are already installed.

:::note
Installing Qlik Sense certificates in this case will cause Qlik Sense to malfunction. To resolve this issue, [follow the instructions in this article](https://community.qalyptus.com/t/problem-after-installing-certificates-on-the-machine-where-qlik-sense-is-installed/122).
:::

## 2- Qalyptus is installed on a separate machine from Qlik Sense

In this case the **installation of Qlik Sense certificates is mandatory** so that Qalyptus can communicate with Qlik Sense. Two main steps are necessary to install Qlik Sense certificates.

## Export Qlik Sense certificates via QMC

Follow the steps below to export the certificates:

1. Connect to the Qlik Sense **QMC**
2. Select **Certificates** on the QMC start page
3. The export certificate page is displayed
4. Click on **Add machine name** to add a new box
5. In the **Machine name** box, type the full name of the computer where Qalyptus is installed: machineName.domain.com or the IP address
6. Leave the **Certificate password** and **Retype password** fields empty
7. Check the **Include secret key** checkbox
8. Click on **Export certificates**

When the export is complete, the following message appears: **Certificates exported**.

The certificates will be exported to a disk location and the path is displayed. In the folder, the following certificates are created: client.pfx, root.cer, server.pfx. If the export fails, the following message is displayed: **Certificates export could not complete**.

## Install certificates via Qalyptus Server Configuration

To install Qlik Sense certificates with Qalyptus Server Configuration, follow the following steps:

1. Connect to the machine where Qalyptus Server is installed with the user who runs the **Qalyptus Server** service
2. In the start menu, search **Qalyptus Server Configuration**
3. Click on **Qalyptus Server Configuration** and go to the **Qlik Sense Certificates** tab
4. Specify the path to the previously exported files: client.pfx, server.pfx, root.cer
5. Click the **Install Certificates** button
6. If old certificates are already installed, a dialog box appears asking for confirmation to delete them and replace them with the new certificates
7. After installation, a confirmation message is displayed

You can now use Qalyptus with Qlik Sense to generate your reports.
