---
title: Change the certificate used by Qalyptus Server to a third-party certificate
sidebar_label: Use third-party certificate
---

By default, a self-signed certificate is used to secure communication with Qalyptus Server. This results in a warning in the client’s web browser such as “The site security certificate is not trusted”. To resolve this issue, the certificate used Qalyptus must be replaced by a certificate signed by a trusted certificate authority (CA).

:::note
The existing self-signed certificate is secure. The warning message is displayed because the web browser does not have all the information necessary to consider that the certificate is valid. Follow the steps below to remove the warning in the client web browser.
:::

## Import certificate

Follow the steps below to import the certificate:

1. Launch the **MMC** console on the machine where Qalyptus Server is installed
2. In the **MMC**, Open **File> Add / Remove Snap-in** …
3. Select Certificates and click **Add**
4. Select **Computer Account**, click **Next**, select **Local computer** and click **Finish**
5. In the **MMC** console, open **Certificates (local computer) / Personal**
6. In the **MMC** console, open **Actions> All Tasks> Import …**
7. Browse to the certificate file provided by your certification authority
8. Follow the on-screen instructions to import the certificate, including the private key
9. Check that the new certificate has been imported into **Certificates (local computer)> Personal> Certificates** and that it contains a private key
10. Double-click on the **Certificate> Certification path** and confirm that it displays **“This certificate is OK“**

## Use the certificate in Qalyptus Server Configuration

Follow the steps below to configure Qalyptus with your certificate.

1. In the **MMC** console, right-click the imported certificate and select **Open**
2. In the **Details** tab, scroll down and select **Thumbprint**
3. Select and copy its value to the clipboard with the keyboard shortcut CTRL + C
4. Close the **MMC** console
5. In the start menu of your computer, search **Qalyptus Server Configuration**
6. Click on **Qalyptus Server Configuration** and go to the **General** tab
7. Enter the username and password of the user who runs the Qalyptus Server service
8. Check the **Use https** checkbox
9. Then choose **Other valid SSL certificate**
10. Paste your certificate’s Thumbprint in the **Certificate** field
11. Make sure that the address entered in the **Machine address** field is the one that will be used to connect to Qalyptus Server
12. Click on **Save**
13. A confirmation message will appear when your certificate is taken into account by Qalyptus

You should now be able to access Qalyptus Server over HTTPS without the browser warning message.
