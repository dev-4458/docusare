const lightCodeTheme = require("prism-react-renderer/themes/github");
const darkCodeTheme = require("prism-react-renderer/themes/dracula");

/** @type {import('@docusaurus/types').Config} */
const config = {
	title: "Qalyptus Help",
	tagline: "Read the documentation for the qalyptus.com website",
	url: "https://help.qalyptus.com/",
	baseUrl: "/",
	onBrokenLinks: "throw",
	onBrokenMarkdownLinks: "warn",
	favicon: "img/favicon.ico",
	organizationName: "qalyptus",
	projectName: "qalyptus-documentation",
	i18n: {
		defaultLocale: "en",
		locales: ["en", "fr"],
	},

	presets: [
		[
			"classic",
			{
				docs: {
					sidebarPath: require.resolve("./sidebars.js"),
					path: "products/qalyptus",
					routeBasePath: 'products/qalyptus',
				},
				blog: false,
				theme: {
					customCss: require.resolve("./src/css/custom.css"),
				},
			},
		],
	],

	themeConfig: {
		navbar: {
			logo: {
				alt: "Qalyptus Help Doc",
				src: "img/qalyptus-help.png",
			},
			items: [
				{
					type: "doc",
					docId: "presentation",
					position: "left",
					label: "Qalyptus Self-hosted",
				},
				{
					type: 'html',
					position: "right",
					value: '<div id="autocomplete"></div>',
				},
				{
					type: "localeDropdown",
					position: "right",
				},
			],
		},
		footer: {
			style: "dark",
			copyright: `Copyright © 2017 -  ${new Date().getFullYear()} Scotfy. All rights reserved.`,
			links: [
				{
					label: "Qalyptus.com",
					href: "https://www.qalyptus.com/",
				},
				{
					label: "Privacy Policy",
					href: "https://www.qalyptus.com/privacy-policy",
				},
				{
					label: "License Terms",
					href: "https://files.qalyptus.com/eula/qalyptus_eula_en.pdf",
				},
				{
					label: "About Us",
					href: "https://www.qalyptus.com/about",
				},
				{
					label: "Contact",
					href: "https://www.qalyptus.com/contact",
				},
			],
		},
		docs: {
			sidebar: {
				autoCollapseCategories: true,
			},
		},
		prism: {
			theme: lightCodeTheme,
			darkTheme: darkCodeTheme,
		},
	},
	scripts: [
	{
		src: 'https://cdn.jsdelivr.net/npm/@algolia/autocomplete-js',
		async: true,
    },
	{
	src: 'https://cdn.jsdelivr.net/npm/@algolia/autocomplete-plugin-query-suggestions',
	async: true,
    },
	{
	src: 'https://cdn.jsdelivr.net/npm/@algolia/autocomplete-plugin-recent-searches',
	async: true,
    },
	{
src: 'https://cdn.jsdelivr.net/npm/algoliasearch@4.9.1/dist/algoliasearch-lite.umd.js',
async: true,
    },
	{
		src: './js/algolia-init.js'
	}
	],
	stylesheets: [
    {
		href: 'https://cdn.jsdelivr.net/npm/@algolia/autocomplete-theme-classic',
        type: 'text/css',
		crossorigin: 'anonymous',
    },
	],
};

module.exports = config;
