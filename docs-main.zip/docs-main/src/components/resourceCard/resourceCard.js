import React from "react";
import styles from "./resourceCard.module.css";

const ResourceCard = props => {
	return (
		<a className={styles.resourceCard} href={props.link}>
			<h1>{props.title}</h1>
			<p>{props.description}</p>
		</a>
	);
};

export default ResourceCard;
