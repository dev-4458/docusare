import React from "react";
import clsx from "clsx";
import Link from "@docusaurus/Link";
import useDocusaurusContext from "@docusaurus/useDocusaurusContext";
import Layout from "@theme/Layout";
import ResourceCard from "../components/resourceCard/resourceCard";

import styles from "./index.module.css";
import Translate, { translate } from "@docusaurus/Translate";

function HomepageHeader() {
	const { siteConfig } = useDocusaurusContext();
	return (
		<header className={clsx("hero hero--primary", styles.heroBanner)}>
			<div className="container">
				<h1 className="hero__title">{siteConfig.title}</h1>
				<p className="hero__subtitle">
					<Translate id="homepage.tagline">
						Read the documentation for the qalyptus.com website
					</Translate>
				</p>
				<div className={styles.buttons}>
					<Link
						className="button button--secondary button--lg" to="/products/qalyptus/presentation">
						<Translate id="homepage.buttonGetStarted">Get Started</Translate>
					</Link>
				</div>
			</div>
		</header>
	);
}

export default function Home() {
	const { siteConfig } = useDocusaurusContext();
	return (
		<Layout title={`${siteConfig.title}`}>
			<HomepageHeader />
			<main>
				<h1 className={styles.resourcesTitle}>
					<Translate id="homepage.browseResources">Browse Resources</Translate>
				</h1>
				<div className={styles.resourceCardsWrapper}>
					<ResourceCard
						title={translate({
							message: "📃 Documentation",
							description: "The documentation link title on the landing page",
						})}
						description={translate({
							message:
								"Get familiar with Qalyptus by reading our documentation.",
							description:
								"The documentation link description on the landing page",
						})}
						link="products/qalyptus/presentation"
					/>
					<ResourceCard
						title={translate({
							message: "🗨️ Community",
							description: "The community link title on the landing page",
						})}
						description={translate({
							message:
								"Find answers, support, and inspiration from other Qalyptus users.",
							description: "The community link description on the landing page",
						})}
						link="https://community.qalyptus.com/"
					/>
					<ResourceCard
						title={translate({
							message: "💳 Billing & Licensing",
							description: "The billing link title on the landing page",
						})}
						description={translate({
							message: "See FAQs about billing and licensing on our website",
							description: "The billing link description on the landing page",
						})}
						link="https://www.qalyptus.com/products/billing-licensing"
					/>
				</div>
			</main>
		</Layout>
	);
}
