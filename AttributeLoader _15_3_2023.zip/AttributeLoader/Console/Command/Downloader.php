<?php

namespace Custom\AttributeLoader\Console\Command;

use Custom\AttributeLoader\Helper\Data;
use Exception;
use Laminas\Log\Logger;
use Laminas\Log\Writer\Stream;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as Product_Model;
use Magento\Catalog\Model\ResourceModel\Attribute;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Console\Cli;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\App\Area;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Store\Model\StoreManagerInterface as StoreManagerInterface;
use Psr\Log\LoggerInterface as LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as Magento_CollectionFactory;
use Magento\Catalog\Api\Data\ProductInterface;
use Webprojectsol\DaneaEasyFatt\Model\ResourceModel\ImportCatalog\Collection as WebImportCatalogCollection;
use Webprojectsol\DaneaEasyFatt\Model\Dir as DaneaEasyFattDir;
use Symfony\Component\Console\Input\InputArgument;

class Downloader extends Command
{
    const AREA_CODE_LOCK_FILE = 'custom_attribute_areacode.lock';
    const STORE_ARGUMENT = 'sku';
    /**
     * @var ProductAttributeRepositoryInterface
     */
    protected $productAttributeRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var Attribute
     */
    protected $attributeResource;

    /**
     * @var State
     */
    protected $appState;

    /**
     * @var \Magento\Framework\EntityManager\EntityMetadata
     */
    protected $metadata;

    /**
     * @var State
     */
    protected $state;

    /**
     * @var StoreManagerInterface
     */
    protected $storeInterface;

    /**
     * @var DirectoryList
     */
    protected $directoryList;

    /**
     * @var LoggerInterface
     */
    protected $logger;
    private $productRepository;
    private $productCollection;
    private $productCollectionFactory;
    private $totalExecutionTime;
    private $startTime;
    private $filesystem;
    private $helper;
    private $perProductTotalExecutionTime;
    private $perProductStartTime;
    private $webImportCatalogCollection;
    private $daneaEasyFattDir;


    public function __construct(
        State                      $appState,
        StoreManagerInterface      $storeInterface,
        DirectoryList              $directoryList,
        LoggerInterface            $logger,
        Magento_CollectionFactory  $productCollectionFactory,
        ProductRepositoryInterface $productRepository,
        Filesystem                 $filesystem,
        Data                       $helper,
        WebImportCatalogCollection $webImportCatalogCollection,
        DaneaEasyFattDir           $daneaEasyFattDir
    )
    {
        $this->appState = $appState;
        $this->storeInterface = $storeInterface;
        $this->directoryList = $directoryList;
        $this->logger = $logger;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productRepository = $productRepository;
        $this->filesystem = $filesystem;
        $this->helper = $helper;
        $this->webImportCatalogCollection = $webImportCatalogCollection;
        $this->daneaEasyFattDir = $daneaEasyFattDir;
        parent::__construct();
    }

    /**
     * Initialization of the command.
     */
    protected function configure()
    {
        $this->setName('custom:mediadownloader:sku');
        $this->setDescription('For given skus it will download images.');
        $this->setDefinition([
            new InputArgument(
                self::STORE_ARGUMENT,
                InputArgument::OPTIONAL,
                'The sku (comma separated) to download images using file_get_contents and put in media folder.'
            )
        ]);
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int
     * @throws LocalizedException
     * @throws FileSystemException
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $skus ='';
        $output->setDecorated(true);
        if (!$this->helper->isEnabled()) {
            $output->writeln(__(
                sprintf(' Module is disabled from backend')
            )->getText());
            return Cli::RETURN_SUCCESS;
        }
        $this->startTime = microtime(true);
        $logDir = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $storeLockFile = $putStatus= '';
        $areaCodeFile = $logDir . "/" . self::AREA_CODE_LOCK_FILE;
        try {
            if (file_exists($areaCodeFile)) {
                unlink($areaCodeFile);
            }
            $this->appState->setAreaCode(Area::AREA_FRONTEND);
        } catch (LocalizedException $e) {
            fopen($areaCodeFile, 'w');
            if ($this->appState->getAreaCode() != Area::AREA_FRONTEND) {
                $output->writeln(__(
                    sprintf('  Running in an unexpected state AreaCode : (%s)', $this->appState->getAreaCode())
                )->getText());
            }
        }

        $importsCatalog = $this->webImportCatalogCollection->addFieldToSelect('filename')
            ->addFieldToFilter(['status','status'], [
                ['eq' => \Webprojectsol\DaneaEasyFatt\Model\ImportCatalog::STATUS_SUCCESS],
                ['eq' => \Webprojectsol\DaneaEasyFatt\Model\ImportCatalog::STATUS_STOPPED],
               ])
            ->setOrder('date','DESC')
            ->getData();
        $skus = $input->getArgument(self::STORE_ARGUMENT);
        if (empty($importsCatalog) && !$skus) {
            $output->writeln('both are pending');
            return Cli::RETURN_SUCCESS;
        }
        $products_to_update=[];
        $filesToImport = null;
        foreach ($importsCatalog as $keyV => $importModel) {
            if($keyV > 3) {
                continue;
            }
            //if($keyV!==0){continue;}
            $filesToImport[]= $this->daneaEasyFattDir->dirImportExport().trim($importModel['filename']) . '_ProgressVideoUpload.txt';
        }
        $output->writeln($filesToImport);
        
        $fileExitsFlag = true;
        foreach($filesToImport as $fileToImport) {
            if(!file_exists($fileToImport) && !$skus) {
                $output->writeln('ProgressVideoUploadFile is not exists:'. $fileToImport);
                $this->log('ProgressVideoUploadFile is not exists: '. $fileToImport);
                
                $fileExitsFlag = false;
                continue;
            }
            
            if($fileToImport && file_get_contents($fileToImport)) {
                $fileData = file_get_contents($fileToImport);
                $idsDecodeList =\Webprojectsol\DaneaEasyFatt\Helper\Data::_JsonDecode($fileData, true);
                //Skipping if file has just blank array
                if([] == $idsDecodeList) {
                    continue;
                }
                $products_to_update = $idsDecodeList ;
                $fileExitsFlag = true;
            }
        }
        
        
        $this->log(print_r($products_to_update,true));
        
        if(!is_array($products_to_update)) {
            $output->writeln('Array expected, format invalid found');
            return Cli::RETURN_SUCCESS;
        }
        
        try {
            $output->writeln("=== Starting downloading media images process ===");
            $output->writeln('');

            $collection = $this->productCollectionFactory->create();
            $mediaAttribute = $this->helper->getSelectedAttributeCode();
            $collection->addAttributeToSelect(
                ['id', 'sku', $mediaAttribute,'da_media_image_filename','da_media_link']
            );

            $collection->addAttributeToFilter(
                'sku',['in'=> [$products_to_update]]
            );
            
            $collection->setFlag('has_stock_status_filter', false);
            
            //$output->writeln($collection->getSelect()->__toString());
            
            $proCount = count($collection);
            $progress = new ProgressBar($output,$proCount);
            $progress->setFormat('<comment>%message%</comment> %current%/%max% [%bar%] %percent:3s%% %elapsed%');
            
            // would be : /home/dzouvxeo/public_html/pub/media/import
            $mediaPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath().'import';
            
            foreach ($collection as $productKey => $product) {
                $this->perProductStartTime = microtime(true);
                if (!$product instanceof Product_Model) {
                    $this->log('Product not found valid.' . $product->getId());
                    continue;
                }
                $proLabel = 'Id: ' . $product->getId() . ' || SKU: ' . $product->getSku();
                $mediaFileImgOrVideoAttributeValue = $product->getDataUsingMethod($mediaAttribute);
                if (!$mediaFileImgOrVideoAttributeValue) {
                    $this->log('Product value "(' . $mediaFileImgOrVideoAttributeValue . ')" found empty or invalid for given product: ' . $proLabel);
                    continue;
                }
                
                $producerAsImages = explode (";", $mediaFileImgOrVideoAttributeValue);
                if (!$producerAsImages) {
                    continue;
                }
                
                $gallery = $product->getMediaGalleryImages();
                if ($gallery) {
                    foreach($gallery as $key =>  $image) {
                        //$logger->info(print_r($image->getData(),true));
                        if($image && $image->getData('value_id')!= ''){
                            //$this->productGallery->deleteGallery($image->getData('value_id'));    
                        }
                        //unset($gallery[$key]);
                    }
                    $this->log('Gallery removed');
                    $product->setMediaGalleryEntries([]);
                    try{
                      $product->save();
                    }catch(\Exception $e){
                        $logger->info($e->getMessage());
                    }
                }
                foreach($producerAsImages as $pKey => $pImgURL) {
                    if (!$pImgURL || filter_var($pImgURL, FILTER_VALIDATE_URL) === FALSE) {
                        $output->writeln("Media found empty or invalid for given  " . $proLabel. ' => ' . $pImgURL);
                        $output->writeln("");
                        $this->log('Product value "(' . $pImgURL . ')" found empty or invalid for given product: ' . $proLabel);
                        continue;
                    }
                    $mediaPathFile = $mediaPath . '/' . basename($pImgURL);
                    if (file_exists($mediaPathFile)) {
                        $output->writeln("Media already found for given  " . $proLabel. ' => ' . $pImgURL);
                        $output->writeln("");
                        $this->log('Product value ' . $proLabel . ' exists already on this path: ' . $mediaPathFile);
                        
                        continue;
                    }
                    $output->writeln("Media found valid, so file_get_contents for  " . $proLabel.' - '. $pImgURL);
                    $mediaFileImgOrVideo = @file_get_contents($pImgURL);
                    if (!$mediaFileImgOrVideo) {
                        $this->log('Media get contents not valid for : ' . $proLabel. ' => ' . $pImgURL);
                        continue;
                    }
                    $putStatus = @file_put_contents($mediaPathFile, $mediaFileImgOrVideo);
                    $output->writeln("Media downloaded completed for  " . $proLabel);
                    $output->writeln("");
                }
                
                $this->perProductTotalExecutionTime = microtime(true) - $this->perProductStartTime;
                $diff = gmdate('H:i:s', intval($this->perProductTotalExecutionTime));
                if (false === $putStatus) {
                    $this->log('Media could not save to path: ' . $proLabel);
                    continue;
                }
                $this->log('Time taken for ' . $proLabel . ' => ' . $diff);
                $progress->setMessage($product->getId() . ' ');
                $output->writeln("Completed " . $proLabel);
                $progress->advance();
                $output->writeln("");
            }
            $output->writeln('');
            $this->totalExecutionTime = microtime(true) - $this->startTime;
        } catch (Exception $e) {


            $output->writeln("");
            $output->writeln("<error>{$e->getMessage()}</error>");
            return Cli::RETURN_FAILURE;
        }
        $output->writeln('');
        $output->writeln('<info>Completed for all the products '.$proCount .' || '. gmdate('H:i:s', intval($this->totalExecutionTime)) . '</info>');
        return Cli::RETURN_SUCCESS;
    }

    /**
     * @param $message
     * @return void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function log($message)
    {
        if (!$this->helper->getLogEnabled()) {
            return;
        }
        $dateToday = 'azvd-'.date('Y_m_d_H').'-Downloader.log';
        $writer = new Stream(BP . '/var/log/'.$dateToday);
        $logger = new Logger();
        $logger->addWriter($writer);
        $logger->info($message);
    }
    
    
}