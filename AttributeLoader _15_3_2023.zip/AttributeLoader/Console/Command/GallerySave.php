<?php

namespace Custom\AttributeLoader\Console\Command;

use Custom\AttributeLoader\Helper\Data;
use Exception;
use Laminas\Log\Logger;
use Laminas\Log\Writer\Stream;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as Product_Model;
use Magento\Catalog\Model\ResourceModel\Attribute;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Console\Cli;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\App\Area;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Store\Model\StoreManagerInterface as StoreManagerInterface;
use Psr\Log\LoggerInterface as LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as Magento_CollectionFactory;
use Magento\Catalog\Api\Data\ProductInterface;
use Symfony\Component\Console\Input\InputArgument;
use Webprojectsol\DaneaEasyFatt\Model\ResourceModel\ImportCatalog\Collection as WebImportCatalogCollection;
use Webprojectsol\DaneaEasyFatt\Model\Dir as DaneaEasyFattDir;
use Magento\Catalog\Model\ResourceModel\Product\Gallery;

class GallerySave extends Command
{
    const AREA_CODE_LOCK_FILE = 'custom_attribute_gallery_save_areacode.lock';
    const STORE_ARGUMENT = 'sku';

    /**
     * @var ProductAttributeRepositoryInterface
     */
    protected $productAttributeRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var Attribute
     */
    protected $attributeResource;

    /**
     * @var State
     */
    protected $appState;

    /**
     * @var \Magento\Framework\EntityManager\EntityMetadata
     */
    protected $metadata;

    /**
     * @var State
     */
    protected $state;

    /**
     * @var StoreManagerInterface
     */
    protected $storeInterface;

    /**
     * @var DirectoryList
     */
    protected $directoryList;

    /**
     * @var LoggerInterface
     */
    protected $logger;
    private $productRepository;
    private $productCollection;
    private $productCollectionFactory;
    private $totalExecutionTime;
    private $startTime;
    private $filesystem;
    private $helper;
    private $perProductTotalExecutionTime;
    private $perProductStartTime;
    private $webImportCatalogCollection;
    private $daneaEasyFattDir;


    public function __construct(
        State                      $appState,
        StoreManagerInterface      $storeInterface,
        DirectoryList              $directoryList,
        LoggerInterface            $logger,
        Magento_CollectionFactory  $productCollectionFactory,
        ProductRepositoryInterface $productRepository,
        Filesystem                 $filesystem,
        Data                       $helper,
        WebImportCatalogCollection $webImportCatalogCollection,
        DaneaEasyFattDir           $daneaEasyFattDir,
        Gallery                    $productGallery 
        
    )
    {
        $this->appState = $appState;
        $this->storeInterface = $storeInterface;
        $this->directoryList = $directoryList;
        $this->logger = $logger;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productRepository = $productRepository;
        $this->filesystem = $filesystem;
        $this->helper = $helper;
        $this->webImportCatalogCollection = $webImportCatalogCollection;
        $this->daneaEasyFattDir = $daneaEasyFattDir;
        $this->productGallery = $productGallery;
        parent::__construct();
    }

    /**
     * Initialization of the command.
     */
    protected function configure()
    {
        $this->setName('custom:gallerysave:sku');
        $this->setDescription('will take SKUs(not product ids) will check image and if image exists then save To gallery.');
        $this->setDefinition([
            new InputArgument(
                self::STORE_ARGUMENT,
                InputArgument::OPTIONAL,
                'The sku (comma separated) to save gallery.'
            )
        ]);
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int
     * @throws LocalizedException
     * @throws FileSystemException
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $skus ='';
        $output->setDecorated(true);
        if (!$this->helper->isEnabled()) {
            $output->writeln(__(
                sprintf(' Module is disabled from backend')
            )->getText());
            return Cli::RETURN_SUCCESS;
        }
        $this->startTime = microtime(true);
        $logDir = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $storeLockFile = $putStatus= '';
        $areaCodeFile = $logDir . "/" . self::AREA_CODE_LOCK_FILE;
        try {
            if (file_exists($areaCodeFile)) {
                unlink($areaCodeFile);
            }
            $this->appState->setAreaCode(Area::AREA_FRONTEND);
        } catch (LocalizedException $e) {
            fopen($areaCodeFile, 'w');
            if ($this->appState->getAreaCode() != Area::AREA_FRONTEND) {
                $output->writeln(__(
                    sprintf('  Running in an unexpected state AreaCode : (%s)', $this->appState->getAreaCode())
                )->getText());
            }
        }

        /*
        $importsCatalog = $this->webImportCatalogCollection->addFieldToSelect('filename')
            ->addFieldToFilter(['status','status'], [
                ['eq' => \Webprojectsol\DaneaEasyFatt\Model\ImportCatalog::STATUS_SUCCESS],
                ['eq' => \Webprojectsol\DaneaEasyFatt\Model\ImportCatalog::STATUS_STOPPED],
               ])
            ->setOrder('date','DESC')
            ->getData();
        */  
        $pathForSkus = $this->daneaEasyFattDir->dirImportExport().'/*_ProgressVideoUpload.txt';
        $filesToImport = glob($pathForSkus);
        
        $skus = $input->getArgument(self::STORE_ARGUMENT);
        //if (empty($importsCatalog) && !$skus) {
        if (!$filesToImport && !$skus) {
            $output->writeln('_ProgressVideoUpload.txt or Skus are not found.');
            return Cli::RETURN_SUCCESS;
        }
        
        $products_to_update = false;
        if(!$skus) {
            /*foreach ($importsCatalog as $keyV => $importModel) {
                if($keyV > 3) {
                    continue;
                }
                //if($keyV!==0){continue;}
                $filesToImport[$keyV] = $this->daneaEasyFattDir->dirImportExport().trim($importModel['filename']) . '_ProgressVideoUpload.txt';
            }*/
            
            //Below is the progress file where completed SKUs were written
            $fileProgressName = $this->daneaEasyFattDir->dirImportExport().date('Ymd').'progressGallerySaveLogs.txt';
            
            $fileExitsFlag = true;
            if($filesToImport){
                foreach($filesToImport as $fileToImport) {
                    if(!file_exists($fileToImport) && !$skus) {
                        //$output->writeln('ProgressVideoUploadFile is not exists:'. $fileToImport);
                        //$this->log('ProgressVideoUploadFile is not exists: '. $fileToImport);
                        $fileExitsFlag = false;
                        continue;
                    }
                
                    //Last Modified Date
                    $mdate = date("Ymd", filemtime($fileToImport));
                    //Current Date
                    $currentDate  = date("Ymd");
                    $output->writeln('*********************************************');
                    $output->writeln('File difference: '.($currentDate - $mdate) .' for '.$fileToImport);
                    //Skip those files older than 1 day
                    if ($mdate && ($currentDate - $mdate) > 1) {
                        $output->writeln('File skipping due to old: '.($currentDate - $mdate) .' for '.$fileToImport);
                        continue;
                    }
                    $fileData = file_get_contents($fileToImport);
                    if($fileToImport && $fileData) {
                        $output->writeln('ProgressVideoUploadFile is exists:'. $fileToImport);
                        
                        //Associated array
                        $idsDecodeList = \Webprojectsol\DaneaEasyFatt\Helper\Data::_JsonDecode($fileData, true);
                        if([] == $idsDecodeList) {
                            continue;
                        }
    
                        $orgCount = is_array($idsDecodeList) || $idsDecodeList instanceof Countable ? count($idsDecodeList) : 0;
                        $output->writeln('Original File elements size Of: '.$orgCount);
                        
                        if($fileProgressName && file_exists($fileProgressName)) {
                            $fileProgressData = explode("\n", file_get_contents($fileProgressName));
                            $idsDecodeList = array_diff($idsDecodeList, $fileProgressData);
                        }
                        $countFruits = is_array($idsDecodeList) || $idsDecodeList instanceof Countable ? count($idsDecodeList) : 0;
                        $output->writeln('Latest size Of: '.$countFruits);
                        
                        //AVG time is 4 min 50 secs for 40 SKUs, CRON runs every 7 min.
                        $sliceLimit = 40;
                        if($countFruits > $sliceLimit) {
                            $products_to_update[] = array_slice($idsDecodeList, 0, $sliceLimit);
                        } else {
                            $products_to_update[] = $idsDecodeList;
                        }
                        $fileExitsFlag = true;
                    }
                }    
            }
            
            
            if(gettype($products_to_update) !=='array') {
                $this->log('Found products to update type neq array. '.gettype($products_to_update));
                $this->log(print_r($products_to_update,true));
            }
            
            $output->writeln(print_r($products_to_update,true));
            //$this->log(print_r($products_to_update,true));
            
            if(!$products_to_update && !is_array($products_to_update) && !$skus) {
                $output->writeln('No further SKUs found: '.gettype($products_to_update) );
                return Cli::RETURN_SUCCESS;
            }    
        }
        
        try {
            $mediaAttribute = $this->helper->getSelectedAttributeCode();
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect(
                ['id', 'sku', $mediaAttribute, 'da_media_image_filename', 'da_media_link']
            );
            $collection->setOrder('entity_id','DESC');
            
            if($skus !== 'all') {
                if($skus) {
                    $skus = explode(",",$skus);
                    $collection->addAttributeToFilter(
                        'sku',['in'=> [$skus]]
                    );
                }
                
                if($products_to_update) {
                    $products_to_update = array_filter($products_to_update);
                    $collection->addAttributeToFilter(
                        'sku',['in'=> [$products_to_update]]
                    );
                }
                $collection->setFlag('has_stock_status_filter', false);
            }
            
            //This will avoid to execute everytime for all products.
            if(!$skus && !$products_to_update) {
                $output->writeln('No further SKUs found or text file both are empty');
                $this->log('No further SKUs found or text file both are empty');
                return Cli::RETURN_SUCCESS;
            }
            
            $output->writeln("=== Starting process for saving images ===");
            $output->writeln('');
            $proCount = count($collection);
            $progress = new ProgressBar($output,$proCount);
            $progress->setFormat('<comment>%message%</comment> %current%/%max% [%bar%] %percent:3s%% %elapsed%');
            
            // would be : /home/dzouvxeo/public_html/pub/media/import
            $mediaPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath().'import';
            $this->log($collection->getSelect()->__toString());
            
            foreach ($collection as $productKey => $product) {
                
                //if($product->getId() > 3635) {
                   //continue;
                //}
                $this->perProductStartTime = microtime(true);
                if (!$product instanceof Product_Model) {
                    $output->writeln('Product not found valid.' . $product->getId());
                    $this->log('Product not found valid.' . $product->getId());
                    continue;
                }
                
                $proLabel = 'ProductID: ' . $product->getId() . ' || SKU: ' . $product->getSku();
                $this->log('Process started for: '.$proLabel);
                $mediaFileImgOrVideoAttributeValue = $product->getDataUsingMethod($mediaAttribute);
                if (!$mediaFileImgOrVideoAttributeValue) {
                    //$output->writeln('ProductAttributeValue found InValid: ' . $product->getSku().' Value: '.$mediaFileImgOrVideoAttributeValue);
                    $this->log('Product value "(' .$mediaAttribute.'=>'. $mediaFileImgOrVideoAttributeValue . ')" found empty or invalid for given product: ' . $proLabel);
                    //continue;
                }
                $producerAsImages= null;
                if ($mediaFileImgOrVideoAttributeValue) {
                    $producerAsImages = explode (";", $mediaFileImgOrVideoAttributeValue);
                    if (!$producerAsImages) {
                        continue;
                    }    
                }
                
                $existingMediaGalleryEntries = $product->getMediaGalleryEntries();
                if ($existingMediaGalleryEntries) {
                    $output->writeln('MediaGalleryEntries found for : '.$product->getId());
                    foreach ($existingMediaGalleryEntries as $key => $entry) {
                        if (!empty($entry)) {   
                            $output->writeln(print_r($entry,true));
                            unset($existingMediaGalleryEntries[$key]);
                        }
                    }
                
                    if($product->getDataUsingMethod('name')) {
                        //Setted because of attribute name error was throwing
                        try {
                            //$product->setMediaGalleryEntries($existingMediaGalleryEntries);
                            //$this->productRepository->save($product);
                        } catch(\Exception $e) {
                            $this->log($e->getMessage());
                            $output->writeln($e->getMessage()." thrown while removing media gallery: " . $proLabel);
                            continue;
                        }
                    }
                }
                
                
                //Main Single Image
                $media_link = $product->getDataUsingMethod('da_media_link');
                if($media_link && filter_var($media_link, FILTER_VALIDATE_URL) !== FALSE) {
                    //$output->writeln("Main Image found :  " . $proLabel. ' => ' . $media_link);
                    //$output->writeln("");
                    $mediaPathFile = $mediaPath . '/' . basename($media_link);
                    
                    $this->saveImageGallery($product, $mediaPathFile, true);
                }
                
                if($producerAsImages){
                    foreach($producerAsImages as $pKey => $pImgURL) {
                        if (!$pImgURL || filter_var($pImgURL, FILTER_VALIDATE_URL) === FALSE) {
                            //$output->writeln("Media found empty or invalid for given  " . $proLabel. ' => ' . $pImgURL);
                            //$output->writeln("");
                            //$this->log('Product value "(' . $pImgURL . ')" found empty or invalid for given product: ' . $proLabel);
                            continue;
                        }
                        $mediaPathFile = $mediaPath . '/' . basename($pImgURL);
                        if (file_exists($mediaPathFile)) {
                            //$output->writeln("Media File already exists for given  " . $proLabel. ' => ' . $pImgURL);
                            //$output->writeln("");
                            //$this->log('Product value ' . $proLabel . ' exists already on this path: ' . $mediaPathFile);
                            $this->saveImageGallery($product, $mediaPathFile);
                            continue;
                        } else {
                            $this->log('Media Path not found: '.$mediaPathFile);
                            $output->writeln('Media Path not found: '.$mediaPathFile);
                        }
                    }    
                }
                
                
                try {
                    //$product->save();
                    $this->productRepository->save($product);
                } catch(\Exception $e){
                    $this->log($e->getMessage());
                    $output->writeln($e->getMessage()." thrown while saving: " . $proLabel);
                    continue;
                }
                    
                $this->perProductTotalExecutionTime = microtime(true) - $this->perProductStartTime;
                $diff = gmdate('H:i:s', intval($this->perProductTotalExecutionTime));
                 
                $output->writeln('Took seconds for ' . $proLabel . ' => ' . $diff);
                $this->log('Took seconds for ' . $proLabel . ' => ' . $diff);
                
                if($products_to_update) {
                    file_put_contents($fileProgressName, PHP_EOL.$product->getSku() , FILE_APPEND | LOCK_EX);
                }

                $progress->setMessage($product->getId() . ' ');
                $output->writeln("Completed " . $proLabel);
                $progress->advance();
                //$output->writeln("");
            }
            unset($product);
            $output->writeln('');
            $this->totalExecutionTime = microtime(true) - $this->startTime;
        } catch (Exception $e) {
            $output->writeln("");
            $output->writeln("<error>{$e->getMessage()}</error>");
            return Cli::RETURN_FAILURE;
        }
        $output->writeln('');
        $output->writeln('Completed for all the products '.$proCount .' || '. gmdate('H:i:s', intval($this->totalExecutionTime)) );
        return Cli::RETURN_SUCCESS;
    }

    /**
     * @param $message
     * @return void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function log($message)
    {
        if (!$this->helper->getLogEnabled()) {
            return;
        }
        $dateToday = 'az-'.date('Y_m_d_H').'-MediaGallerySave.log';
        $writer = new Stream(BP . '/var/log/'.$dateToday);
        $logger = new Logger();
        $logger->addWriter($writer);
        $logger->info($message);
    }
    
    private function saveImageGallery($product, $pImgPath, $type =null) {
        //if(file_exists($pImgPath)) {
        if($type == null) {
            $product->addImageToMediaGallery(
				$pImgPath, 
				null, 
				false, 
				false
		    );
        } else {
            $product->addImageToMediaGallery(
			    $pImgPath, 
			    array('image', 'small_image', 'thumbnail'), 
			    false, 
			    false
            );  
        }
		    
		//}
    }
}